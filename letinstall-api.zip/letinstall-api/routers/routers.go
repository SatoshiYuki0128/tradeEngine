package router

import (
	"fmt"
	"io/ioutil"
	"letsinstallapi/controller"
	sdkcontroller "letsinstallapi/controller/SDK"
	appchannelcontroller "letsinstallapi/controller/appChannel"
	applistcontroller "letsinstallapi/controller/appList"
	doccontroller "letsinstallapi/controller/doc"
	ownerusercontroller "letsinstallapi/controller/ownerUser"
	registercontroller "letsinstallapi/controller/register"
	rolecontroller "letsinstallapi/controller/role"
	roleroutecontroller "letsinstallapi/controller/roleRoute"
	groupController "letsinstallapi/controller/userGroup"
	examplecontroller "letsinstallapi/example/controller"
	"letsinstallapi/models"
	"os"
	"time"

	"net/http"
	"net/http/pprof"

	"github.com/google/uuid"
	"github.com/gorilla/mux"
	"github.com/spf13/viper"
	httpSwaggergo "github.com/swaggo/http-swagger"
	"go.elastic.co/apm"
)

var (
	routes []models.ApiRoute
)

func init() {
	//* Health check start
	register("GET", "/admin-api/v2/Health/health", controller.HealthCheck, nil)
	//* Health check End

	/* *** ApiDoc AppChannel ******** */
	register("POST", "/admin-api/ApiDoc/AppChannel/GetAppChannel", doccontroller.Doc_GetAppChannel, nil)
	register("PUT", "/admin-api/ApiDoc/AppChannel/PutAppChannel", doccontroller.Doc_PutAppChannel, nil)
	/* *** ApiDoc App ******** */
	register("POST", "/admin-api/ApiDoc/App/GetApp", doccontroller.Doc_GetApp, nil)
	register("PUT", "/admin-api/ApiDoc/App/PutApp", doccontroller.Doc_PutApp, nil)
	/* *** ApiDoc UserGroup ******** */
	register("POST", "/admin-api/ApiDoc/UserGroup/GetUserGroup", doccontroller.Doc_GetUserGroup, nil)
	register("PUT", "/admin-api/ApiDoc/UserGroup/PutUserGroup", doccontroller.Doc_PutUserGroup, nil)
	register("GET", "/admin-api/ApiDoc/UserGroup/GetPromoURL", doccontroller.Doc_GetPromoURL_UserGroup, nil)
	/* *** ApiDoc Role ******** */
	register("POST", "/admin-api/ApiDoc/Role/GetRole", doccontroller.Doc_GetRole, nil)
	register("PUT", "/admin-api/ApiDoc/Role/PutRole", doccontroller.Doc_PutRole, nil)
	/* *** ApiDoc RoleRoute ******** */
	register("POST", "/admin-api/ApiDoc/RoleRoute/GetRoleRoute", doccontroller.Doc_GetRoleRoute, nil)
	register("PUT", "/admin-api/ApiDoc/RoleRoute/PutRoleRoute", doccontroller.Doc_PutRoleRoute, nil)
	/* *** ApiDoc OwnerUser ******** */
	register("POST", "/admin-api/ApiDoc/OwnerUser/GetOwnerUser", doccontroller.Doc_GetOwnerUser, nil)
	register("PUT", "/admin-api/ApiDoc/OwnerUser/PutOwnerUser", doccontroller.Doc_PutOwnerUser, nil)
	register("PUT", "/admin-api/ApiDoc/OwnerUser/ReSetPassword", doccontroller.Doc_ReSetPassword, nil)
	/* *** ApiDoc GuestWeb ******** */
	register("PUT", "/admin-api/ApiDoc/GuestWeb/RegisterUser", doccontroller.Doc_RegisterUser, nil)
	register("POST", "/admin-api/ApiDoc/GuestWeb/Login", doccontroller.Doc_Login, nil)
	/* *** ApiDoc SDK ******** */
	register("PUT", "/admin-api/ApiDoc/SDK/AgentDeviceInfo", doccontroller.Doc_AgentDeviceInfo, nil)     //0913
	register("PUT", "/admin-api/ApiDoc/SDK/setDownload", doccontroller.Doc_AgentDevice_setDownload, nil) //0913
	register("POST", "/admin-api/ApiDoc/SDK/AgentDevice_1st", doccontroller.Doc_AgentDevice_1st, nil)    //0913

	//* pprof start
	register("GET", "/debug/pprof/", pprof.Index, nil)
	register("GET", "/debug/pprof/allocs", pprof.Index, nil)
	register("GET", "/debug/pprof/block", pprof.Index, nil)
	register("GET", "/debug/pprof/cmdline", pprof.Index, nil)
	register("GET", "/debug/pprof/goroutine", pprof.Index, nil)
	register("GET", "/debug/pprof/heap", pprof.Index, nil)
	register("GET", "/debug/pprof/mutex", pprof.Index, nil)
	register("GET", "/debug/pprof/profile", pprof.Index, nil)
	register("GET", "/debug/pprof/threadcreate", pprof.Index, nil)
	register("GET", "/debug/pprof/trace", pprof.Index, nil)
	//* pprof end

	//* example start
	register("POST", "/admin-api/v2/example/video1", examplecontroller.Example_GetVideo1, nil)
	register("GET", "/admin-api/v2/example/video", examplecontroller.Example_GetVideo, nil)
	register("GET", "/admin-api/v2/example/count", examplecontroller.Example_GetCount, nil)
	register("GET", "/admin-api/v2/example/ids", examplecontroller.Example_GetIds, nil)
	register("GET", "/admin-api/v2/example/onevideo", examplecontroller.Example_GetOneVideo, nil)
	register("GET", "/admin-api/v2/example/videos", examplecontroller.Example_GetVideos, nil)
	//* example end

	/* *** v2 SDK ******** */
	register("PUT", "/admin-api/v2/SDK/AgentDeviceInfo", sdkcontroller.AgentDeviceInfo, nil)     //0913
	register("PUT", "/admin-api/v2/SDK/setDownload", sdkcontroller.AgentDevice_setDownload, nil) //0913
	register("POST", "/admin-api/v2/SDK/AgentDevice_1st", sdkcontroller.AgentDevice_1st, nil)    //0913
	/* *** v2 SDK ******** */

	register("POST", "/admin-api/v2/cxbb/Register/OtpCheck", registercontroller.PostOtpcheck, nil)

	//* App start
	register("POST", "/admin-api/v2/App/GetApp", applistcontroller.PostApplist, nil)
	register("PUT", "/admin-api/v2/App/EditApp", applistcontroller.EditApplist, nil)
	//* App end

	//* AppChannel start
	register("POST", "/admin-api/v2/AppChannel/GetAppChannel", appchannelcontroller.PostAppchannel, nil)
	register("PUT", "/admin-api/v2/AppChannel/PutAppChannel", appchannelcontroller.PutAppChannel, nil)
	//* AppChannel end

	//* Register start
	register("PUT", "/admin-api/v2/GuestWeb/RegisterUser", registercontroller.RegisterUser, nil)
	register("POST", "/admin-api/v2/GuestWeb/Login", registercontroller.UserLogin, nil)
	register("PUT", "/admin-api/v2/GuestWeb/ForgetPassword", registercontroller.PutForgetpassword, nil)
	register("POST", "/admin-api/v2/GuestWeb/GetVerifyCode", registercontroller.PutGetverifycode, nil)
	//* Register end

	//* RoleRoute start
	register("POST", "/admin-api/v2/RoleRoute/GetRoleRoute", roleroutecontroller.GetRoleRoute, nil)
	register("PUT", "/admin-api/v2/RoleRoute/PutRoleRoute", roleroutecontroller.PutRoleRoute, nil)
	//* RoleRoute end

	//* Role start
	register("POST", "/admin-api/v2/Role/GetRole", rolecontroller.GetRole, nil)
	register("PUT", "/admin-api/v2/Role/PutRole", rolecontroller.PutRole, nil)
	//* Role end

	register("GET", "/admin-api/v2/Group/promoCode", groupController.GetPromoCode, nil)
	register("POST", "/admin-api/v2/Group/userGroup", groupController.GetUserGroup, nil)
	register("PUT", "/admin-api/v2/Group/userGroup", groupController.EditUserGroup, nil)

	register("POST", "/admin-api/v2/OwnerUser/ownerUser", ownerusercontroller.GetOwnerUser, nil)
	register("PUT", "/admin-api/v2/OwnerUser/ownerUser", ownerusercontroller.EditOwnerUser, nil)
	register("PUT", "/admin-api/v2/OwnerUser/resetPassword", ownerusercontroller.ResetPassword, nil)
}

func NewRouter() *mux.Router {
	r := mux.NewRouter()
	if viper.GetBool("Swagger.ShowSwagger") {
		r.PathPrefix("/api/swagger").Handler(httpSwaggergo.WrapHandler)
	}

	for _, route := range routes {
		r.Methods(route.Method, "OPTIONS").
			Path(route.Pattern).
			Handler(route.Handler)
	}

	r.Use(AddRequestTrace)
	r.Use(Middleware)
	return r
}

func register(method, pattern string, handler http.HandlerFunc, middleware mux.MiddlewareFunc) {
	routes = append(routes, models.ApiRoute{method, pattern, handler, middleware})
}

func Middleware(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "DELETE, POST, PUT, GET, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "X-Requested-With, Content-Type, Accept, Ekey, Host, Token, Useragent, Vendor, UserKey, cid, GroupKey, x-domain, authToken, botblock, user-agent, Tid, origin, referer, X-CSRF-Token, Authorization")
		w.Header().Set("Access-Control-Expose-Headers", "x-cdn-rdi")
		w.Header().Set("Access-Control-Allow-Credentials", "true")
		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		xip := r.Header.Get("X-FORWARDED-FOR")
		if xip != "" {
			w.Header().Set("X-FORWARDED-FOR", xip)
		}

		h.ServeHTTP(w, r)
	})
}

func NotFoundMiddleware(w http.ResponseWriter, r *http.Request) {
	RequestLog(r, "404", "", "")

	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte("404 Not Found"))
}

func AddRequestTrace(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		traceHeaderName := "rd7-mobile2-trace"
		traceHeaderValue := CreateRequestTrace()

		r.Header.Set(traceHeaderName, traceHeaderValue)

		h.ServeHTTP(w, r)
	})
}

// CreateSocketID 產生新的SocketID
func CreateRequestTrace() (requestTrace string) {
	requestTrace = uuid.NewString()

	hostname, _ := os.Hostname()

	//GetPodName 取得Pod Name結尾兩位
	if len(hostname) > 0 {
		requestTrace = hostname + "-" + requestTrace
	}

	//fmt.Println("Your SocketID is: %s", socketID)

	return
}

func RequestLog(r *http.Request, status string, traceId string, spanId string) {
	logstr := fmt.Sprintf("Time:%s,Host:%s,URL:%s,Method:%s,Proto:%s,", time.Now().Format("2006-01-02 15:04:05"), r.Host, r.URL, r.Method, r.Proto)
	for key, element := range r.Header {
		logstr = fmt.Sprintf("%s%s:%s,", logstr, key, element)
	}

	//* 排除上傳檔案(FormData)與method = get
	if r.Method != "GET" && r.Body != nil && len(r.MultipartForm.File) == 0 {
		body, _ := ioutil.ReadAll(r.Body)
		logstr = logstr + fmt.Sprintf("body: %s,request-status : %s", body, status)
	}

	fmt.Println(fmt.Sprintf("reqlog:%s, traceId=%s, spanId=%s", logstr, traceId, spanId))
}

func APMTrace(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		tx := apm.TransactionFromContext(r.Context())
		traceContext := tx.TraceContext()
		traceId := traceContext.Trace
		spanId := traceContext.Span
		RequestLog(r, "200", fmt.Sprintf("%s", traceId), fmt.Sprintf("%s", spanId))
		h.ServeHTTP(w, r)
	})
}
