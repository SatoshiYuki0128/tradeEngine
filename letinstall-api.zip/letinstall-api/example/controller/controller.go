package examplecontroller

import (
	exampleservices "letsinstallapi/example/service"
	"letsinstallapi/models"
	"net/http"
)

// @Summary 範例_合併header,querystring,urlparam,requestbody到request model[EX1]
// @Tags Video
// @version 1.0
// @produce application/json
// @param hd1 header string true "testheader"
// @param hd2 query string true "email"
// @Param param body models.TestVideoRequestBody true "data"
// @Success 200 {object} models.TestVideo
// @Router /v2/example/video1 [POST]
func Example_GetVideo1(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	exampleservices.GetAndValidateRequest1[models.TestVideoRequest](r, &flowData, "EX1")

	exampleservices.Example_GetVideo(&flowData, "EX1")

	exampleservices.ServeResponse1(w, &flowData)
}

// @Summary 範例_RequestModel巢狀結構[EX2]
// @Tags Video
// @version 1.0
// @produce application/json
// @param hd1 header string true "testheader"
// @param hd2 query string true "email"
// @Param videoId header int true "videoId"
// @Success 200 {object} int
// @Router /v2/example/video [Get]
func Example_GetVideo(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	exampleservices.GetAndValidateRequest1[models.TestVideoRequest](r, &flowData, "EX2")

	exampleservices.Example_GetVideo(&flowData, "EX2")

	exampleservices.ServeResponse1(w, &flowData)
}

// @Summary 範例_DB取單一值[EX3]
// @Tags Video
// @version 1.0
// @produce application/json
// @Success 200 {object} int
// @Router /v2/example/count [Get]
func Example_GetCount(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}

	exampleservices.Example_GetCount(&flowData, "EX3")

	exampleservices.ServeResponse1(w, &flowData)
}

// @Summary 範例_DB取單值array[EX4]
// @Tags Video
// @version 1.0
// @produce application/json
// @Success 200 {object} models.TestVideo
// @Router /v2/example/ids [Get]
func Example_GetIds(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}

	exampleservices.Example_GetIds(&flowData, "EX4")

	exampleservices.ServeResponse1(w, &flowData)
}

// @Summary 範例_DB取單一struct[EX5]
// @Tags Video
// @version 1.0
// @produce application/json
// @Success 200 {object} []int
// @Router /v2/example/onevideo [Get]
func Example_GetOneVideo(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}

	exampleservices.Example_GetOneVideo(&flowData, "EX5")

	exampleservices.ServeResponse1(w, &flowData)
}

// @Summary 範例_DB取struct array[EX6]
// @Tags Video
// @version 1.0
// @produce application/json
// @Success 200 {object} []models.TestVideo
// @Router /v2/example/videos [Get]
func Example_GetVideos(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}

	exampleservices.Example_GetVideos(&flowData, "EX6")

	exampleservices.ServeResponse1(w, &flowData)
}
