package example

import (
	"fmt"
	"letsinstallapi/common"
)

func ApiGet() {
	query := map[string]string{}
	query["account"] = "HT01"
	query["env"] = "prod"

	byteResponse, err := common.APIGET("https://sxqa2.777xqa.com:5569/api/v1/ThirdCloud/CDN/LiveCDN", nil, query)

	if err != nil {
		fmt.Println("error:", err)
	}

	fmt.Println(string(byteResponse))
}
