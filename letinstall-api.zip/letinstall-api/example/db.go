package example

import (
	"fmt"
	"letsinstallapi/factory"
	"letsinstallapi/models"
)

func GetSingleData(videoId int) (data models.TestVideo) {

	sqlStr := `select id,code
			from videos
			where id=?;`

	var model []models.TestVideo
	//用模組代號取得模組:gormsql/gosql
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&model, sqlStr, videoId)

	if err != nil {
		fmt.Println("error:", err)
	}
	//實例上只實作了多筆取資料，故變數傳入與使用是用Slice跟Slice[0]
	fmt.Println("data:", model[0])
	data = model[0]
	return
}

func GetMultiData() {

	sqlStr := `select id,code
			from videos;`

	var model []models.TestVideo
	//用模組代號取得模組:gormsql/gosql
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&model, sqlStr)

	if err != nil {
		fmt.Println("error:", err)
	}

	fmt.Println("data:", model)
}

func InsertOrUpdateOrDeleteData() {

	sqlStr := `update videos
			set code=code
			where id=?;`

	//用模組代號取得模組:gormsql/gosql
	dbModule := factory.GetDbModule("gosql")
	rowsAffected, err := dbModule.Dbo.SqlUpdateOrDelete(sqlStr, 99999)

	if err != nil {
		fmt.Println("error:", err)
	}

	fmt.Println(rowsAffected)
}
