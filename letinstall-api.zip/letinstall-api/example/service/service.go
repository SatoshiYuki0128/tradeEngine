package exampleservices

import (
	"encoding/json"
	"letsinstallapi/common"
	httphelper "letsinstallapi/common/http"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"net/http"
)

//ServiceCode:N/A
func GetAndValidateRequest1[T any](r *http.Request, info *models.FlowData, ctrlCode string) {

	data, isOK := httphelper.GetRequestBody(r, info, ctrlCode, "EX")
	if isOK {
		httphelper.CheckModel[T](data, r, info, ctrlCode, "EX")
	}

	return
}

//ServiceCode:N/A
func ServeResponse1(w http.ResponseWriter, info *models.FlowData) {

	httphelper.JsonResponse(w, info)
}

//ServiceCode:EX1
func Example_GetVideo(flowData *models.FlowData, ctrlCode string) {

	if flowData.Err != nil {
		return
	}

	req := flowData.Request.(models.TestVideoRequest)
	sqlStr := `select id,code
			from videos
			where id=?;`
	byteVideos, err := common.SqlSelect(common.DefaultSlave, sqlStr, req.VideoId)
	if err != nil {
		servErr := models.ServError{ServCode: "EX1", FuncCode: "00", Msg: "Get DB Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}

	var sliceVideos []models.TestVideo
	err = json.Unmarshal(byteVideos, &sliceVideos)
	if err != nil {
		servErr := models.ServError{ServCode: "EX1", FuncCode: "01", Msg: "Json Serialize Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}
	flowData.Response = sliceVideos[0]

	return
}

//ServiceCode:EX2
func Example_GetCount(flowData *models.FlowData, ctrlCode string) {

	if flowData.Err != nil {
		return
	}
	sqlStr := `select count(id) as count
			from videos;`
	var count int
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&count, sqlStr)
	if err != nil {
		servErr := models.ServError{ServCode: "EX2", FuncCode: "00", Msg: "Get DB Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}
	flowData.Response = count

	return
}

//ServiceCode:EX3
func Example_GetIds(flowData *models.FlowData, ctrlCode string) {

	if flowData.Err != nil {
		return
	}
	sqlStr := `select id
			from videos;`
	var ids []int
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&ids, sqlStr)
	if err != nil {
		servErr := models.ServError{ServCode: "EX3", FuncCode: "00", Msg: "Get DB Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}
	flowData.Response = ids

	return
}

//ServiceCode:EX4
func Example_GetOneVideo(flowData *models.FlowData, ctrlCode string) {

	if flowData.Err != nil {
		return
	}
	sqlStr := `select id
			from videos
			where id=99999;`
	var video models.TestVideo
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&video, sqlStr)
	if err != nil {
		servErr := models.ServError{ServCode: "EX4", FuncCode: "00", Msg: "Get DB Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}
	flowData.Response = video

	return
}

//ServiceCode:EX5
func Example_GetVideos(flowData *models.FlowData, ctrlCode string) {

	if flowData.Err != nil {
		return
	}
	sqlStr := `select id
			from videos;`
	var video []models.TestVideo
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&video, sqlStr)
	if err != nil {
		servErr := models.ServError{ServCode: "EX5", FuncCode: "00", Msg: "Get DB Error", Err: err}
		flowData.CtrlError = models.CtrlError{CtrlCode: ctrlCode, ServError: servErr}
		return
	}
	flowData.Response = video

	return
}
