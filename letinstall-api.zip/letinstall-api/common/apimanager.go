package common

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/spf13/viper"
)

//* Call API By Get
func APIGET(url string, headers map[string]string, querys map[string]string) (response []byte, err error) {
	client := &http.Client{
		Timeout: GetRequestTimeoutBySeconed(),
	}

	// oringe sample
	//client := apmhttp.WrapClient(http.DefaultClient)

	req, _ := http.NewRequest("GET", url, nil)
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	if len(headers) > 0 {
		for key, value := range headers {
			req.Header.Add(key, value)
		}
	}

	if len(querys) > 0 {
		q := req.URL.Query()

		for key, value := range querys {
			q.Add(key, value)
		}

		req.URL.RawQuery = q.Encode()
	}

	// print request curl
	//command, _ := http2curl.GetCurlCommand(req)
	//fmt.Println(command)

	resp, errMsg := client.Do(req)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}
	defer resp.Body.Close()
	response, errMsg = ioutil.ReadAll(resp.Body)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	return
}

//* Call API By Put
func APIPUT(urlink string, headers map[string]string, querys map[string]string, body []byte, formBody map[string]string) (response []byte, err error) {
	client := &http.Client{
		Timeout: GetRequestTimeoutBySeconed(),
	}

	req, _ := http.NewRequest("PUT", urlink, bytes.NewReader(body))
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	req.Header.Add("Content-Type", "application/json")

	if len(headers) > 0 {
		for key, value := range headers {
			req.Header.Add(key, value)
		}
	}

	if len(querys) > 0 {
		q := req.URL.Query()
		for key, value := range querys {
			q.Add(key, value)
		}
		req.URL.RawQuery = q.Encode()
	}

	if len(formBody) > 0 {
		for key, value := range formBody {
			req.Form.Add(key, value)
		}
	}

	resp, errMsg := client.Do(req)

	if errMsg != nil {
		fmt.Println(errMsg)
		return
	} else {
		defer resp.Body.Close()
	}

	response, errMsg = ioutil.ReadAll(resp.Body)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	return
}

//* Call API By Post
func APIPOST(urlink string, headers map[string]string, querys map[string]string, body []byte) (response []byte, err error) {
	client := &http.Client{
		Timeout: GetRequestTimeoutBySeconed(),
	}

	req, _ := http.NewRequest("POST", urlink, bytes.NewReader(body))
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	req.Header.Add("Content-Type", "application/json")

	if len(headers) > 0 {
		for key, value := range headers {
			req.Header.Add(key, value)
		}
	}

	if len(querys) > 0 {
		q := req.URL.Query()
		for key, value := range querys {
			q.Add(key, fmt.Sprintf("%v", value))
		}
		req.URL.RawQuery = q.Encode()
	}
	//command, _ := http2curl.GetCurlCommand(req)
	//fmt.Println(command)

	resp, errMsg := client.Do(req)

	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	if resp != nil {
		defer resp.Body.Close()
	}

	response, errMsg = ioutil.ReadAll(resp.Body)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	return
}

//* Call API By Post
func APIPOSTFormEncode(urlink string, headers map[string]string, querys map[string]string, formBody map[string]string) (response []byte, err error) {
	client := &http.Client{
		Timeout: GetRequestTimeoutBySeconed(),
	}

	form := url.Values{}

	for key, value := range formBody {
		form.Add(key, value)
	}

	//req, err := http.NewRequest("POST", url, strings.NewReader(form.Encode()))
	req, _ := http.NewRequest("POST", urlink, strings.NewReader(form.Encode()))
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	if len(headers) > 0 {
		for key, value := range headers {
			req.Header.Add(key, value)
		}
	}

	if len(querys) > 0 {
		q := req.URL.Query()
		for key, value := range querys {
			q.Add(key, fmt.Sprintf("%v", value))
		}
		req.URL.RawQuery = q.Encode()
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	//command, _ := http2curl.GetCurlCommand(req)
	//fmt.Println(command)

	resp, errMsg := client.Do(req)

	if resp != nil {
		defer resp.Body.Close()
	}

	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	response, errMsg = ioutil.ReadAll(resp.Body)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	return
}

//* Call API By Delete
func APIDELETE(url string, headers map[string]string, querys map[string]string, body []byte, formBody map[string]string) (response []byte, err error) {
	client := &http.Client{
		Timeout: GetRequestTimeoutBySeconed(),
	}

	req, _ := http.NewRequest("DELETE", url, bytes.NewReader(body))
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	req.Header.Add("Content-Type", "application/json")

	if len(headers) > 0 {
		for key, value := range headers {
			req.Header.Add(key, value)
		}
	}

	if len(querys) > 0 {
		q := req.URL.Query()
		for key, value := range querys {
			q.Add(key, fmt.Sprintf("%v", value))
		}
		req.URL.RawQuery = q.Encode()
	}

	if len(formBody) > 0 {
		for key, value := range formBody {
			req.Form.Add(key, value)
		}
	}

	//command, _ := http2curl.GetCurlCommand(req)
	//fmt.Println(command)

	resp, errMsg := client.Do(req)
	defer resp.Body.Close()

	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	response, errMsg = ioutil.ReadAll(resp.Body)
	if errMsg != nil {
		fmt.Println(errMsg)
		return
	}

	return
}

//取得Request Timeout時間
func GetRequestTimeoutBySeconed() time.Duration {
	result := viper.GetDuration("ClientRequestSetting.timneoutbySecond") * time.Second

	if result < 0 {
		result = 30 * time.Second
	}

	return result
}
