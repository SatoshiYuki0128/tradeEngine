package md5helper

import (
	"crypto/md5"
	"fmt"
)

func GenerateMD5(password string) (md5str1 string) {
	data := []byte(password)
	has := md5.Sum(data)
	md5str1 = fmt.Sprintf("%x", has) //将[]byte转成16进制
	return
}
