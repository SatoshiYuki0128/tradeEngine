package common

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"

	_ "github.com/go-sql-driver/mysql"
	"github.com/shopspring/decimal"
	"github.com/spf13/viper"
)

type DBConnection int

const (
	DefaultMaster = 0
	DefaultSlave  = 1
)

type DbFactory interface {
	PrintDBErrorLog(string, error, ...interface{})
	SqlSelect(interface{}, string, ...interface{}) error
	SqlInsert(string, ...interface{}) (int64, int64, error)
	SqlUpdateOrDelete(string, ...interface{}) (int64, error)
	SqlTransactionExecute([]string, [][]interface{}) error
}

func (db DBConnection) String() string {
	switch db {
	case DefaultMaster:
		return "ConnectionStrings.MasterConnection"
	case DefaultSlave:
		return "ConnectionStrings.SlaveConnection"
	default:
		panic("Unknown DB connection")
	}
}

func PrintDBErrorLog(dbConnection DBConnection, sqlStr string, err error, args ...interface{}) {
	if err != nil {
		msg := fmt.Sprintf("sql error, dbConnection:%d, sqlStr:%s, args:%v, error msg:%v \n", dbConnection, sqlStr, args, err)
		fmt.Printf("%s\n", msg)
	}
}

func SqlSelect(dbConnection DBConnection, sqlStr string, args ...interface{}) (jsonByte []byte, err error) {

	var connectionString = viper.GetString(dbConnection.String())
	db, err := sql.Open("mysql", connectionString)
	defer func() {
		if db != nil {
			db.Close()
		}
	}()

	PrintDBErrorLog(dbConnection, sqlStr, err, args...)

	if err != nil {
		return
	}

	if err = db.Ping(); err != nil {
		fmt.Println("opon database fail:", err)
		return
	}

	rows, err := db.Query(sqlStr, args...)
	defer func() {
		if rows != nil {
			rows.Close() //关闭掉未scan的sql连接
		}
	}()

	PrintDBErrorLog(dbConnection, sqlStr, err, args...)

	jsonByte, err = SqlRowsToJson(rows)

	return
}

func SqlInsert(dbConnection DBConnection, sqlStr string, args ...interface{}) (rowsAffected int64, lastId int64, err error) {

	var connectionString = viper.GetString(dbConnection.String())
	db, err := sql.Open("mysql", connectionString)
	defer func() {
		if db != nil {
			db.Close()
		}
	}()

	if err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	if err = db.Ping(); err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	result, err := db.Exec(sqlStr, args...)

	if err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	rowsAffected, _ = result.RowsAffected()
	lastId, _ = result.LastInsertId()

	return
}

func SqlUpdateOrDelete(dbConnection DBConnection, sqlStr string, args ...interface{}) (rowsAffected int64, err error) {

	var connectionString = viper.GetString(dbConnection.String())
	db, err := sql.Open("mysql", connectionString)
	defer func() {
		if db != nil {
			db.Close()
		}
	}()

	if err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	if err = db.Ping(); err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	result, err := db.Exec(sqlStr, args...)

	if err != nil {
		PrintDBErrorLog(dbConnection, sqlStr, err, args...)
		return
	}

	rowsAffected, err = result.RowsAffected()

	return
}

func SqlRowsToJson(rows *sql.Rows) (jsonByte []byte, err error) {
	columns, err := rows.Columns()
	if err != nil {
		return
	}
	ct, _ := rows.ColumnTypes()
	count := len(columns)
	values := make([]interface{}, count)
	scanArgs := make([]interface{}, count)
	for i := range values {
		scanArgs[i] = &values[i]
	}

	masterDatas := []map[string]interface{}{}

	for rows.Next() {
		masterData := make(map[string]interface{})
		err = rows.Scan(scanArgs...)
		if err != nil {
			return
		}
		for i, v := range values {
			if v == nil {
				masterData[columns[i]] = nil
				continue
			}
			//v.(string)
			//x := v.(string)

			//NOTE: FROM THE GO BLOG: JSON and GO - 25 Jan 2011:
			// The json package uses map[string]interface{} and []interface{} values to store arbitrary JSON objects and arrays; it will happily unmarshal any valid JSON blob into a plain interface{} value. The default concrete Go types are:
			//
			// bool for JSON booleans,
			// float64 for JSON numbers,
			// string for JSON strings, and
			// nil for JSON null.

			switch ct[i].DatabaseTypeName() {
			case "BIGINT", "MEDIUMINT", "INT", "TINYINT":
				switch reflect.TypeOf(v).Kind() {
				case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
					if nx, err := strconv.Atoi(fmt.Sprint(v.(int64))); err == nil {
						masterData[columns[i]] = nx
					}
				default:
					if nx, err := strconv.Atoi(string(v.([]byte))); err == nil {
						masterData[columns[i]] = nx
					}
				}
			case "BINARY":
				if b, err := strconv.Atoi(string(v.([]byte))); err == nil {
					masterData[columns[i]] = b
				}
			case "DECIMAL":
				if d, err := decimal.NewFromString(string(v.([]byte))); err == nil {
					masterData[columns[i]] = d
				}
			/*if b, err := strconv.ParseBool(string(v.([]byte))); err == nil {
				masterData[columns[i]] = b
			}*/
			case "VARCHAR", "CHAR", "NVARCHAR", "NCHAR":
				masterData[columns[i]] = string(v.([]byte))
			case "DATETIME", "DATE":
				masterData[columns[i]] = string(v.([]byte))
			default:
				//* 型態如果無法識別就中斷返回
				err = fmt.Errorf(fmt.Sprintln(columns[i] + " columntype:" + ct[i].DatabaseTypeName() + " not set"))
				return
			}

		}
		masterDatas = append(masterDatas, masterData)
	}
	bjson, err := json.Marshal(masterDatas)
	if err != nil {
		return
	}

	jsonByte = bjson
	return
}

func TakeSliceArg(arg interface{}) (out []interface{}, ok bool) {
	slice, success := takeArg(arg, reflect.Slice)
	if !success {
		ok = false
		return
	}
	c := slice.Len()
	out = make([]interface{}, c)
	for i := 0; i < c; i++ {
		out[i] = slice.Index(i).Interface()
	}
	return out, true
}
func takeArg(arg interface{}, kind reflect.Kind) (val reflect.Value, ok bool) {
	val = reflect.ValueOf(arg)
	if val.Kind() == kind {
		ok = true
	}
	return
}
