package otphelper

import (
	"fmt"
	redishelper "letsinstallapi/common/redis"
	"time"

	"github.com/xlzd/gotp"
)

const secretLength = 16

//FunctionCode:OH1
func VerifyOTP(key string, otpcode string) (result bool) {
	redisKey := fmt.Sprintf("verifyOTP-%s", key)
	if redishelper.IsExistKey(redisKey) {
		secret := redishelper.GetKey(redisKey)
		now := time.Now()
		otp := gotp.NewTOTP(secret, 6, 600, nil)
		result = otp.Verify(otpcode, int(now.Unix()))
	}
	return
}

//FunctionCode:OH2
func GenerateOTP(key string) (optCode string) {
	secret := gotp.RandomSecret(secretLength)
	otp := gotp.NewTOTP(secret, 6, 600, nil)
	optCode = otp.Now()
	redisKey := fmt.Sprintf("verifyOTP-%s", key)
	redishelper.SetRedisDataWithAcitiveSecond(redisKey, secret, 600)

	return
}
