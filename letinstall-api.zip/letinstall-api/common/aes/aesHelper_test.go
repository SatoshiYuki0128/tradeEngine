package aeshelper

import (
	"testing"
)

func TestAesEncryptCBC(t *testing.T) {
	type args struct {
		orig string
		key  string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{"testAesEncrypt", args{"qqq", AES128Key}, "9aESD0fu+En/OPYrXZQ7Wg=="},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := AesEncryptCBC(tt.args.orig, tt.args.key); got != tt.want {
				t.Errorf("AesEncryptCBC() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestAesDecryptCBC(t *testing.T) {
	type args struct {
		cryted string
		key    string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{"testAesDecrypt", args{"9aESD0fu+En/OPYrXZQ7Wg==", AES128Key}, "qqq"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := AesDecryptCBC(tt.args.cryted, tt.args.key); got != tt.want {
				t.Errorf("AesDecryptCBC() = %v, want %v", got, tt.want)
			}
		})
	}
}
