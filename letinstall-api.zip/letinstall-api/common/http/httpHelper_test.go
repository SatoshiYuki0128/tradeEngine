package httphelper

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"letsinstallapi/models"
	"net/http"
	"net/url"
	"reflect"
	"testing"
)

func createMockRequest() *http.Request {
	mockRequest, _ := http.NewRequest("POST", "http://localhost", bytes.NewReader([]byte(`{"videoId":99999,"testId":122}`)))
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	mockRequest.Header.Add("hd1", "mid")

	q := mockRequest.URL.Query()
	q.Add("hd2", fmt.Sprintf("%v", "123@123"))
	mockRequest.URL.RawQuery = q.Encode()
	return mockRequest
}

func Test_setRequestHeaderIntoRequest(t *testing.T) {
	mockRequest := createMockRequest()
	type args struct {
		headers http.Header
		request interface{}
	}
	tests := []struct {
		name string
		args args
	}{
		{"setRequestHeaderIntoRequest", args{mockRequest.Header, &models.TestVideoRequest{}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			setRequestHeaderIntoRequest(tt.args.headers, tt.args.request)
			if tt.args.request.(*models.TestVideoRequest).Header != "mid" {
				t.Error("setRequestHeaderIntoRequest error")
			}
		})
	}
}

func TestGetRequestBody(t *testing.T) {
	mockRequest := createMockRequest()
	type args struct {
		r              *http.Request
		flowData       *models.FlowData
		controllerCode string
		serviceCode    string
	}
	tests := []struct {
		name     string
		args     args
		wantData []byte
		wantIsOK bool
	}{
		{"GetRequestBody", args{mockRequest, &models.FlowData{}, "HHT", "HHT"}, []byte(`{"videoId":99999,"testId":122}`), true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotData, gotIsOK := GetRequestBody(tt.args.r, tt.args.flowData, tt.args.controllerCode, tt.args.serviceCode)
			if !reflect.DeepEqual(gotData, tt.wantData) {
				t.Errorf("GetRequestBody() gotData = %v, want %v", gotData, tt.wantData)
			}
			if gotIsOK != tt.wantIsOK {
				t.Errorf("GetRequestBody() gotIsOK = %v, want %v", gotIsOK, tt.wantIsOK)
			}
		})
	}
}

func Test_setQueryStringIntoRequest(t *testing.T) {
	mockRequest := createMockRequest()
	type args struct {
		querys  url.Values
		request interface{}
	}
	tests := []struct {
		name string
		args args
	}{
		{"setQueryStringIntoRequest", args{mockRequest.URL.Query(), &models.TestVideoRequest{}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			setQueryStringIntoRequest(tt.args.querys, tt.args.request)
			if tt.args.request.(*models.TestVideoRequest).Query != "123@123" {
				t.Error("setQueryStringIntoRequest error")
			}
		})
	}
}

func Test_validateRequest(t *testing.T) {
	type args struct {
		flowData       *models.FlowData
		request        interface{}
		controllerCode string
		serviceCode    string
	}
	tests := []struct {
		name      string
		args      args
		isError   bool
		wantError string
	}{
		{"validateRequest", args{&models.FlowData{}, models.TestVideoRequestBody{VideoId: 0, M1GT0Id: 99}, "TV", "TV"}, true, "Validate Error:VideoId必须大于0;"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			validateRequest(tt.args.flowData, tt.args.request, tt.args.controllerCode, tt.args.serviceCode)
			if tt.isError {
				if tt.args.flowData.Msg != tt.wantError {
					t.Error("validateRequest Error")
				}
			}
		})
	}
}
