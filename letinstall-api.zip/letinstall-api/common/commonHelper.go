package common

import (
	"context"
	"reflect"
	"strconv"
	"strings"
)

func GenericContains(target interface{}, list interface{}) (bool, int) {
	if reflect.TypeOf(list).Kind() == reflect.Slice || reflect.TypeOf(list).Kind() == reflect.Array {
		listvalue := reflect.ValueOf(list)
		for i := 0; i < listvalue.Len(); i++ {
			if target == listvalue.Index(i).Interface() {
				return true, i
			}
		}
	}
	if reflect.TypeOf(target).Kind() == reflect.String && reflect.TypeOf(list).Kind() == reflect.String {
		return strings.Contains(list.(string), target.(string)), strings.Index(list.(string), target.(string))
	}
	return false, -1
}

func GetContextValue[T any](ctx context.Context, k string) (value T, ok bool) {

	value, ok = ctx.Value(k).(T)
	return
}

func DynamicSetModelOld[T any](targetModel interface{}, fieldName string, fieldValue string) {
	reflectModelValue := reflect.ValueOf(targetModel)
	var emptyModel T
	reflectModelType := reflect.TypeOf(emptyModel)
	//DynamicSetModel1(reflectModelType, reflectModelValue, fieldName, fieldValue)
	for i := 0; i < reflectModelType.NumField(); i++ {
		rf := reflectModelType.Field(i)
		v, ok := rf.Tag.Lookup("json")
		if ok && strings.Split(strings.ToLower(v), ",")[0] == fieldName {
			switch reflectModelValue.Elem().Field(i).Kind() {
			case reflect.Bool:
				boolData, _ := strconv.ParseBool(fieldValue)
				reflectModelValue.Elem().Field(i).SetBool(boolData)
				break
			case reflect.String:
				reflectModelValue.Elem().Field(i).SetString(fieldValue)
				break
			case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
				intData, _ := strconv.Atoi(fieldValue)
				reflectModelValue.Elem().Field(i).SetInt(int64(intData))
				break
			case reflect.Float32, reflect.Float64:
				floatData, _ := strconv.ParseFloat(fieldValue, 64)
				reflectModelValue.Elem().Field(i).SetFloat(floatData)
				break
			default:
				reflectModelValue.Elem().Field(i).SetBytes([]byte(fieldValue))
				break
			}
		} else {
			reflectField := reflectModelValue.Elem().FieldByName(fieldName)
			if reflectField.IsValid() {
				switch reflectField.Kind() {
				case reflect.Bool:
					boolData, _ := strconv.ParseBool(fieldValue)
					reflectField.SetBool(boolData)
					break
				case reflect.String:
					reflectField.SetString(fieldValue)
					break
				case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
					intData, _ := strconv.Atoi(fieldValue)
					reflectField.SetInt(int64(intData))
					break
				case reflect.Float32, reflect.Float64:
					floatData, _ := strconv.ParseFloat(fieldValue, 64)
					reflectField.SetFloat(floatData)
					break
				default:
					reflectField.SetBytes([]byte(fieldValue))
					break
				}
			}
		}
	}

}

func DynamicSetModelOld2[T any](targetModel interface{}, fieldName string, fieldValue string) {
	reflectModelValue := reflect.ValueOf(targetModel).Elem()
	var emptyModel T
	reflectModelType := reflect.TypeOf(emptyModel)
	nestReflectSetModel(reflectModelType, reflectModelValue, fieldName, fieldValue)
}
func DynamicSetModel(targetModel interface{}, fieldName string, fieldValue string) {
	reflectModelValue := reflect.ValueOf(targetModel).Elem()
	reflectModelType := reflect.ValueOf(targetModel).Type().Elem()
	nestReflectSetModel(reflectModelType, reflectModelValue, fieldName, fieldValue)
}
func nestReflectSetModel(reflectType reflect.Type, reflectValue reflect.Value, fieldName string, fieldValue string) {
	for i := 0; i < reflectType.NumField(); i++ {
		rf := reflectType.Field(i)
		if rf.Type.Kind() == reflect.Struct {
			nestReflectSetModel(rf.Type, reflectValue.Field(i), fieldName, fieldValue)
			continue
		}
		v, ok := rf.Tag.Lookup("json")
		if ok && strings.Split(strings.ToLower(v), ",")[0] == fieldName {
			reflectField := reflectValue.Field(i)
			switch reflectField.Kind() {
			case reflect.Bool:
				boolData, _ := strconv.ParseBool(fieldValue)
				reflectField.SetBool(boolData)
				break
			case reflect.String:
				reflectField.SetString(fieldValue)
				break
			case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
				intData, _ := strconv.Atoi(fieldValue)
				reflectField.SetInt(int64(intData))
				break
			case reflect.Float32, reflect.Float64:
				floatData, _ := strconv.ParseFloat(fieldValue, 64)
				reflectField.SetFloat(floatData)
				break
			default:
				reflectField.SetBytes([]byte(fieldValue))
				break
			}
		} else {
			reflectField := reflectValue.FieldByName(fieldName)
			if reflectField.IsValid() {
				switch reflectField.Kind() {
				case reflect.Bool:
					boolData, _ := strconv.ParseBool(fieldValue)
					reflectField.SetBool(boolData)
					break
				case reflect.String:
					reflectField.SetString(fieldValue)
					break
				case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
					intData, _ := strconv.Atoi(fieldValue)
					reflectField.SetInt(int64(intData))
					break
				case reflect.Float32, reflect.Float64:
					floatData, _ := strconv.ParseFloat(fieldValue, 64)
					reflectField.SetFloat(floatData)
					break
				default:
					reflectField.SetBytes([]byte(fieldValue))
					break
				}
			}

		}
	}

}

func IsNoBlankViewableAsciiString(target string) (result bool) {

	for i := range target {
		if target[i] < '!' || target[i] > '~' {
			result = false
			break
		}
		result = true
	}

	return
}

func MarkString(input string, markLength int) (output string) {
	for i := 0; i < len(input); i++ {
		if i < markLength {
			output += "*"
		} else {
			output += string(input[i])
		}
	}
	return
}
