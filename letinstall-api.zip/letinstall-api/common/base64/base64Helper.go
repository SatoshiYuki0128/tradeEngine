package base64helper

import (
	"encoding/base64"
	"fmt"
	"strings"
)

func Base64Encode(input string) (output string) {
	output = base64.StdEncoding.EncodeToString([]byte(input))
	return
}

func Base64Decode(input string) (output string) {
	uidbyte, err := base64.StdEncoding.DecodeString(input)
	if err != nil {
		fmt.Println("Base64Decode Error:", err)
		return
	}
	uidStr := string(uidbyte[:])
	uidArrary := strings.Split(uidStr, ":")
	for i := range uidArrary {
		output += uidArrary[i]
	}
	return
}
