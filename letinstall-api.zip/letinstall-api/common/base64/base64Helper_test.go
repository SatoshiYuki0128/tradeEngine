package base64helper

import (
	"testing"
)

func TestBase64Encode(t *testing.T) {
	type args struct {
		input string
	}
	tests := []struct {
		name       string
		args       args
		wantOutput string
	}{
		{"test_base64encode", args{"testbase64"}, "dGVzdGJhc2U2NA=="},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotOutput := Base64Encode(tt.args.input); gotOutput != tt.wantOutput {
				t.Errorf("Base64Encode() = %v, want %v", gotOutput, tt.wantOutput)
			}
		})
	}
}

func TestBase64Decode(t *testing.T) {
	type args struct {
		input string
	}
	tests := []struct {
		name       string
		args       args
		wantOutput string
	}{
		{"test_base64decode", args{"dGVzdGJhc2U2NA=="}, "testbase64"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotOutput := Base64Decode(tt.args.input); gotOutput != tt.wantOutput {
				t.Errorf("Base64Decode() = %v, want %v", gotOutput, tt.wantOutput)
			}
		})
	}
}
