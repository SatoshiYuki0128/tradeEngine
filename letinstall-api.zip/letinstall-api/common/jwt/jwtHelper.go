package jwthelper

import (
	"errors"
	"letsinstallapi/models"
	"time"

	"github.com/golang-jwt/jwt/v4"
	"github.com/spf13/viper"
)

const Key = "token"

//FunctionCode:JH1
func GenerateJwtToken(userID string) (string, error) {
	nowTime := time.Now()
	expireTime := nowTime.Add(time.Duration(viper.GetInt("JWT.TOKEN_LIFE")) * time.Second)

	claims := models.Claims{
		userID,
		jwt.StandardClaims{
			ExpiresAt: expireTime.Unix(),
			Issuer:    "PID",
		},
	}

	tokenClaims := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	token, err := tokenClaims.SignedString([]byte(viper.GetString("JWT.SECRET")))

	return token, err
}

//FunctionCode:JH2
func ParseJwtToken(jwtToken string) (userID string, err error) {
	tokenClaims, err := jwt.ParseWithClaims(jwtToken, &models.Claims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(viper.GetString("JWT.SECRET")), nil
	})

	if err != nil {
		return "", err
	}

	claims, ok := tokenClaims.Claims.(*models.Claims)
	if !ok || !tokenClaims.Valid {
		return "", errors.New("tokenClaims invalid")
	}

	return claims.UserID, nil
}
