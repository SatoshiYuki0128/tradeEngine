package goSql

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"letsinstallapi/common"
	"reflect"
	"strconv"

	_ "github.com/go-sql-driver/mysql"
	"github.com/shopspring/decimal"
	"github.com/spf13/viper"
)

type GoSqlClient struct {
	common.DbFactory
	MasterDB *sql.DB
	SlaveDB  *sql.DB
}

func NewGoSqlClient() *GoSqlClient {

	return &GoSqlClient{MasterDB: goSqlDB(common.DefaultMaster), SlaveDB: goSqlDB(common.DefaultSlave)}
}

func goSqlDB(conn common.DBConnection) (db *sql.DB) {

	var connectionString = viper.GetString(conn.String())
	db, err := sql.Open("mysql", connectionString)

	if err != nil {
		fmt.Printf("GoSql Connect Failed : %v", err)
		panic(err)
	}

	if err = db.Ping(); err != nil {
		fmt.Printf("GoSql Ping Failed : %v", err)
		panic(err)
	}

	return
}

func (db *GoSqlClient) PrintDBErrorLog(sqlStr string, err error, args ...interface{}) {
	if err != nil {
		msg := fmt.Sprintf("sql error, sqlStr:%s, args:%v, error msg:%v \n", sqlStr, args, err)
		fmt.Printf("%s\n", msg)
	}
}

func (db *GoSqlClient) SqlSelect(dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	reflectValue := reflect.ValueOf(dataPointer).Elem()

	switch reflectValue.Kind() {
	case reflect.Array, reflect.Slice:
		err = sqlSelectSliceData(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	default:
		err = sqlSelectSingleData(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	}
	return
}

func sqlSelectSliceData(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	reflectValue := reflect.ValueOf(dataPointer).Elem().Type().Elem()

	switch reflectValue.Kind() {
	case reflect.Struct:
		err = sqlSelectStructSlice(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	default:
		err = sqlSelectValueSlice(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	}

	return
}

func sqlSelectStructSlice(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	rows, err := db.SlaveDB.Query(sqlStr, args...)
	defer func() {
		if rows != nil {
			rows.Close()
		}
	}()

	db.PrintDBErrorLog(sqlStr, err, args...)

	jsonByte, err := sqlRowsToJson(rows)

	if err != nil {
		fmt.Println("sqlRowsToJson error:", err)
		return
	}

	err = json.Unmarshal(jsonByte, &dataPointer)

	if err != nil {
		fmt.Println("RowJson Unmarshal error:", err)
		return
	}

	return
}

func sqlSelectValueSlice(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	rows, err := db.SlaveDB.Query(sqlStr, args...)
	defer func() {
		if rows != nil {
			rows.Close()
		}
	}()

	jsonByte, err := sqlRowsToJsonNoColumnName(rows)
	if err != nil {
		fmt.Println("sqlRowsToJsonNoColumnName error:", err)
		return
	}

	err = json.Unmarshal(jsonByte, &dataPointer)

	if err != nil {
		fmt.Println("RowJson Unmarshal error:", err)
		return
	}

	return
}

func sqlSelectSingleData(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	reflectValue := reflect.ValueOf(dataPointer).Elem()
	switch reflectValue.Kind() {
	case reflect.Struct:
		err = sqlSelectSingleStruct(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	default:
		err = sqlSelectSingleValue(db, dataPointer, sqlStr, args...)
		db.PrintDBErrorLog(sqlStr, err, args...)
		break
	}
	return
}

func sqlSelectSingleValue(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	rows, err := db.SlaveDB.Query(sqlStr, args...)
	defer func() {
		if rows != nil {
			rows.Close()
		}
	}()

	for rows.Next() {
		err = rows.Scan(dataPointer)
		if err != nil {
			return
		}
	}

	return
}

func sqlSelectSingleStruct(db *GoSqlClient, dataPointer interface{}, sqlStr string, args ...interface{}) (err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	rows, err := db.SlaveDB.Query(sqlStr, args...)
	defer func() {
		if rows != nil {
			rows.Close()
		}
	}()

	db.PrintDBErrorLog(sqlStr, err, args...)

	jsonByte, err := sqlSingleRowToJson(rows)

	if err != nil {
		fmt.Println("sqlSingleRowToJson error:", err)
		return
	}

	err = json.Unmarshal(jsonByte, &dataPointer)

	if err != nil {
		fmt.Println("RowJson Unmarshal error:", err)
		return
	}

	return
}

func (db *GoSqlClient) SqlInsert(sqlStr string, args ...interface{}) (rowsAffected, lastInsertId int64, err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	result, err := db.MasterDB.Exec(sqlStr, args...)

	if err != nil {
		db.PrintDBErrorLog(sqlStr, err, args...)
		return
	}

	rowsAffected, _ = result.RowsAffected()
	lastInsertId, _ = result.LastInsertId()

	return
}

func (db *GoSqlClient) SqlUpdateOrDelete(sqlStr string, args ...interface{}) (rowsAffected int64, err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	result, err := db.MasterDB.Exec(sqlStr, args...)

	if err != nil {
		db.PrintDBErrorLog(sqlStr, err, args...)
		return
	}

	rowsAffected, err = result.RowsAffected()

	return
}

func sqlRowsToJson(rows *sql.Rows) (jsonByte []byte, err error) {
	columns, err := rows.Columns()
	if err != nil {
		return
	}
	ct, _ := rows.ColumnTypes()
	count := len(columns)
	values := make([]interface{}, count)
	scanArgs := make([]interface{}, count)
	for i := range values {
		scanArgs[i] = &values[i]
	}

	masterDatas := []map[string]interface{}{}

	for rows.Next() {
		masterData := make(map[string]interface{})
		err = rows.Scan(scanArgs...)
		if err != nil {
			return
		}
		for i, v := range values {
			if v == nil {
				masterData[columns[i]] = nil
				continue
			}
			masterData[columns[i]], err = transferDbValueToGenericValue(v, ct[i].DatabaseTypeName())
			if err != nil {
				fmt.Println(columns[i], err)
				return
			}
		}
		masterDatas = append(masterDatas, masterData)
	}
	bjson, err := json.Marshal(masterDatas)
	if err != nil {
		return
	}

	jsonByte = bjson
	return
}

func sqlSingleRowToJson(rows *sql.Rows) (jsonByte []byte, err error) {
	columns, err := rows.Columns()
	if err != nil {
		return
	}
	ct, _ := rows.ColumnTypes()
	count := len(columns)
	values := make([]interface{}, count)
	scanArgs := make([]interface{}, count)
	for i := range values {
		scanArgs[i] = &values[i]
	}

	masterData := make(map[string]interface{})

	for rows.Next() {

		err = rows.Scan(scanArgs...)
		if err != nil {
			return
		}
		for i, v := range values {
			if v == nil {
				masterData[columns[i]] = nil
				continue
			}

			masterData[columns[i]], err = transferDbValueToGenericValue(v, ct[i].DatabaseTypeName())
			if err != nil {
				fmt.Println(columns[i], err)
				return
			}
		}
	}
	bjson, err := json.Marshal(masterData)
	if err != nil {
		return
	}

	jsonByte = bjson
	return
}

func sqlRowsToJsonNoColumnName(rows *sql.Rows) (jsonByte []byte, err error) {
	columns, err := rows.Columns()
	if err != nil {
		return
	}
	ct, _ := rows.ColumnTypes()
	count := len(columns)
	values := make([]interface{}, count)
	scanArgs := make([]interface{}, count)
	for i := range values {
		scanArgs[i] = &values[i]
	}

	masterDatas := []interface{}{}

	for rows.Next() {
		var masterData interface{}
		err = rows.Scan(scanArgs...)
		if err != nil {
			return
		}
		for i, v := range values {
			if v == nil {
				masterData = nil
				continue
			}

			masterData, err = transferDbValueToGenericValue(v, ct[i].DatabaseTypeName())
			if err != nil {
				fmt.Println(err)
				return
			}
		}
		masterDatas = append(masterDatas, masterData)
	}
	bjson, err := json.Marshal(masterDatas)
	if err != nil {
		return
	}

	jsonByte = bjson
	return
}

func transferDbValueToGenericValue(value interface{}, dataTypeName string) (result interface{}, err error) {
	switch dataTypeName {
	case "BIGINT", "MEDIUMINT", "INT", "TINYINT":
		switch reflect.TypeOf(value).Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			if nx, err := strconv.Atoi(fmt.Sprint(value.(int64))); err == nil {
				result = nx
			}
		default:
			if nx, err := strconv.Atoi(string(value.([]byte))); err == nil {
				result = nx
			}
		}
	case "BINARY":
		if b, err := strconv.Atoi(string(value.([]byte))); err == nil {
			result = b
		}
	case "DECIMAL":
		if d, err := decimal.NewFromString(string(value.([]byte))); err == nil {
			result = d
		}
	/*if b, err := strconv.ParseBool(string(v.([]byte))); err == nil {
		masterData[columns[i]] = b
	}*/
	case "VARCHAR", "CHAR", "NVARCHAR", "NCHAR":
		result = string(value.([]byte))
	case "DATETIME", "DATE":
		result = string(value.([]byte))
	default:
		err = errors.New("columntype:" + dataTypeName + " not support")
	}
	return
}

func (db *GoSqlClient) SqlTransactionExecute(sqlStrArray []string, argsArray [][]interface{}) (err error) {

	defer func() {
		if db != nil {
			db.MasterDB.Close()
			db.SlaveDB.Close()
		}
	}()

	tx, err := db.MasterDB.Begin()
	if err != nil {
		fmt.Printf("DB init transaction failed,err:%v\n", err)
		return
	}
	defer tx.Rollback()

	for i, sql := range sqlStrArray {
		_, err = tx.Exec(sql, argsArray[i]...)
		if err != nil {
			db.PrintDBErrorLog(sql, err, argsArray[i])
			return
		}
	}

	err = tx.Commit()
	if err != nil {
		fmt.Printf("DB commit transaction failed,err:%v\n", err)
		return
	}

	return
}
