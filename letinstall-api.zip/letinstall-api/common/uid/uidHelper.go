package uidhelper

import (
	"fmt"
	"os"
	"time"

	"github.com/sony/sonyflake"
)

var sf *sonyflake.Sonyflake

func init() {
	var setting sonyflake.Settings
	fixFlakeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2022-09-01 00:00:00", time.UTC)
	setting.StartTime = fixFlakeTime
	sf = sonyflake.NewSonyflake(setting)
	if sf == nil {
		panic("Sonyflake Init Error")
	}
}

func generateSonyflake() (id uint64) {

	id, err := sf.NextID()
	if err != nil {
		panic(fmt.Sprintf("flake.NextID() failed with %s\n", err))
	}
	return
}

func getMachineId() (machineID uint16, err error) {
	machineID = uint16(os.Getuid())
	return
}

func GetBase16Uid(prefix string) (uid string) {
	id := generateSonyflake()
	uid = fmt.Sprintf("%s%X", prefix, id)
	return
}
