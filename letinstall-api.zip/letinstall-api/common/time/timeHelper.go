package timehelper

import (
	"fmt"
	"strings"
	"time"
)

const TIME_LAYOUT = "2006-01-02 15:04:05"

func GetUTCTime() time.Time {
	return time.Now().In(time.UTC)
}

func GetTaipeiTime() time.Time {
	time_UTC := GetUTCTime()
	return time_UTC.Add(time.Hour * 8)
}

func GetTaipeiTimeString() string {
	return GetTaipeiTime().Format(TIME_LAYOUT)
}

func GetUTCTimeString() string {
	return GetUTCTime().Format(TIME_LAYOUT)
}

func ParseWithLocation(locationName string, timeString string) (utcTime time.Time, err error) {

	if location, err := time.LoadLocation(locationName); err != nil {
		fmt.Println("Load Location Error:" + err.Error())
		return time.Time{}, err
	} else {
		localTime, _ := time.ParseInLocation(TIME_LAYOUT, timeString, location)
		return localTime.In(time.UTC), nil
	}
}

//arvin
func TimeString(str string) string {
	str = strings.TrimSpace(str)
	if IsEmptyTime(str) {
		return "NULL"
	} else {
		str = fmt.Sprintf("'%s'", str)
	}
	return str
}

//arvin
func IsEmptyTime(str string) bool {
	chk := strings.Replace(str, "0", "", -1)
	chk = strings.Replace(chk, "-", "", -1)
	chk = strings.Replace(chk, ":", "", -1)
	chk = strings.Replace(chk, " ", "", -1)
	chk = strings.TrimSpace(chk)
	return (chk == "")
}
