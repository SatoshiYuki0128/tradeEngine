package rsahelper

import (
	r "crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/hex"
	"fmt"

	"github.com/spf13/viper"
)

func RSA_Encrypt(str string) string {

	//取得公鑰
	publicKeyString := viper.GetString("rsaPublicKey")
	publicKeyByte, _ := hex.DecodeString(publicKeyString)

	//解碼
	keyInit, err := x509.ParsePKIXPublicKey(publicKeyByte)
	if err != nil {
		return ""
	}

	//加密
	pubKey := keyInit.(*rsa.PublicKey)
	result, err := rsa.EncryptPKCS1v15(r.Reader, pubKey, []byte(str))
	if err != nil {
		fmt.Println(err)
		return ""
	}

	h := hex.EncodeToString(result)

	return h
}

func RSA_Decrypt(str string) []byte {

	if len(str) != 1024 {
		errorMessage := "長度不對"
		return []byte(errorMessage)
	}

	array, _ := hex.DecodeString(str)

	privateKeyString := viper.GetString("rsaPrivateKey")
	privateKeyByte, _ := hex.DecodeString(privateKeyString)

	privateKey, _ := x509.ParsePKCS1PrivateKey(privateKeyByte)
	res, err := rsa.DecryptPKCS1v15(r.Reader, privateKey, array)

	if err != nil {
		fmt.Println(err)
	}

	return res
}
