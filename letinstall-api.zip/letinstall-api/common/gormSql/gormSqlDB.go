package gormSql

import (
	"fmt"
	"letsinstallapi/common"
	"reflect"

	"github.com/spf13/viper"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type GormSqlClient struct {
	common.DbFactory
	MasterDB *gorm.DB
	SlaveDB  *gorm.DB
}

func NewGormSqlClient() *GormSqlClient {

	return &GormSqlClient{MasterDB: gormDB(common.DefaultMaster), SlaveDB: gormDB(common.DefaultSlave)}
}

func gormDB(conn common.DBConnection) (db *gorm.DB) {

	dsn := conn.String()
	db, err := gorm.Open(mysql.Open(viper.GetString(dsn)), &gorm.Config{})
	if err != nil {
		fmt.Printf("Gorm Connect Failed : %v", err)
		panic(err)
	}
	return
}

func (db *GormSqlClient) PrintDBErrorLog(sqlStr string, err error, args ...interface{}) {
	if err != nil {
		msg := fmt.Sprintf("sql error, sqlStr:%s, args:%v, error msg:%v \n", sqlStr, args, err)
		fmt.Printf("%s\n", msg)
	}
}

func (db *GormSqlClient) SqlSelect(t interface{}, sqlStr string, args ...interface{}) (err error) {

	defer func() {
		if db != nil {
			baseDB, _ := db.SlaveDB.DB()
			defer baseDB.Close()
		}
	}()

	rt := reflect.TypeOf(t)
	fmt.Println(reflect.Array)
	fmt.Println(reflect.Slice)
	if rt.Kind() == reflect.Array || rt.Kind() == reflect.Slice {
		v := reflect.ValueOf(&t)
		e := v.Elem()
		nt := reflect.New(e.Type())
		rows, _ := db.SlaveDB.Raw(sqlStr, args...).Rows()
		for rows.Next() {
			db.SlaveDB.ScanRows(rows, &nt)
			reflect.Append(v, nt)
		}

	} else {
		tx := db.SlaveDB.Raw(sqlStr, args...).Scan(&t)

		db.PrintDBErrorLog(sqlStr, tx.Error, args...)
	}
	/*rows, err := db.SlaveDB.Raw(sqlStr, args...).Rows()
	for rows.Next() {
		db.SlaveDB.ScanRows(rows, &t)
	}*/

	return
}
func (db *GormSqlClient) SqlUpdateOrDelete(sqlStr string, args ...interface{}) (rowsAffected int64, err error) {

	defer func() {
		if db != nil {
			baseDB, _ := db.MasterDB.DB()
			defer baseDB.Close()
		}
	}()

	tx := db.MasterDB.Exec(sqlStr, args...)

	db.PrintDBErrorLog(sqlStr, tx.Error, args...)

	rowsAffected = tx.RowsAffected
	if tx.Error != nil {
		err = tx.Error
	}

	return
}
func (db *GormSqlClient) SqlInsert(sqlStr string, args ...interface{}) (rowsAffected, lastInsertId int64, err error) {

	defer func() {
		if db != nil {
			baseDB, _ := db.MasterDB.DB()
			defer baseDB.Close()
		}
	}()

	tx := db.MasterDB.Exec(sqlStr, args...)

	db.PrintDBErrorLog(sqlStr, tx.Error, args...)

	rowsAffected = tx.RowsAffected
	if tx.Error != nil {
		err = tx.Error
	}

	return
}

func PrintDBErrorLog(dbConnection common.DBConnection, sqlStr string, err error, args ...interface{}) {
	if err != nil {
		msg := fmt.Sprintf("sql error, dbConnection:%d, sqlStr:%s, args:%v, error msg:%v \n", dbConnection, sqlStr, args, err)
		fmt.Printf("%s\n", msg)
	}
}

func SqlSelect[T any](dbConnection common.DBConnection, sqlStr string, args ...interface{}) (t T, err error) {

	db := gormDB(dbConnection)

	PrintDBErrorLog(dbConnection, sqlStr, err, args...)

	tx := db.Raw(sqlStr, args...).Scan(&t)

	PrintDBErrorLog(dbConnection, sqlStr, tx.Error, args...)

	return
}

func SqlInsert(dbConnection common.DBConnection, sqlStr string, args ...interface{}) (rowsAffected, lastInsertId int64, err error) {

	db := gormDB(dbConnection)

	PrintDBErrorLog(dbConnection, sqlStr, err, args...)

	tx := db.Exec(sqlStr, args...)

	PrintDBErrorLog(dbConnection, sqlStr, tx.Error, args...)

	rowsAffected = tx.RowsAffected

	return
}

func SqlUpdateOrDelete(dbConnection common.DBConnection, sqlStr string, args ...interface{}) (rowsAffected int64, err error) {

	db := gormDB(dbConnection)

	PrintDBErrorLog(dbConnection, sqlStr, err, args...)

	tx := db.Exec(sqlStr, args...)

	PrintDBErrorLog(dbConnection, sqlStr, tx.Error, args...)

	rowsAffected = tx.RowsAffected

	return
}

func (db *GormSqlClient) SqlTransactionExecute(sqlStrArray []string, argsArray [][]interface{}) (err error) {

	return
}
