package redishelper

import (
	"fmt"
	"strings"
	"time"

	"github.com/garyburd/redigo/redis"
	"github.com/spf13/viper"
)

var pool *redis.Pool

//FunctionCode:RH1
func init() {
	pool = &redis.Pool{
		MaxIdle:     30,
		MaxActive:   1000,
		IdleTimeout: 240 * time.Second,
		Wait:        true,
		Dial: func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", viper.GetString("Redis.addr"))
			if err != nil {
				return nil, err
			}
			pw := viper.GetString("Redis.password")
			db := viper.GetInt32("Redis.DB")

			if len(pw) > 0 {
				if _, err := c.Do("AUTH", viper.GetString("Redis.password")); err != nil {
					c.Close()
					return nil, err
				}
			}

			if db != 0 {
				_, err := c.Do("SELECT", db)
				if err != nil {
					c.Close()
					return nil, err
				}
			}

			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			if time.Since(t) < time.Minute {
				return nil
			}
			_, err := c.Do("PING")
			return err
		},
	}
}

//FunctionCode:RH3
func SetRedisDataWithAcitiveSecond(key string, message string, activeSeconds int32) {
	conn := pool.Get()
	defer conn.Close()

	_, err := conn.Do("SET", key, message)
	if err != nil {
		fmt.Println("redis set failed:", err)
	}

	n, _ := conn.Do("EXPIRE", key, activeSeconds)
	if n != int64(1) {
		fmt.Println("redis set EXPIRE failed:", err)
	}
}

//FunctionCode:RH4
func SetKeyWithAcitiveMillisecond(key string, message string, activeMilliseconds int32) {
	conn := pool.Get()
	defer conn.Close()

	_, err := conn.Do("SET", key, message)
	if err != nil {
		fmt.Println("redis set failed:", err)
	}

	n, _ := conn.Do("PEXPIRE", key, activeMilliseconds)
	if n != int64(1) {
		fmt.Println("redis set EXPIRE failed:", err)
	}
}

//FunctionCode:RH5
func SetKey(key string, message string) {
	conn := pool.Get()
	defer conn.Close()

	_, err := conn.Do("SET", key, message)
	if err != nil {
		fmt.Println("redis set failed:", err)
	}
}

//FunctionCode:RH6
func GetKey(key string) string {
	conn := pool.Get()
	defer conn.Close()

	data, err := conn.Do("GET", key)

	if err != nil {
		fmt.Println("redis get failed:", err)
		return ""
	}
	if data == nil {
		return ""
	}

	fmt.Printf("Get mykey: %s \n", data)
	return string(data.([]byte))
}

//FunctionCode:RH7
func DeleteKey(key string) {
	conn := pool.Get()
	defer conn.Close()

	result, err := conn.Do("DEL", key)
	if err != nil {
		fmt.Println("redis delelte failed:", err)
	}
	fmt.Printf("redisKey:%s,result: %v \n", key, result)
}

//FunctionCode:RH8
func DeleteKeysByPrefix(prefix string) {
	iter, err := GetKeysByPrefix(prefix)
	if err != nil {
		fmt.Println("redis delelte failed:", err)
	}
	for i, fullkey := range iter {
		fmt.Println(i, fullkey)
		DeleteKey(fullkey)
	}
}

//FunctionCode:RH9
func GetKeysByPrefix(pattern string) ([]string, error) {
	pattern = strings.Replace(pattern, "*", "", -1)
	pattern = pattern + "*"
	conn := pool.Get()
	defer conn.Close()

	iter := 0
	keys := []string{}
	for {
		arr, err := redis.Values(conn.Do("SCAN", iter, "MATCH", pattern))
		if err != nil {
			return keys, fmt.Errorf("error retrieving '%s' keys", pattern)
		}

		iter, _ = redis.Int(arr[0], nil)
		k, _ := redis.Strings(arr[1], nil)
		keys = append(keys, k...)

		if iter == 0 {
			break
		}
	}

	return keys, nil
}

//FunctionCode:RH10
func FlushAll() {
	conn := pool.Get()
	defer conn.Close()

	conn.Send("FLUSHDB")
	conn.Flush()
	result, err := conn.Receive()
	if err != nil {
		fmt.Println("redis delelte failed:", err)
	}
	fmt.Printf("result: %s \n", result)
}

//FunctionCode:RH11
func GetKeysByPattern(pattern string) []string {
	conn := pool.Get()
	defer conn.Close()
	var list []string

	keys, err := redis.Strings(conn.Do("KEYS", pattern))

	if err != nil {
		fmt.Println("redis getKeys failed:", err)
	}

	for _, key := range keys {
		list = append(list, key)
	}
	return list
}

//FunctionCode:RH12
func IsExistKey(key string) (isKeyExist bool) {

	conn := pool.Get()
	defer conn.Close()

	isKeyExist, err := redis.Bool(conn.Do("EXISTS", key))
	if err != nil {
		fmt.Println("Redis EXISTS Key:", key, " Error:", err)
		isKeyExist = false
	}

	return

}
