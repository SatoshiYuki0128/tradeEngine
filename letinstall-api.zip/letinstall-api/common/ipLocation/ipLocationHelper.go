package iplocationhelper

import (
	"encoding/json"
	"fmt"
	"letsinstallapi/common"
)

type IpLocatonResponse struct {
	Data IpLocaton `json:"data"`
}
type IpLocaton struct {
	Country  string `json:"country"`
	TimeZone string `json:"timezone"`
}

func GetIpLocaton(ip string) (ipLocaton IpLocaton, err error) {
	url := fmt.Sprintf("http://35.201.162.162/common-api/GeoIP/GetIpInfo?ip=%s", ip)
	body, err := common.APIGET(url, nil, nil)
	if err != nil {
		return
	}
	temp := IpLocatonResponse{}
	json.Unmarshal(body, &temp)

	ipLocaton = temp.Data
	return
}
