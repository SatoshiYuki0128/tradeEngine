package applistcontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	applistservice "letsinstallapi/services/appList"
	"net/http"
)

// @Summary App列表-查詢列表[AL1]
// @Tags ( /admin-api ) AppList
// @version 1.0
// @produce application/json
// @param cid header string true "cid ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.AppListReq true "test""
// @Success 200 {object} models.Doc_GetAppRM
// @Router /v2/App/GetApp [post]
func PostApplist(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.PostAppReq](r, &flowData, "AL1") {
		applistservice.GetAppList(&flowData, "AL1")
	}
	services.ServeResponse(w, &flowData)
}

// @Summary App列表-增刪修[AL2]
// @Tags ( /admin-api ) AppList
// @version 1.0
// @produce application/json
// @param cid header string true "cid ex:cc85usd94816e39c4pq0#1662017393"
// @Param param body models.Doc_AppModel true "test""
// @Success 200 {object} models.Doc_AppModel
// @Router /v2/App/EditApp [put]
func EditApplist(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.EditAppListReq](r, &flowData, "AL2") {
		applistservice.EditAppList(&flowData, "AL2")
	}
	services.ServeResponse(w, &flowData)
}
