package appchannelcontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	appchannelservice "letsinstallapi/services/appChannel"
	"net/http"
)

// @Summary 渠道管理-查詢列表 [AC1]
// @Tags ( /admin-api ) AppChannel
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostAppChannelReq true "test""
// @Success 200 {object} models.Doc_GetAppChannelRM
// @Router /v2/AppChannel/GetAppChannel [post]
func PostAppchannel(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetAppChannelRequest](r, &flowData, "AC1") {
		appchannelservice.GetAppChannelList(&flowData, "AC1")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 渠道管理-增刪修 [AC2]
// @Tags ( /admin-api ) AppChannel
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_AppChannelModel true "test""
// @Success 200 {object} models.Doc_AppChannelModel
// @Router /v2/AppChannel/PutAppChannel [put]
func PutAppChannel(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.UpdateAppChannelRequest](r, &flowData, "AC2") {
		appchannelservice.UpdateAppChannel(&flowData, "AC2")
	}

	services.ServeResponse(w, &flowData)
}
