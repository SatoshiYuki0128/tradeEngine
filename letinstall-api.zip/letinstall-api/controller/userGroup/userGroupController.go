package groupController

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	groupService "letsinstallapi/services/userGroup"
	"net/http"
)

// @Summary 群組管理-推廣網址
// @Tags ( /admin-api ) Group
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證  cc8slgqvbnoaafaabfig#1662110403"
// @param keepdays query int false "可用天數：-1:不限期"
// @Success 200 {object} models.Doc_StringRM
// @Router /v2/Group/promoCode [get]
func GetPromoCode(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetPromoCode](r, &flowData, "GS1") {
		groupService.GetPromoCode(&flowData, "GS1")
	}
	services.ServeResponse(w, &flowData)
}

// @Summary 群組管理-查詢列表
// @Tags ( /admin-api ) Group
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostUserGroupReq true "test""
// @Success 200 {object} models.Doc_GetUserGroupRM
// @Router /v2/Group/userGroup [post]
func GetUserGroup(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetUserGroup](r, &flowData, "GS2") {
		groupService.GetUserGroup(&flowData, "GS2")
	}
	services.ServeResponse(w, &flowData)
}

// @Summary 群組管理-增刪修
// @Tags ( /admin-api ) Group
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_UserGroupModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/Group/userGroup [put]
func EditUserGroup(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.EditUserGroup](r, &flowData, "GS3") {
		groupService.EditUserGroup(&flowData, "GS3")
	}
	services.ServeResponse(w, &flowData)
}
