package controller

import (
	"net/http"
)

// @Summary 存活檢查
// @Tags Health
// @version 1.0
// @produce text/html
// @Success 200  "<html><body>200 OK</body></html>"
// @Router /Health/health [get]
func HealthCheck(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html")
	w.Write([]byte("<html><body>200 OK</body></html>"))
}
