package sdkcontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	sdkservice "letsinstallapi/services/SDK"
	"net/http"
)

// @Summary Step1.蒐集資料API (for業主落地頁)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) SDK
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} models.AgentDeviceInfoRM
// @Router /v2/SDK/AgentDeviceInfo [put]
func AgentDeviceInfo(w http.ResponseWriter, r *http.Request) {
	_ServiceCode := "SDK1"
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_RequestRSA](r, &flowData, _ServiceCode) {
		sdkservice.SetDownload(&flowData, _ServiceCode)
	}
	services.ServeResponse(w, &flowData)
}

// @Summary Step2.標記已下載API (for業主落地頁)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) SDK
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} bool
// @Router /v2/SDK/setDownload [put]
func AgentDevice_setDownload(w http.ResponseWriter, r *http.Request) {
	_controllerCode := "SDK2"
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_RequestSDK](r, &flowData, _controllerCode) {
		sdkservice.SetDownload(&flowData, _controllerCode)
	}
	services.ServeResponse(w, &flowData)
}

// @Summary Step3.比對資料API (for App應用)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) SDK
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} models.AgentDeviceInfoRM
// @Router /v2/SDK/AgentDevice_1st [post]
func AgentDevice_1st(w http.ResponseWriter, r *http.Request) {
	_ServiceCode := "SDK3"
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_RequestRSA](r, &flowData, _ServiceCode) {
		sdkservice.SetDownload(&flowData, _ServiceCode)
	}
	services.ServeResponse(w, &flowData)
}
