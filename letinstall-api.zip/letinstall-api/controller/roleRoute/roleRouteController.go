package roleroutecontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	rolerouteservice "letsinstallapi/services/roleRoute"
	"net/http"
)

// @Summary 角色功能-查詢列表 [RR1]
// @Tags ( /admin-api ) RoleRoute
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Success 200 {object} models.Doc_GetRoleRouteRM
// @Router /v2/RoleRoute/GetRoleRoute [post]
func GetRoleRoute(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_UserLoginModel](r, &flowData, "RR1") {
		rolerouteservice.GetRoleRoute(&flowData, "RR1")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 角色功能-增刪修 [RR2]
// @Tags ( /admin-api ) RoleRoute
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_RoleRouteReq true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/RoleRoute/PutRoleRoute [put]
func PutRoleRoute(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.PutRoleRouteRequest](r, &flowData, "RR2") {
		rolerouteservice.PutRoleRoute(&flowData, "RR2")
	}

	services.ServeResponse(w, &flowData)
}
