package registercontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	registerservice "letsinstallapi/services/register"
	"net/http"
)

// @Summary 取得使用者權限[ARG1]
// @Tags ( /admin-api ) LetsInstall-Register
// @version 1.0
// @produce application/json
// @param jwt header string false "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjc4IiwiZXhwIjoxNjU5OTI5Mzg3LCJpc3MiOiJQSUQifQ.mb6crJhka3wUlzim7E1QjPUsQiHeqbHKIEmikoZ9fqI"
// @Success 200 {object} int
// @Router /cxbb/Register/getRoleRoute [get]
func GetRoleRoute(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.RoleRouteRequest](r, &flowData, "RG6") {
		registerservice.GetRoleRoute(&flowData, "RG6")
	}

	services.ServeResponse(w, &flowData)
}
