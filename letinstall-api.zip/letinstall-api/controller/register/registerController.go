package registercontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	registerservice "letsinstallapi/services/register"
	"net/http"
)

// @Summary OTPCode檢查[RG1]
// @Tags ( /api ) LetsInstall-Register
// @version 1.0
// @produce application/json
// @Param param body models.OTPCheckRequest true "test""
// @Success 200 {object} models.ExternalResponse
// @Router /cxbb/Register/OtpCheck [post]
func PostOtpcheck(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.OTPCheckRequest](r, &flowData, "RG1") {
		registerservice.CheckOTPCode(&flowData, "RG1")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 帳號註冊 [RG1]
// @Tags ( /admin-api ) Register
// @version 1.0
// @produce application/json
// @param promotionCode header string false "推廣碼 ex:3XFN11R8PIOI"
// @Param param body models.Doc_RegisterModel true "test""
// @Success 200 {object} models.Doc_RegisterUserRM
// @Router /v2/GuestWeb/RegisterUser [put]
func RegisterUser(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.RegisterUserRequest](r, &flowData, "RG1") {
		registerservice.RegisterUser(&flowData, "RG1")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 帳號登入 [RG2]
// @Tags ( /guest-api ) Register
// @version 1.0
// @produce application/json
// @Param param body models.Doc_UserLoginReq true "test""
// @Success 200 {object} models.Doc_UserLoginRM
// @Router /v2/GuestWeb/Login [post]
func UserLogin(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_UserLoginReq](r, &flowData, "RG2") {
		registerservice.UserLogin(&flowData, "RG2")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 忘記密碼[RG3]
// @Tags ( /guest-api ) Register
// @version 1.0
// @produce application/json
// @Param param body models.ForgetPasswordRequest true "test""
// @Success 200 {object} models.ExternalResponse
// @Router /v2/GuestWeb/ForgetPassword [put]
func PutForgetpassword(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.ForgetPasswordRequest](r, &flowData, "RG3") {
		registerservice.ForgetPassword(&flowData, "RG3")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 取得驗證碼[RG4]
// @Tags ( /guest-api ) Register
// @version 1.0
// @produce application/json
// @Param param body models.GetVerifyCodeRequest true "test""
// @Success 200 {object} models.ExternalResponse
// @Router /v2/GuestWeb/GetVerifyCode [post]
func PutGetverifycode(w http.ResponseWriter, r *http.Request) {

	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetVerifyCodeRequest](r, &flowData, "RG4") {
		registerservice.GetVerifyCode(&flowData, "RG4")
	}

	services.ServeResponse(w, &flowData)
}
