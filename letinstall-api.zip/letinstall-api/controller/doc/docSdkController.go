package doccontroller

import (
	"encoding/json"
	"fmt"
	"letsinstallapi/models"
	"net/http"
	//go get github.com/rs/xid
)

// @Summary Step1.蒐集資料API (for業主落地頁)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} models.Doc_AgentDeviceInfoRM
// @Router /ApiDoc/SDK/AgentDeviceInfo [put]
func Doc_AgentDeviceInfo(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := new(models.Doc_AgentDeviceInfoRM)
	var errResponse models.ExternalErrorResponse

	//主表-Model，有刪除、新增欄位，可看model結構
	var dbModel models.AgentDevice_1stDB
	fmt.Printf("主表-Model：%d", dbModel.Id)

	//copy from yaboapi-v2
	// @Router /cxbb/AgentChannel/AgentDeviceInfo [put]
	// -- AgentDevice_1st表.新增欄位：country_xff'國家-外網IP'
	// -- AgentDevice_1st表.刪除欄位：promotionCode'推廣碼'

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary Step2.標記已下載API (for業主落地頁)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} bool
// @Router /ApiDoc/SDK/setDownload [put]
func Doc_AgentDevice_setDownload(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := new(models.Doc_BoolRM)
	var errResponse models.ExternalErrorResponse

	//copy from yaboapi-v2
	// @Router /api/cxbb/AgentChannel/setDownload [put]

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary Step3.比對資料API (for App應用)...複製yaboapi-v2原邏輯
// @Tags ( /sdk-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param token header string false "OwnerUser.UserKey"
// @Param param body models.Doc_RequestRSA true "test"
// @Success 200 {object} models.Doc_AgentDeviceInfoRM
// @Router /ApiDoc/SDK/AgentDevice_1st [post]
func Doc_AgentDevice_1st(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := new(models.Doc_AgentDeviceInfoRM)
	var errResponse models.ExternalErrorResponse

	//主表-Model，有刪除、新增欄位，可看model結構
	var dbModel models.AgentDevice_1stDB
	fmt.Printf("主表-Model：%d", dbModel.Id)

	// 表二抽離部分欄位至此表
	var resultModel models.AgentDevice_ResultModel
	fmt.Printf("比對結果表-Model：%d", resultModel.Id)

	//copy from yaboapi-v2
	// @Router /cxbb/AgentChannel/AgentDevice_1st [post]
	// -- AgentDevice_1st表.新增欄位：country_xff'國家-外網IP'
	// -- AgentDevice_1st表.刪除欄位：promotionCode'推廣碼'

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}
