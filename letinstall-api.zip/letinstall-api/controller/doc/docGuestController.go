package doccontroller

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/models"
	"net/http"
	"strings"
	"time"
	//go get github.com/rs/xid
)

// @Summary 帳號註冊 20220829
// @Tags ( /guest-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param code header string false "eyJ1a2V5IjoiNVA0TFA4QjVCNExSIiwiZ2tleSI6IkYyQUVWRlIyIn0="
// @Param param body models.Doc_RegisterModel true "test""
// @Success 200 {object} models.Doc_RegisterUserRM
// @Router /ApiDoc/GuestWeb/RegisterUser [put]
func Doc_RegisterUser(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := new(models.Doc_RegisterUserRM)

	//20220901 arvin modify *******
	// headerGroupKey := r.Header.Get("GroupKey")
	code := r.Header.Get("code")
	codeJosn := Doc_Decode_AES(code)
	codeModel := new(models.Doc_PromoKeyModel)
	json.Unmarshal([]byte(codeJosn), &codeModel)
	nowTimeUnix := timehelper.GetUTCTime().Unix()
	if codeModel.ActiveTime > 0 && nowTimeUnix >= codeModel.ActiveTime {
		// 推廣碼過期
		return
	}
	headerGroupKey := codeModel.GroupKey
	//20220901 arvin modify *******

	/*=== service ==================================*/
	var req models.Doc_RegisterModel
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
		return
	}
	err = json.Unmarshal(body, &req) //轉為json
	if err != nil {
		fmt.Println(err) // "物件反序列錯誤"
		return
	}

	var errResponse models.ExternalErrorResponse

	parentGroup := models.Doc_UserGroupRoleModel{}

	req_NowTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	isCreateNewGroup := false
	if headerGroupKey == "" {
		headerGroupKey = "GCVQBRB5" //常規app初始key (設定在config)
	}

	/* ****** headerGroupKey 有值  ********* */
	// GroupKey驗證
	/*
				-- 查詢parentGroup ... get parentUserGroup、parentUserKey
		select UG.id,UG.groupKey,UG.groupName, OU.userKey as userKey,R.id as adminRoleID
		from OwnerUser as OU
		inner join Role as R on R.id=OU.roleID
		inner join UserGroup as UG on UG.groupKey=R.groupKey
		where R.roleName = 'admin' and R.groupKey='F2AEVFR2' and OU.isEnable=1 limit 1
	*/
	parentGroup.Id = 999 //debug
	// 查詢DB by SQL
	if parentGroup.Id == 0 { //groupExisted := true
		//驗證失敗，報錯並回傳
		fmt.Println("groupKey驗證錯誤 return")
		return
	} else {
		isCreateNewGroup = true
	}

	// Insert UserGroup
	if isCreateNewGroup {
		newGroup := models.Doc_UserGroupModel{}
		newGroup.GroupKey = "12345678"            //string(uuid.New())    //"12345678"            // 唯一鍵生成：8碼
		newGroup.ParentKey = parentGroup.GroupKey // 從parentGroup取得
		newGroup.UserKey = parentGroup.UserKey    // 從parentGroup取得

		_parentGroupName := "tempGroupName"
		if req.GroupName == "" { // 可不填
			if parentGroup.GroupName != "" {
				_parentGroupName = strings.Replace(parentGroup.GroupName, "_sub", "", -1)
			}
		} else {
			_parentGroupName = strings.Replace(req.GroupName, "_sub", "", -1)
		}
		newGroup.GroupName = _parentGroupName + "_sub"

		newGroup.CreateTime = req_NowTime
		newGroup.CreateUser = parentGroup.UserKey
		newGroup.UpdateTime = req_NowTime
		newGroup.UpdateUser = parentGroup.UserKey
		// ........Insert UserGroup , get newUserGroup.groupKey
		newGroup.GroupKey = "12345678" // 唯一鍵生成：8碼

		req.GroupName = _parentGroupName

		/* ========== */
		// Insert Role(3)  admin  owner  user
		newRole1 := models.Doc_RoleModel{}
		newRole1.GroupKey = newGroup.GroupKey
		newRole1.RoleLevel = 1
		newRole1.RoleName = "admin"
		newRole1.CreateTime = req_NowTime
		newRole1.CreateUser = parentGroup.UserKey
		newRole1.UpdateTime = req_NowTime
		newRole1.UpdateUser = parentGroup.UserKey
		// ........Insert Role , get newRoleID
		newRole1.Id = 1111
		parentGroup.AdminRoleID = newRole1.Id
		/* ========== */
		newRole2 := models.Doc_RoleModel{}
		newRole2.GroupKey = newGroup.GroupKey
		newRole2.RoleLevel = 2
		newRole2.RoleName = "owner"
		newRole2.CreateTime = req_NowTime
		newRole2.CreateUser = parentGroup.UserKey
		newRole2.UpdateTime = req_NowTime
		newRole2.UpdateUser = parentGroup.UserKey
		// ........Insert Role , get newRoleID
		newRole2.Id = 2222
		/* ========== */
		newRole3 := models.Doc_RoleModel{}
		newRole3.GroupKey = newGroup.GroupKey
		newRole3.RoleLevel = 3
		newRole3.RoleName = "user"
		newRole3.CreateTime = req_NowTime
		newRole3.CreateUser = parentGroup.UserKey
		newRole3.UpdateTime = req_NowTime
		newRole3.UpdateUser = parentGroup.UserKey
		// ........Insert Role , get newRoleID
		newRole3.Id = 3333
	}

	// Insert OwnerUser
	newUser := models.Doc_OwnerUserModel{}
	newUser.UserKey = "123456789012" // 唯一鍵生成：12碼
	newUser.RoleID = parentGroup.AdminRoleID
	newUser.RoleName = "admin"
	newUser.UserName = req.Account
	newUser.Account = req.Account
	newUser.Pwd = Doc_Encode_AES(Doc_Decode_Base64(req.Pwd)) //AES
	newUser.IsEnable = 1
	newUser.VipLevel = 1
	newUser.LastloginIP = GetRequestIP(r)
	newUser.Phone = req.Phone
	newUser.CreateTime = req_NowTime
	newUser.CreateUser = parentGroup.UserKey
	newUser.UpdateTime = req_NowTime
	newUser.UpdateUser = parentGroup.UserKey
	// ........Insert OwnerUser, get newUserID
	newUser.Id = 99
	req.Id = newUser.Id
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if req.Id > 0 {
			rm.ErrorCode = "00"
			rm.Data = req
		} else {
			rm.ErrorCode = "01"
			// rm.Data = false
		}
		response, _ = json.Marshal(rm)
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 帳號登入 20220830
// @Tags ( /guest-api ) ApiDoc
// @version 1.0
// @produce application/json
// @Param param body models.Doc_UserLoginReq true "test""
// @Success 200 {object} models.Doc_UserLoginRM
// @Router /ApiDoc/GuestWeb/Login [post]
func Doc_Login(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := models.Doc_UserLoginRM{}

	req := new(models.Doc_UserLoginReq)
	req.Pwd = Doc_Encode_AES(Doc_Decode_Base64(req.Pwd)) //AES
	fmt.Printf("select * from OwnerUser where account='%s' and pwd='%s' limit 1; \n", req.Account, req.Pwd)

	loginuser := models.Doc_OwnerUserModel{Id: 2}
	if loginuser.Id > 0 {
		loginuser.Cid = fmt.Sprintf("%s#%d", GenerateLogKey(), time.Now().Unix())
		loginuser.LastloginIP = GetRequestIP(r)
		loginuser.LastloginTime = timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
		fmt.Printf("UPDATE OwnerUser SET lastloginIP='%s',lastloginTime='%v',cid='%s' where id=%d   \n",
			loginuser.LastloginIP, loginuser.LastloginTime, loginuser.Cid, loginuser.Id)
	}
	rm.Data.Cid = loginuser.Cid

	userKey, groupKey, _ := Doc_GetGroupKeyByCid(rm.Data.Cid)
	if userKey != "" && groupKey != "" {
		cidInfo := models.Doc_OwnerUserCidsModel{}
		cidInfo.UserKey = userKey
		cidInfo.GroupKey = groupKey
		cidInfo.LastloginIP = GetRequestIP(r)
		cidInfo.LastloginTime = timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
		cidInfo.Cid = rm.Data.Cid
		fmt.Println("INSERT INTO `OwnerUserCids`(`id`, `userKey`, `groupKey`, `lastloginTime`, `lastloginIP`, `cid`) VALUES (1, '5P4LP8B5B4LR', 'F2AEVFR2', '2022-08-30 16:32:10', '127.0.0.1', 'cc6r7hjd0cvmdcrecm0g#1661842374');")
	}
	response, _ = json.Marshal(rm)
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}
