package doccontroller

import (
	"bytes"
	"crypto/des"
	"encoding/hex"
	"fmt"
	aeshelper "letsinstallapi/common/aes"
	base64helper "letsinstallapi/common/base64"
	"net/http"
	"strings"

	"github.com/rs/xid"
	//go get github.com/rs/xid
)

func SetPasswordMask(pwd string) string {
	rs := []rune(pwd)
	for i := 0; i < len(rs); i++ {
		rs[i] = '*'
	}
	return string(rs)
}

func GenerateLogKey() string {
	return xid.New().String()
}

func Doc_Encode_Base64(str string) string {
	return base64helper.Base64Encode(str)
}

func Doc_Decode_Base64(str string) string {
	return base64helper.Base64Decode(str)
}

func GetRequestIP(r *http.Request) string {
	reqIP := strings.TrimSpace(strings.Split(r.Header.Get("X-Forwarded-For"), ",")[0])
	if reqIP == "" {
		reqIP = "111.235.135.58"
	}
	return reqIP
}

const key_DESECB = "TAuiAHio" //key的长度必须都是8位

// Go DES ECB加密
func Doc_Encode_DESECB(src string) string {
	key := key_DESECB
	data := []byte(src)
	keyByte := []byte(key)
	block, err := des.NewCipher(keyByte)
	if err != nil {
		panic(err)
	}
	bs := block.BlockSize()
	//对明文数据进行补码
	data = pkcs5Padding(data, bs)
	if len(data)%bs != 0 {
		panic("Need a multiple of the blocksize")
	}
	out := make([]byte, len(data))
	dst := out
	for len(data) > 0 {
		//对明文按照blocksize进行分块加密
		//必要时可以使用go关键字进行并行加密
		block.Encrypt(dst, data[:bs])
		data = data[bs:]
		dst = dst[bs:]
	}
	return fmt.Sprintf("%X", out)
}

// Go DES ECB解密
func Doc_Decode_DESECB(src string) string {
	key := key_DESECB
	data, err := hex.DecodeString(src)
	if err != nil {
		panic(err)
	}
	keyByte := []byte(key)
	block, err := des.NewCipher(keyByte)
	if err != nil {
		panic(err)
	}
	bs := block.BlockSize()
	if len(data)%bs != 0 {
		panic("crypto/cipher: input not full blocks")
	}
	out := make([]byte, len(data))
	dst := out
	for len(data) > 0 {
		block.Decrypt(dst, data[:bs])
		data = data[bs:]
		dst = dst[bs:]
	}
	out = pkcs5UnPadding(out)
	return string(out)
}
func pkcs5Padding(ciphertext []byte, blockSize int) []byte {
	//明文补码算法
	padding := blockSize - len(ciphertext)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}
func pkcs5UnPadding(origData []byte) []byte {
	//明文减码算法
	length := len(origData)
	unpadding := int(origData[length-1])
	return origData[:(length - unpadding)]
}

func Doc_Decode_AES(src string) string {
	return aeshelper.AesDecryptCBC(src, aeshelper.AES128Key)
}
func Doc_Encode_AES(src string) string {
	return aeshelper.AesEncryptCBC(src, aeshelper.AES128Key)
}

func Doc_ExecSQL_Insert(sql string) int64 {
	var primaryKey_id int64 = 999
	return primaryKey_id
}

func Doc_ExecSQL_Update(sql string) int64 {
	var effectRowsCount int64 = 1
	return effectRowsCount
}
