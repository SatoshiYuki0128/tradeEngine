package doccontroller

import (
	"encoding/json"
	"fmt"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/models"
	"net/http"
	"strconv"
	"strings"
	//go get github.com/rs/xid
)

/*********** 修改歷程 *****************************************************/
// Arvin modify on 2022-08-25 14:26 ............. @Router /ApiDoc/App/GetApp [post]
// Arvin modify on 2022-08-30 15:40 ............. All router，加入cid驗證
/*********** 修改歷程 *****************************************************/

func Doc_GetGroupKeyByCid(cid string) (userKey string, groupKey string, roleID string) {
	fmt.Printf("Select R.id as roleID,R.groupKey,OU.userKey	from OwnerUser as OU inner join Role as R on R.id=OU.roleID	where OU.cid='%s' \n", cid)
	userKey = "sqlSelect.userKey"
	groupKey = "sqlSelect.groupKey"
	roleID = "sqlSelect.roleID"
	// userKey ,groupKey :=GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	// if userKey == "" || groupKey==""{
	// 	//驗證失敗，前端導回首頁
	// 	return
	// }
	if cid == "cc6r7hjd0cvmdcrecm0g#1661842374" {
		userKey = "5P4LP8B5B4LR"
		groupKey = "F2AEVFR2"
	}
	return
}

/*===== AppChannel ========================================================================*/
// @Summary 渠道管理-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostAppChannelReq true "test""
// @Success 200 {object} models.Doc_GetAppChannelRM
// @Router /ApiDoc/AppChannel/GetAppChannel [post]
func Doc_GetAppChannel(w http.ResponseWriter, r *http.Request) {
	var response []byte
	cid := "cc6r7hjd0cvmdcrecm0g#1661842374" //r.Header.Get("cid")
	_appKey := r.Header.Get("appkey")
	rm := new(models.Doc_GetAppChannelRM)

	/*=== service ==================================*/
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	_userKey, _groupKey, _ := Doc_GetGroupKeyByCid(cid)
	if _userKey == "" || _groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	// "GCVQBRB5" 從config取
	if _groupKey == "GCVQBRB5" {
		fmt.Printf("select AC.* from AppChannel as AC where AC.appKey ='%s' ", _appKey)
	} else {
		fmt.Printf("select AC.* from AppChannel as AC where AC.groupKey ='%s'", _groupKey)
	}

	/*
				-- 渠道管理-List- Step.2  --
				select AC.* from AppChannel as AC where AC.groupKey ='F2AEVFR2'

				select AC.* from AppChannel as AC where AC.groupKey ='F2AEVFR2'

		select AC.* from AppChannel as AC where AC.groupKey ='GCVQBRB5' and AC.appKey ='AK-954F2900824D'
	*/
	req := models.Doc_PostAppChannelReq{}
	data := models.Doc_AppChannelModel{}
	dataList := []models.Doc_AppChannelModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalResponse
	req.OrderBy.OrderType = strings.ToUpper(req.OrderBy.OrderType)
	// services.ColumnCheck_String()

	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 渠道管理-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_AppChannelModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/AppChannel/PutAppChannel [put]
func Doc_PutAppChannel(w http.ResponseWriter, r *http.Request) {
	var response []byte
	/*=== service ==================================*/
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	data := models.Doc_AppChannelModel{}
	var errResponse models.ExternalResponse
	data.ChannelID = 999
	// update AppChannel set [columnName]=[columnValue] where id={req.channelID}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

/*===== App ========================================================================*/
// @Summary App列表-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.PostAppReq true "test""
// @Success 200 {object} models.Doc_GetAppRM
// @Router /ApiDoc/App/GetApp [post]
func Doc_GetApp(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	rm := new(models.Doc_GetAppRM)

	/*=== service ==================================*/
	/*
		-- App-List- Step.2  --
		// ********* Arvin modify on 2022-08-25 14:26 *********
		select AP.* ,(case when UG.groupKey='F2AEVFR2' then 0 else 1 end) as Seq
		from App as AP
		inner join UserGroup as UG on UG.groupKey=AP.groupKey
		where (UG.groupKey ='F2AEVFR2' or UG.parentKey='F2AEVFR2')
		order by Seq
	*/
	req := models.PostAppReq{}
	data := models.Doc_AppModel{}
	dataList := []models.Doc_AppModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalResponse
	req.OrderBy.OrderType = strings.ToUpper(req.OrderBy.OrderType)
	// services.ColumnCheck_String()

	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary App列表-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_AppModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/App/PutApp [put]
func Doc_PutApp(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	/*=== service ==================================*/
	data := models.Doc_AppModel{}
	var errResponse models.ExternalResponse
	data.Id = 999
	// update App set [columnName]=[columnValue] where id={req.id}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

/*===== UserGroup ========================================================================*/
// @Summary 群組管理-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostUserGroupReq true "test""
// @Success 200 {object} models.Doc_GetUserGroupRM
// @Router /ApiDoc/UserGroup/GetUserGroup [post]
func Doc_GetUserGroup(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	rm := new(models.Doc_GetUserGroupRM)

	/*=== service ==================================*/
	/*
		-- 群組管理-List- Step.2  --
		select * from UserGroup as UG where (UG.groupKey ='YV45X8P8' or UG.parentKey='YV45X8P8')
	*/
	req := models.Doc_PostUserGroupReq{}
	data := models.Doc_UserGroupModel{}
	dataList := []models.Doc_UserGroupModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalResponse
	req.OrderBy.OrderType = strings.ToUpper(req.OrderBy.OrderType)
	// services.ColumnCheck_String()

	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 群組管理-推廣網址
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證  cc6r7hjd0cvmdcrecm0g#1661842374"
// @param keepdays query int false "可用天數：-1:不限期"
// @Success 200 {object} models.Doc_StringRM
// @Router /ApiDoc/UserGroup/GetPromoURL [get]
func Doc_GetPromoURL_UserGroup(w http.ResponseWriter, r *http.Request) {
	var response []byte
	rm := new(models.Doc_StringRM)

	/*=== service ==================================*/
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	keepdays := r.URL.Query().Get("keepdays")
	_keepdays, err := strconv.Atoi(keepdays)
	if err != nil || _keepdays < 1 {
		_keepdays = 0
	}

	var errResponse models.ExternalResponse

	promo := new(models.Doc_PromoKeyModel)
	promo.GroupKey = groupKey
	promo.UserKey = userKey
	if _keepdays > 0 {
		promo.ActiveTime = timehelper.GetUTCTime().AddDate(0, 0, _keepdays).Unix()
	}
	jsonValue, _ := json.Marshal(promo)
	enCode := Doc_Encode_AES(string(jsonValue))
	promoURL := fmt.Sprintf("https://qa.letsinstall.io/?code=%s", enCode)

	deCode := Doc_Decode_AES(enCode)
	fmt.Println(deCode)

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		rm.ErrorCode = "00"

		rm.Data = promoURL
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 群組管理-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_UserGroupModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/UserGroup/PutUserGroup [put]
func Doc_PutUserGroup(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	/*=== service ==================================*/
	data := models.Doc_UserGroupModel{}
	var errResponse models.ExternalResponse
	data.Id = 999
	// update UserGroup set [columnName]=[columnValue] where id={req.id}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

/*===== OwnerUser ========================================================================*/
// @Summary 帳號維護-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:  cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostOwnerUserReq true "test""
// @Success 200 {object} models.Doc_GetOwnerUserRM
// @Router /ApiDoc/OwnerUser/GetOwnerUser [post]
func Doc_GetOwnerUser(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	rm := new(models.Doc_GetOwnerUserRM)

	/*=== service ==================================*/
	req := models.Doc_PostOwnerUserReq{}
	data := models.Doc_OwnerUserModel{}

	selectSQL := "select AC.* from OwnerUser as AC where AC.groupKey ='F2AEVFR2' "
	if req.Where.Cid != "" {
		selectSQL += fmt.Sprintf(" and cid='%s'", req.Where.Cid)
		// ...
		// ...
	}
	dataList := []models.Doc_OwnerUserModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalErrorResponse
	req.OrderBy.OrderType = strings.ToUpper(req.OrderBy.OrderType)
	// services.ColumnCheck_String()
	// for i := 0; i < len(dataList); i++ {
	// 	dataList[i].UserToken = Doc_Encode_AES(dataList[i].UserKey)
	// }
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 帳號維護-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_OwnerUserModel true "test"
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/OwnerUser/ownerUser [put]
func Doc_PutOwnerUser(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	/*=== service ==================================*/
	req := models.Doc_OwnerUserModel{}
	req.Pwd = Doc_Encode_AES(Doc_Decode_Base64(req.Pwd))
	var errResponse models.ExternalErrorResponse
	req.Id = 999
	// update OwnerUser set [columnName]=[columnValue] where id={req.id}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 帳號維護-個人資訊修改(修改密碼)
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_ReSetPasswordReq true "test"
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/OwnerUser/ReSetPassword [put]
func Doc_ReSetPassword(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "edit"
	rm.Data.Status = true

	/*=== service ==================================*/
	var req models.Doc_ReSetPasswordReq
	var errResponse models.ExternalErrorResponse

	var effectRowsCount int64 = 0
	if userKey != "" {
		req.Pwd = Doc_Encode_AES(Doc_Decode_Base64(req.Pwd))
		req.NewPwd = Doc_Encode_AES(Doc_Decode_Base64(req.NewPwd))

		effectRowsCount = Doc_ExecSQL_Update(fmt.Sprintf("update OwnerUser set Pwd='%s' where userKey='%s' and Pwd='%s'; \n", req.NewPwd, userKey, req.Pwd))
		rm.Data.Status = (effectRowsCount > 0) //success
	}
	if effectRowsCount == 0 {
		//密碼重設失敗
		rm.Data.Status = false
		rm.ErrorMessage = "密碼重設失敗"
		rm.ErrorCode = "???"
	} else {
		rm.Data.Status = true
	}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

/*===== Role ========================================================================*/
// @Summary 角色-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostRoleReq true "test""
// @Success 200 {object} models.Doc_GetRoleRM
// @Router /ApiDoc/Role/GetRole [post]
func Doc_GetRole(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	rm := new(models.Doc_GetRoleRM)

	/*=== service ==================================*/
	/*
		-- 角色-List- Step.2  --
		select * from Role as RL where RL.groupKey ='YV45X8P8'
	*/
	req := models.Doc_PostRoleReq{}
	data := models.Doc_RoleModel{}
	dataList := []models.Doc_RoleModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalResponse
	req.OrderBy.OrderType = strings.ToUpper(req.OrderBy.OrderType)
	// services.ColumnCheck_String()

	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 角色-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_RoleModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/Role/PutRole [put]
func Doc_PutRole(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, _ := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	/*=== service ==================================*/
	data := models.Doc_RoleModel{}
	var errResponse models.ExternalResponse
	data.Id = 999
	// update Role set [columnName]=[columnValue] where id={req.id}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

/*===== RoleRoute ========================================================================*/
// @Summary 角色功能-查詢列表
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Success 200 {object} models.Doc_GetRoleRouteRM
// @Router /ApiDoc/RoleRoute/GetRoleRoute [post]
func Doc_GetRoleRoute(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, roleID := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" || roleID == "0" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}

	rm := new(models.Doc_GetRoleRouteRM)

	/*=== service ==================================*/
	data := models.Doc_RoleRouteModel{}
	dataList := []models.Doc_RoleRouteModel{}
	dataList = append(dataList, data)
	var errResponse models.ExternalErrorResponse
	fmt.Printf("select RR.* from RoleRoute as RR where RR.roleID=%s", roleID)

	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		if len(dataList) > 0 {
			rm.ErrorCode = "00"
		} else {
			rm.ErrorCode = "01"
		}
		rm.Data = dataList
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

// @Summary 角色功能-增刪修
// @Tags ( /admin-api ) ApiDoc
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_RoleRouteReq true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /ApiDoc/RoleRoute/PutRoleRoute [put]
func Doc_PutRoleRoute(w http.ResponseWriter, r *http.Request) {
	var response []byte
	// -- User驗證 Step.1 使用cid查詢出該使用者的登入狀態是否有效，並取回userKey及groupKey
	userKey, groupKey, roleID := Doc_GetGroupKeyByCid("cc6r7hjd0cvmdcrecm0g#1661842374")
	if userKey == "" || groupKey == "" || roleID == "0" {
		//驗證失敗，回傳登入無效錯誤代碼，前端導回首頁
		return
	}
	rm := models.Doc_PutResponseRM{}
	rm.Data.Action = "add"
	rm.Data.Status = true

	/*=== service ==================================*/
	req := models.Doc_RoleRouteReq{}
	var errResponse models.ExternalErrorResponse

	isRoleExisted := false
	fmt.Printf("Select count(1) from Role where id=%d ", req.RoleID)
	if isRoleExisted {
		fmt.Printf("update Role set roleName='%s',roleMemo='%s' where id=%d \n", req.RoleName, req.RoleMemo, req.RoleID)
	} else {
		role := new(models.Doc_RoleModel)
		role.GroupKey = groupKey
		role.RoleLevel = 4
		role.RoleMemo = req.RoleMemo
		role.RoleName = req.RoleName
		fmt.Println("Insert Role")
	}

	if len(req.Data) > 0 {
		fmt.Printf("delete from RoleRoute where roleID=%d \n", req.RoleID)
		for _, roleRoute := range req.Data {
			newItem := new(models.Doc_RoleRouteModel)
			newItem.RoleID = req.RoleID
			newItem.ParentID = roleRoute.ParentID
			newItem.RouteID = roleRoute.RouteID
			newItem.RouteName = roleRoute.RouteName
			newItem.RouteMemo = roleRoute.RouteMemo
			newItem.IsView = roleRoute.IsView
			newItem.IsEdit = roleRoute.IsEdit
			newItem.IsDelete = roleRoute.IsDelete
			//CreateDate
			//CreateUser
			//UpdateDate
			//UpdateUser
			fmt.Println("INSERT INTO RoleRoute columnNAME values ( columnVALUE ) ")
		}
	}
	/*=== service ==================================*/

	if len(errResponse.ErrorMessage) > 0 {
		response, _ = json.Marshal(errResponse)
	} else {
		response, _ = json.Marshal(rm)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}
