package rolecontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	roleservice "letsinstallapi/services/role"
	"net/http"
)

// @Summary 角色-查詢列表 [R1]
// @Tags ( /admin-api ) Role
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostRoleReq true "test""
// @Success 200 {object} models.Doc_GetRoleRM
// @Router /v2/Role/GetRole [post]
func GetRole(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetRoleRequest](r, &flowData, "R1") {
		roleservice.GetRole(&flowData, "R1")
	}

	services.ServeResponse(w, &flowData)
}

// @Summary 角色-增刪修 [R2]
// @Tags ( /admin-api ) Role
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_RoleModel true "test""
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/Role/PutRole [put]
func PutRole(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.PutRoleRequest](r, &flowData, "R2") {
		roleservice.PutRole(&flowData, "R2")
	}

	services.ServeResponse(w, &flowData)
}
