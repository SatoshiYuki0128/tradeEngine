package ownerusercontroller

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
	owneruserservice "letsinstallapi/services/ownerUser"
	"net/http"
)

// @Summary 帳號維護-個人資訊修改(修改密碼)
// @Tags ( /admin-api ) OwnerUser
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:ccaldp1of5aho49r82ug#1662342884"
// @Param param body models.Doc_ReSetPasswordReq true "test"
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/OwnerUser/resetPassword [put]
func ResetPassword(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.ResetPassword](r, &flowData, "OU1") {
		owneruserservice.ResetPassword(&flowData, "OU1")
	}
	services.ServeResponse(w, &flowData)
}

// @Summary 帳號維護-查詢列表
// @Tags ( /admin-api ) OwnerUser
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:  cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_PostOwnerUserReq true "test""
// @Success 200 {object} models.Doc_GetOwnerUserRM
// @Router /v2/OwnerUser/ownerUser [post]
func GetOwnerUser(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.GetOwnerUser](r, &flowData, "OU2") {
		owneruserservice.GetOwnerUser(&flowData, "OU2")
	}
	services.ServeResponse(w, &flowData)
}

// @Summary 帳號維護-增刪修
// @Tags ( /admin-api ) OwnerUser
// @version 1.0
// @produce application/json
// @param cid header string true "使用者已登入驗證 ex:cc6r7hjd0cvmdcrecm0g#1661842374"
// @Param param body models.Doc_OwnerUserModel true "test"
// @Success 200 {object} models.Doc_PutResponseRM
// @Router /v2/OwnerUser/ownerUser [put]
func EditOwnerUser(w http.ResponseWriter, r *http.Request) {
	flowData := models.FlowData{}
	if services.GetAndValidateRequest[models.Doc_OwnerUserModel](r, &flowData, "OU3") {
		owneruserservice.EditOwnerUser(&flowData, "OU3")
	}
	services.ServeResponse(w, &flowData)
}
