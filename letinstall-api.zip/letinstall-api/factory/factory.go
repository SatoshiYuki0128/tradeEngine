package factory

import (
	"letsinstallapi/common"
	"letsinstallapi/common/goSql"
	"letsinstallapi/common/gormSql"
)

type DbModule struct {
	Dbo common.DbFactory
}

func GetDbModule(dbModuleType string) *DbModule {

	switch dbModuleType {
	case "gormsql":
		return &DbModule{Dbo: gormSql.NewGormSqlClient()}
	case "gosql":
		return &DbModule{Dbo: goSql.NewGoSqlClient()}
	default:
		break
	}

	return nil
}
