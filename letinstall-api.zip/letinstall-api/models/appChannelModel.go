package models

type GetAppChannelRequest struct {
	Cid string `json:"cid"`
	Doc_PostAppChannelReq
}

type UpdateAppChannelRequest struct {
	Cid string `json:"cid"`
	Doc_AppChannelModel
}
