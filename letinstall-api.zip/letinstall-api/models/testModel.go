package models

type TestVideo struct {
	Id          int
	Code        string
	TestBoolean bool
}

type TestVideoRequestBody struct {
	VideoId int `json:"videoId" validate:"gt=0"`
	M1GT0Id int `json:"testId" validate:"m1gt0"`
}

type TestVideoRequestHeader struct {
	TestVideoRequestBody
	Header string `json:"hd1" validate:"oneof=big small mid"`
}

type TestVideoRequest struct {
	TestVideoRequestHeader
	Query string `json:"hd2" validate:"email"`
}
