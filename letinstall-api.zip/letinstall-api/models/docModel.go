package models

/*==== common  =========================================================================*/
type PageInfoRequest struct {
	Number int `json:"number"`
	Limit  int `json:"limit"`
}

type OrderByInfo struct {
	ColumnName string `json:"columnname"`
	OrderType  string `json:"orderby"`
}

// type ResponseModel struct {
// 	Status    string `json:"status"`
// 	ErrorCode string `json:"errorCode"`
// 	Version   string `json:"version" default:"1.0.0.0"`
// 	Msg       string `json:"msg"`
// }

// type ErrorResponseModel struct {
// 	ResponseModel
// 	Code   interface{} `json:"code"`
// 	Msg    string      `json:"msg"`
// 	Extra  interface{} `json:"extra"`
// 	Errors interface{} `json:"errors"`
// 	HTTP   string      `json:"http"`
// }

/*=============================================================================*/

/*===== AppChannel ========================================================================*/
type Doc_AppChannelModel struct {
	ChannelID   int    `json:"channelid"`   //channelID
	AppKey      string `json:"appkey"`      //App代碼
	GroupKey    string `json:"groupkey"`    //使用者群組代碼
	ChannelName string `json:"channelname"` //渠道名稱
	ChannelLink string `json:"channellink"` //分享鏈接(QRcode)
	ChannelPwd  string `json:"channelpwd"`  //分享密碼
	DelFlag     int    `json:"delflag"`     //是否停用
	CreateTime  string `json:"createtime"`  //建立時間
	CreateUser  string `json:"createuser"`  //建立人
	UpdateTime  string `json:"updatetime"`  //修改時間
	UpdateUser  string `json:"updateuser"`  //修改人
}

type Doc_PostAppChannelReq struct {
	Page    PageInfoRequest     `json:"page"`
	Where   Doc_AppChannelWhere `json:"where"`
	OrderBy OrderByInfo         `json:"orderby"`
}

func (request *Doc_PostAppChannelReq) IsConditionEmpty() bool {
	return request.Where.ChannelID == 0 &&
		request.Where.ChannelName == "" &&
		request.Where.UpdateTime_start == "" &&
		request.Where.UpdateTime_end == "" &&
		request.Where.UpdateUser == "" &&
		request.OrderBy.ColumnName == "" &&
		request.Page.Limit == 0 &&
		request.Page.Number == 0
}

type Doc_AppChannelWhere struct {
	ChannelID        int    `json:"channelid"`        //channelID
	AppKey           string `json:"appkey"`           //App代碼
	GroupKey         string `json:"groupkey"`         //使用者群組代碼
	ChannelName      string `json:"channelname"`      //渠道名稱
	UpdateTime_start string `json:"updatetime_start"` //修改時間-起
	UpdateTime_end   string `json:"updatetime_end"`   //修改時間-迄
	UpdateUser       string `json:"updateuser"`       //修改人
}
type Doc_GetAppChannelRM struct {
	ExternalErrorResponse
	Data       []Doc_AppChannelModel `json:"data"`
	TotalCount int                   `json:"totalcount"`
}

type Doc_PutResponseRM struct {
	ExternalErrorResponse
	Data UpdateStatusModel `json:"data"`
}
type UpdateStatusModel struct {
	Status bool   `json:"status"` //異動成功:true / 失敗:false
	Action string `json:"action"` //新增:add / 刪除:delete / 修改:edit
}

/*===== App ========================================================================*/
type Doc_AppModel struct {
	//Action          UpdateStatusModel `json:"action"`
	UserKey         string `json:"UserKey"`
	Id              int    `json:"id"`              //id
	AppKey          string `json:"appkey"`          //App代碼
	GroupKey        string `json:"groupkey"`        //使用者群組代碼
	AppName         string `json:"appname"`         //App名稱
	AppName_tw      string `json:"appname_tw"`      //App名稱-繁
	AppName_cn      string `json:"appname_cn"`      //App名稱-中
	AppName_en      string `json:"appname_en"`      //App名稱-英
	Platform        string `json:"platform"`        //App平台
	VersionNumber   string `json:"versionnumber"`   //版本編號
	UserIP          string `json:"userip"`          //修改人IP
	UserCountryCode string `json:"usercountrycode"` //修改人國籍
	IsActive        int    `json:"isactive"`        //啟用狀態
	DelFlag         int    `json:"delflag"`         //刪除標記
	CreateTime      string `json:"createtime"`      //建立時間
	CreateUser      string `json:"createuser"`      //建立人
	UpdateTime      string `json:"updatetime"`      //修改時間
	UpdateUser      string `json:"updateuser"`      //修改人
}

type Doc_AppWhere struct {
	AppKey           string `json:"appkey"`           //App代碼
	GroupKey         string `json:"groupkey"`         //使用者群組代碼
	AppName          string `json:"appname"`          //App名稱
	Platform         string `json:"platform"`         //App平台
	UpdateTime_start string `json:"updatetime_start"` //修改時間-起
	UpdateTime_end   string `json:"updatetime_end"`   //修改時間-迄
	UpdateUser       string `json:"updateuser"`       //修改人
}
type Doc_GetAppRM struct {
	ExternalErrorResponse
	Data       []Doc_AppModel `json:"data"`
	TotalCount int            `json:"totalcount"`
}

/*===== UserGroup ========================================================================*/
type Doc_UserGroupModel struct {
	Id         int    `json:"id"`         //id
	GroupKey   string `json:"groupkey"`   //使用者群組代碼
	UserKey    string `json:"userkey"`    //憑證碼
	GroupName  string `json:"groupname"`  //群組名稱
	GroupMemo  string `json:"groupmemo"`  //群組說明
	ParentKey  string `json:"parentkey"`  //父群組代碼
	CreateTime string `json:"createtime"` //建立時間
	CreateUser string `json:"createuser"` //建立人
	UpdateTime string `json:"updatetime"` //修改時間
	UpdateUser string `json:"updateuser"` //修改人
}

type Doc_StringRM struct {
	ExternalErrorResponse
	Data string `json:"data"`
}

type Doc_PromoKeyModel struct {
	UserKey    string `json:"userkey"`    //使用者群組代碼
	GroupKey   string `json:"groupkey"`   //使用者群組代碼
	ActiveTime int64  `json:"activetime"` //推廣碼有效期間
}

type Doc_PostUserGroupReq struct {
	Page    PageInfoRequest    `json:"page"`
	Where   Doc_UserGroupWhere `json:"where"`
	OrderBy OrderByInfo        `json:"orderby"`
}
type Doc_UserGroupWhere struct {
	GroupKey         string `json:"groupkey"`         //使用者群組代碼
	UserKey          string `json:"userkey"`          //憑證碼
	GroupName        string `json:"groupname"`        //群組名稱
	UpdateTime_start string `json:"updatetime_start"` //修改時間-起
	UpdateTime_end   string `json:"updatetime_end"`   //修改時間-迄
	UpdateUser       string `json:"updateuser"`       //修改人
}
type Doc_GetUserGroupRM struct {
	ExternalErrorResponse
	Data       []Doc_UserGroupModel `json:"data"`
	TotalCount int                  `json:"totalcount"`
}

/*===== OwnerUser ========================================================================*/
type Doc_OwnerUserModel struct {
	Id            int    `json:"id"`            //id
	UserKey       string `json:"userkey"`       //憑證碼
	RoleID        int    `json:"roleid"`        //角色ID
	RoleName      string `json:"rolename"`      //角色名稱
	UserName      string `json:"username"`      //別名
	Account       string `json:"account"`       //帳號(郵箱)
	Pwd           string `json:"pwd"`           //密碼
	VipLevel      int    `json:"viplevel"`      //Vip等級
	LastloginTime string `json:"lastlogintime"` //最後登入時間
	LastloginIP   string `json:"lastloginip"`   //最後登入IP
	Cid           string `json:"cid"`           //登入狀態驗證
	Phone         string `json:"phone"`         //手機號碼
	Email         string `json:"email"`         //電子郵件
	IsEnable      int    `json:"isenable"`      //是否啟用
	CreateTime    string `json:"createtime"`    //建立時間
	CreateUser    string `json:"createuser"`    //建立人
	UpdateTime    string `json:"updatetime"`    //修改時間
	UpdateUser    string `json:"updateuser"`    //修改人
}

type Doc_ReSetPasswordReq struct {
	Pwd    string `json:"pwd"`    //密碼
	NewPwd string `json:"newpwd"` //密碼
}

type Doc_OwnerUserCidsModel struct {
	Id            int    `json:"id"`            //id
	UserKey       string `json:"userkey"`       //憑證碼
	GroupKey      string `json:"groupkey"`      //使用者群組代碼
	LastloginTime string `json:"lastlogintime"` //最後登入時間
	LastloginIP   string `json:"lastloginip"`   //最後登入IP
	Cid           string `json:"cid"`           //登入狀態驗證
}

type Doc_PostOwnerUserReq struct {
	PageInfoRequest
	Where   Doc_OwnerUserWhere `json:"where"`
	OrderBy OrderByInfo        `json:"orderby"`
}

type Doc_OwnerUserWhere struct {
	Cid              string `json:"cid"`              //登入狀態驗證
	UserName         string `json:"username"`         //別名
	UpdateTime_start string `json:"updatetime_start"` //修改時間-起
	UpdateTime_end   string `json:"updatetime_end"`   //修改時間-迄
	UpdateUser       string `json:"updateuser"`       //修改人
	// VipLevel         int    `json:"viplevel"`         //Vip等級
}
type Doc_GetOwnerUserRM struct {
	ExternalErrorResponse
	Data       []Doc_OwnerUserModel `json:"data"`
	TotalCount int                  `json:"totalcount"`
}

/*===== Register ========================================================================*/
type Doc_RegisterModel struct {
	Id        int    `json:"id"`        //id
	Account   string `json:"account"`   //帳號(郵箱)
	Pwd       string `json:"pwd"`       //密碼
	Phone     string `json:"phone"`     //手機號碼
	GroupName string `json:"groupname"` //群組名稱
}

type Doc_BoolRM struct {
	ExternalErrorResponse
	Data bool `json:"data"`
}

/*===== Role ========================================================================*/
type Doc_RoleModel struct {
	Id         int    `json:"id"`         //id
	GroupKey   string `json:"groupkey"`   //使用者群組代碼
	RoleLevel  int    `json:"rolelevel"`  //角色等級
	RoleName   string `json:"rolename"`   //角色name
	RoleMemo   string `json:"rolememo"`   //角色說明
	Delflag    int    `json:"delflag"`    //是否停用
	CreateTime string `json:"createtime"` //建立時間
	CreateUser string `json:"createuser"` //建立人
	UpdateTime string `json:"updatetime"` //修改時間
	UpdateUser string `json:"updateuser"` //修改人
}
type Doc_PostRoleReq struct {
	Page    PageInfoRequest `json:"page"`
	Where   Doc_RoleWhere   `json:"where"`
	OrderBy OrderByInfo     `json:"orderby"`
}
type Doc_RoleWhere struct {
	GroupKey string `json:"groupkey"` //使用者群組代碼
}
type Doc_GetRoleRM struct {
	ExternalErrorResponse
	Data       []Doc_RoleModel `json:"data"`
	TotalCount int             `json:"totalcount"`
}

/*===== ========================================================================*/
type Doc_UserGroupRoleModel struct {
	Id          int    `json:"id"`          //id
	GroupKey    string `json:"groupkey"`    //使用者群組代碼
	GroupName   string `json:"groupname"`   //群組名稱
	UserKey     string `json:"userkey"`     //憑證碼
	AdminRoleID int    `json:"adminroleid"` //admin role id
}

type Doc_RegisterUserRM struct {
	ExternalErrorResponse
	Data Doc_RegisterModel `json:"data"`
}

type Doc_UserLoginReq struct {
	Account string `json:"account"` //帳號(郵箱)
	Pwd     string `json:"pwd"`     //密碼
}
type Doc_UserLoginRM struct {
	ExternalErrorResponse
	Data Doc_UserLoginModel `json:"data"`
}
type Doc_UserLoginModel struct {
	Cid string `json:"cid"` //登入狀態驗證
}

/*===== RoleRoute ========================================================================*/
type Doc_RoleRouteModel struct {
	Id         int    `json:"id"`         //id
	ParentID   int    `json:"parentid"`   //父功能id(json)
	RoleID     int    `json:"roleid"`     //角色id
	RouteID    int    `json:"routeid"`    //功能id(json)
	RouteName  string `json:"routename"`  //功能名稱(json)
	RouteMemo  string `json:"routememo"`  //備註
	IsView     int    `json:"isview"`     //檢視權限
	IsEdit     int    `json:"isedit"`     //檢視權限
	IsDelete   int    `json:"isdelete"`   //檢視權限
	CreateTime string `json:"-"`          //建立時間
	CreateUser string `json:"-"`          //建立人
	UpdateTime string `json:"updatetime"` //最後修改時間
	UpdateUser string `json:"updateuser"` //修改人
}
type Doc_GetRoleRouteRM struct {
	ExternalErrorResponse
	Data       []Doc_RoleRouteModel `json:"data"`
	TotalCount int                  `json:"totalcount"`
}
type Doc_RoleRouteReq struct {
	RoleID   int                  `json:"roleid"`   //角色id
	RoleName string               `json:"rolename"` //角色name
	RoleMemo string               `json:"rolememo"` //角色說明
	Data     []Doc_RoleRouteModel `json:"data"`
}

/*===== AgentChannel ========================================================================*/
type AgentDevice_1stDB struct {
	Id        int64  `json:"id"`        //pk
	Sw        int    `json:"sw"`        //手機寬度
	Sh        int    `json:"sh"`        //手機高度
	Sp        string `json:"sp"`        //手機pix
	Gv        string `json:"gv"`        //品牌(Apple Inc.)
	Gr        string `json:"gr"`        //GPU Version
	Os        string `json:"os"`        //系統(iOS or Android)
	Osver     string `json:"osver"`     //osver os序號(iOS 13.1)
	Ver       string `json:"ver"`       //sdkVersion
	Appkey    string `json:"appkey"`    //app Key
	Uuid      string `json:"uuid"`      //UUID
	Imei      string `json:"imei"`      //IMEI
	ChannelId int    `json:"channelid"` //channelId
	// PromotionCode string `json:"code"`        //code.........................刪除欄位
	Ip_nat      string `json:"ip_nat"`      //內網IP
	Ip_xff      string `json:"ip_xff"`      //外網IP
	Country_xff string `json:"country_xff"` //國家-外網IP.........................新增欄位
	Timezone    string `json:"timezone"`    //時區zh-tw
	Lang        string `json:"lang"`        //語言
	IsDownload  int    `json:"isdownload"`  //是否已下載
	CreateTime  string `json:"createtime"`  //建立日期
	CreateUser  string `json:"createuser"`  //建立人員
	UpdateTime  string `json:"updatetime"`  //修改日期
	UpdateUser  string `json:"updateuser"`  //修改人員
	Apprequest  string `json:"apprequest"`  //BBIN Json
}

// 表二抽離部分欄位至此表
type AgentDevice_ResultModel struct {
	Id             int64  `json:"id"`             //pk
	Id_2nd         int64  `json:"id_2nd"`         //2nd_pk
	CreateTime_2nd string `json:"CreateTime_2nd"` //建立日期2nd
	MatchType      string `json:"matchtype"`      //比對成功類別
	DeviceMatch    int    `json:"devicematch"`    //裝置資訊比對狀態 0: uuid 1:device
	DeviceDiffName string `json:"devicediffname"` //裝置資訊差異欄位名稱
	DeviceDiff     string `json:"devicediff"`     //裝置資訊差異欄位
}

type Doc_RequestSDK struct {
	Token string `json:"token"`
	Doc_RequestRSA
}
type Doc_RequestRSA struct {
	Rsa string `json:"rsa"`
}

type Doc_AgentDeviceInfoRM struct {
	ExternalErrorResponse
	Data Doc_AgentDeviceRM `json:"data"`
}
type Doc_AgentDeviceRM struct {
	Uuid       string `json:"uuid"`
	ChannelId  int    `json:"channelid"`
	AppRequest string `json:"apprequest"`
}
