package models

type AgentDeviceRM struct {
	Uuid          string `json:"uuid"`
	ChannelId     int    `json:"channelid"`
	PromotionCode string `json:"code"`
	AppRequest    string `json:"apprequest"`
}

type AgentDeviceInfoRM struct {
	ExternalErrorResponse
	Data []AgentDeviceRM `json:"data"`
}

type SetDownload struct {
	ChannelId  int    `json:"channelId"`
	Uuid       string `json:"uuid"`
	IsDownload int    `json:"isDownload"`
	Appkey     string `json:"appkey"`
}
