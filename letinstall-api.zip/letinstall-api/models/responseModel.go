package models

import "fmt"

type ExternalResponse struct {
	ExternalErrorResponse
	Data interface{} `json:"data"`
}

type ExternalErrorResponse struct {
	ErrorCode    string `json:"ErrorCode"`
	ErrorMessage string `json:"ErrorMessage"`
}

type ServError struct {
	ServCode string `json:"servcode"`
	FuncCode string `json:"funccode"`
	Err      error  `json:"err"`
	Msg      string `json:"msg"`
}

func (e *ServError) Error() string {
	return fmt.Sprintf("ServCode:%s FuncCode:%s Message:%s InternalError:%s", e.ServCode, e.FuncCode, e.Msg, e.Err)
}

type CtrlError struct {
	CtrlCode string `json:"ctlcode"`
	ServError
}

func (e *CtrlError) Error() string {
	return fmt.Sprintf("CtlCode:%s ServCode:%s FuncCode:%s Message:%s InternalError:%s", e.CtrlCode, e.ServCode, e.FuncCode, e.Msg, e.Err)
}

type FlowData struct {
	CtrlError
	Request  interface{}            `json:"request"`
	Response interface{}            `json:"response"`
	Data     map[string]interface{} `json:"data"`
}

func (resp FlowData) ErrorCode() string {
	errorCode := resp.CtrlCode
	if resp.ServCode != "" {
		errorCode += "-" + resp.ServCode
	}
	if resp.FuncCode != "" {
		errorCode += "-" + resp.FuncCode
	}
	return errorCode
}
