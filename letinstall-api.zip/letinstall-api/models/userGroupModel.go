package models

type GetPromoCode struct {
	Cid      string `json:"cid"`
	KeepDays int    `json:"keepdays"`
}

type GetUserGroup struct {
	Cid     string             `json:"cid"`
	Page    PageInfoRequest    `json:"page"`
	Where   Doc_UserGroupWhere `json:"where"`
	OrderBy OrderByInfo        `json:"orderby"`
}

type EditUserGroup struct {
	Cid        string `json:"cid"`
	Id         int    `json:"id"`         //id
	GroupKey   string `json:"groupkey"`   //使用者群組代碼
	UserKey    string `json:"userkey"`    //憑證碼
	GroupName  string `json:"groupname"`  //群組名稱
	GroupMemo  string `json:"groupmemo"`  //群組說明
	ParentKey  string `json:"parentkey"`  //父群組代碼
	CreateTime string `json:"createtime"` //建立時間
	CreateUser string `json:"createuser"` //建立人
	UpdateTime string `json:"updatetime"` //修改時間
	UpdateUser string `json:"updateuser"` //修改人
}
