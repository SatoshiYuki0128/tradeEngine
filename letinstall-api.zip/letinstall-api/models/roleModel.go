package models

type GetRoleRequest struct {
	Cid string `json:"cid"`
	Doc_PostRoleReq
}

type PutRoleRequest struct {
	Cid string `json:"cid"`
	Doc_RoleModel
}
