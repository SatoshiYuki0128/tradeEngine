package models

type PutRoleRouteRequest struct {
	Doc_UserLoginModel
	Doc_RoleRouteReq
}
