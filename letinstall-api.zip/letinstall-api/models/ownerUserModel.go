package models

type ResetPassword struct {
	Cid    string `json:"cid"`
	Pwd    string `json:"pwd"`    //密碼
	NewPwd string `json:"newpwd"` //密碼
}

type GetOwnerUser struct {
	Cid string `json:"cid"`
	PageInfoRequest
	Where   Doc_OwnerUserWhere `json:"where"`
	OrderBy OrderByInfo        `json:"orderby"`
}
