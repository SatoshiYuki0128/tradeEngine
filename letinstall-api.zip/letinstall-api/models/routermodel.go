package models

import (
	"net/http"

	"github.com/gorilla/mux"
)

type ApiRoute struct {
	Method     string
	Pattern    string
	Handler    http.HandlerFunc
	Middleware mux.MiddlewareFunc
}
