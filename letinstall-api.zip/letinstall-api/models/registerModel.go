package models

type OTPCheckRequest struct {
	AppKey  string `json:"appkey"`
	OtpCode string `json:"otpcode"`
}

type ForgetPasswordRequest struct {
	Password       string `json:"password" validate:"min=6,max=20"`
	EnsurePassword string `json:"ensurePassword" validate:"min=6,max=20"`
	PhoneNumber    string `json:"phoneNumber"`
	OtpCode        string `json:"otpCode"`
}

type SignInRequest struct {
	UserName string `json:"username" validate:"email"`
	Password string `json:"password" validate:"min=6,max=20"`
}

type SignInResponse struct {
	ChannelConsoleUrl string
	JwtToken          string
}

func (e *SignInResponse) ToUrl() string {
	return e.ChannelConsoleUrl + "/redirect?token=" + e.JwtToken
}

type SignUpRequest struct {
	UserName       string `json:"username" validate:"email"`
	Password       string `json:"password" validate:"min=6,max=20"`
	EnsurePassword string `json:"ensurePassword" validate:"min=6,max=20"`
	PhoneNumber    string `json:"phoneNumber"`
	OtpCode        string `json:"otpCode"`
}

type GetVerifyCodeRequest struct {
	CountryCode int    `json:"countryCode"`
	PhoneNumber string `json:"phoneNumber" validate:"min=1"`
}

type VerifyCode struct {
	Mobile      string `json:"mobile"`
	Msg         string `json:"msg"`
	CountryCode int    `json:"country_code"`
	Platfrom    string `json:"platform"`
	Test        int    `json:"test"`
}

type VerifyCodeResp struct {
	Result   bool        `json:"result"`
	Msg      string      `json:"msg"`
	Provider string      `json:"provider"`
	Profile  ProfileResp `json:"profile"`
}

type ProfileResp struct {
	ExecutionTime float64 `json:"execution_time"`
	ServerName    string  `json:"server_name"`
}

type YaboConsolerUser struct {
	UserId   string `json:"id"`
	Account  string `json:"account"`
	Password string `json:"password"`
	Appkey   string `json:"appkey"`
}

type RoleRouteRequest struct {
	JwtToken string `json:"jwt" validate:"jwt"`
}

type UserRoleRoutes struct {
	Username string      `json:"username"`
	Role     string      `json:"role"`
	Routes   []RoleRoute `json:"routes"`
}

type RoleRoute struct {
	RouteId int    `json:"routeId"`
	Title   string `json:"title"`
}

type GetVerifyCode struct {
	CountryCode int    `json:"countrycode"`
	PhoneNumber string `json:"phonenumber"`
}

type RegisterUserRequest struct {
	PromotionCode string `json:"code"`
	Doc_RegisterModel
}

type UserAndGroupKey struct {
	UserKey  string `json:"userKey"`
	GroupKey string `json:"groupKey"`
	Account  string `json:"account"`
	RoleId   int    `json:"roleId"`
}
