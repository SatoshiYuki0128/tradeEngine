package models

type GetAppList struct {
	Id            int    `json:"id"`            //id
	AppKey        string `json:"appkey"`        //App代碼
	GroupKey      string `json:"groupkey"`      //使用者群組代碼
	AppName       string `json:"appname"`       //App名稱
	AppName_tw    string `json:"appname_tw"`    //App名稱-繁
	AppName_cn    string `json:"appname_cn"`    //App名稱-中
	AppName_en    string `json:"appname_en"`    //App名稱-英
	Platform      string `json:"platform"`      //App平台
	VersionNumber string `json:"versionnumber"` //版本編號
	//UserIP          string `json:"userip"`          //修改人IP
	UserCountryCode string `json:"usercountrycode"` //修改人國籍
	IsActive        int    `json:"isactive"`        //啟用狀態
	DelFlag         int    `json:"delflag"`         //刪除標記
	CreateDate      string `json:"createtime"`      //建立時間
	CreateUser      string `json:"createuser"`      //建立人
	UpdateTime      string `json:"updatetime"`      //修改時間
	UpdateUser      string `json:"updateuser"`      //修改人
}

type AppListReq struct {
	Page    PageInfoRequest `json:"page"`
	Where   Doc_AppWhere    `json:"where"`
	OrderBy OrderByInfo     `json:"orderby"`
}
