# LetsInstallAPI-V2
letsinstall api v2
樣板基礎為色站api(videp portal為基礎建置)

Go Lang開發
[Main.Go  捷徑](/main.go)
[routers  捷徑](/router/routers.go)
# 自動取套件 go mod vendor
# 刷新元件關聯 go mod tidy
# 本機執行 go run main.go
go get github.com/json-iterator/go
go get github.com/360EntSecGroup-Skylar/excelize

### [LetsInstall-Admin-API-QA站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-adminQA-v0.0.1.46" -m "letsinstall-adminQA-v0.0.1.46"
git push origin letsinstall-adminQA-v0.0.1.46
<!-- git push origin release_qa --tags -->

### [LetsInstall-Admin-API-Demo/Prod站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-adminProd-v0.0.1.7" -m "letsinstall-adminProd-v0.0.1.7"
git push origin letsinstall-adminProd-v0.0.1.7

### [LetsInstall-客端API-QA站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-guestQA-v0.0.1.7" -m "letsinstall-guestQA-v0.0.1.7"
git push origin letsinstall-guestQA-v0.0.1.7

### [LetsInstall-客端API-Demo/Prod站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-guestProd-v0.0.1.7" -m "letsinstall-guestProd-v0.0.1.7"
git push origin letsinstall-guestProd-v0.0.1.7
