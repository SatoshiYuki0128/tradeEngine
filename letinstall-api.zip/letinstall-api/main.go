package main

import (
	"fmt"
	"letsinstallapi/docs"
	routers "letsinstallapi/routers"
	"net/http"

	"github.com/spf13/viper"
	"go.elastic.co/apm/module/apmgorilla"
)

func main() {
	initConfig()
	router := routers.NewRouter()

	apmgorilla.Instrument(router)
	routers.APMTrace(router)
	http.ListenAndServe(":80", router)
}

func initConfig() {
	viper.SetConfigName("appsettings")
	viper.AddConfigPath(".")
	//viper.AddConfigPath("$GOPATH/src")

	err := viper.ReadInConfig()
	if err != nil {
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
	docs.SwaggerInfo.BasePath = viper.GetString("Swagger.BasePath")
	docs.SwaggerInfo.Description = viper.GetString("Swagger.Name")
	docs.SwaggerInfo.Title = viper.GetString("Swagger.Name")

	//* init Redis
	//redislib.NewClient()
}
