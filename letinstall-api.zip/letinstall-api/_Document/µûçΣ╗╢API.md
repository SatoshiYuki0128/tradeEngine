# RD7專用 App推廣 VipSignApp
[Main.Go  捷徑](/main.go)

# 自動取套件 go mod vendor
# 自動取套件 go mod tidy
# go install github.com/swaggo/swag/cmd/swag@v1.8.1
# 本機執行 go run main.go
# = = = = = = = = = = = = = = = = = = = = = = = = #

# 文件連結
[routers    捷徑](/routers/routers.go)
[Model      捷徑](/models/docModel.go)
[Controller 捷徑](/controller/doc/docAdminController.go)
[Controller 捷徑](/controller/doc/docGuestController.go)

[捷徑](/models/sdkModel.go)
[捷徑](/controller/SDK/sdkController.go)
[捷徑](/services/SDK/sdkFunction.go)
[捷徑](/services/SDK/sdkService.go)

### [LetsInstall-Admin-API-QA站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-adminQA-v0.0.1.19" -m "letsinstall-adminQA-v0.0.1.19"
git push origin letsinstall-adminQA-v0.0.1.19

### [LetsInstall-Admin-API-Demo/Prod站]佈署   ---(tag名稱前綴大小寫需一致) ###
git tag -a "letsinstall-adminProd-v0.0.1.7" -m "letsinstall-adminProd-v0.0.1.7"
git push origin letsinstall-adminProd-v0.0.1.7
