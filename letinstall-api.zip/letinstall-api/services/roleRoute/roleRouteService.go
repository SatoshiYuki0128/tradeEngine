package rolerouteservice

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

//ServiceCode:RR1
func GetRoleRoute(flowData *models.FlowData, controllerCode string) {
	if keys, isOK := services.GetKeysByCid(flowData, flowData.Request.(models.Doc_UserLoginModel).Cid, controllerCode, "RR1"); isOK {
		getRoleRoutes(flowData, keys.RoleId, controllerCode, "RR1")
	}
	return
}

//ServiceCode:RR2
func PutRoleRoute(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.PutRoleRouteRequest)
	if keys, isOK := services.GetKeysByCid(flowData, request.Cid, controllerCode, "RR2"); isOK {
		setRole(flowData, keys.UserKey, keys.GroupKey, request.RoleID, request.RoleName, request.RoleMemo, controllerCode, "RR2")
		setRoleRoute(flowData, keys.UserKey, request.Data, request.RoleID, controllerCode, "RR2")
	}
}
