package rolerouteservice

import (
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
	"strings"
)

//FunctionCode:RR1
func getRoleRoutes(flowData *models.FlowData, roleId int, controllerCode, serviceCode string) {

	sql := `select id,parentID,roleID,routeID,routeName,routeMemo,isView,isEdit,isDelete,createTime,createUser,updateTime,updateUser
		from RoleRoute where roleID=?;`
	dbModule := factory.GetDbModule("gosql")
	roleRoutes := []models.Doc_RoleRouteModel{}
	err := dbModule.Dbo.SqlSelect(&roleRoutes, sql, roleId)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RR1", "Get RoleRoutes Error", err)
	}
	flowData.Response = roleRoutes

	return
}

//FunctionCode:RR2
func isRoleExsist(flowData *models.FlowData, roleId int, controllerCode, serviceCode string) (isRoleExsist bool) {

	sql := `select count(*) from Role where id=?;`
	dbModule := factory.GetDbModule("gosql")
	dataCount := 0
	err := dbModule.Dbo.SqlSelect(&dataCount, sql, roleId)
	if err == nil && dataCount >= 1 {
		isRoleExsist = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "RR2", "Get Role Error", err)
	}

	return
}

//FunctionCode:RR3
func setRole(flowData *models.FlowData, userKey, groupKey string, roleId int, roleName, roleMemo, controllerCode, serviceCode string) {

	if isRoleExsist := isRoleExsist(flowData, roleId, controllerCode, serviceCode); isRoleExsist {
		updateRole(flowData, userKey, roleId, roleName, roleMemo, controllerCode, serviceCode)
	} else {
		insertRole(flowData, userKey, groupKey, roleName, roleMemo, controllerCode, serviceCode)
	}
	return
}

//FunctionCode:RR4
func insertRole(flowData *models.FlowData, userKey, groupKey, roleName, roleMemo, controllerCode, serviceCode string) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	sql := `insert into Role(groupKey,roleLevel,roleName,roleMemo,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?);`
	dbModule := factory.GetDbModule("gosql")
	_, _, err := dbModule.Dbo.SqlInsert(sql, groupKey, 4, roleName, roleMemo, currentTime, userKey, currentTime, userKey)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RR4", "Insert Role Error", err)
	}

	return
}

//FunctionCode:RR5
func updateRole(flowData *models.FlowData, userKey string, roleId int, roleName, roleMemo, controllerCode, serviceCode string) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
	sql := `update Role set roleName=?,roleMemo=?,updateTime=?,updateUser=? where id=?;`
	dbModule := factory.GetDbModule("gosql")
	_, err := dbModule.Dbo.SqlUpdateOrDelete(sql, roleName, roleMemo, currentTime, userKey, roleId)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RR5", "Update Role Error", err)
	}

	return
}

//FunctionCode:RR6
func setRoleRoute(flowData *models.FlowData, userKey string, roleRoutes []models.Doc_RoleRouteModel, roleId int, controllerCode, serviceCode string) {

	if len(roleRoutes) > 0 {
		currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
		sqlDeleteRoleRoute := `delete from RoleRoute where roleID=?;`
		argsDeleteRoleRoute := []interface{}{roleId}
		sqlInsertRoleRoute := `insert into RoleRoute(roleID,parentID,routeID,routeName,routeMemo,isView,isEdit,isDelete,createTime,createUser,updateTime,updateUser) values `
		argsInsertRoleRoute := []interface{}{}
		for _, roleRoute := range roleRoutes {
			sqlInsertRoleRoute += " (?,?,?,?,?,?,?,?,?,?,?,?),"
			argsInsertRoleRoute = append(argsInsertRoleRoute, roleId, roleRoute.ParentID, roleRoute.RouteID, roleRoute.RouteName, roleRoute.RouteMemo, roleRoute.IsView, roleRoute.IsEdit, roleRoute.IsDelete, currentTime, userKey, currentTime, userKey)
		}
		sqlInsertRoleRoute = strings.TrimRight(sqlInsertRoleRoute, ",")
		sqlInsertRoleRoute += " ; "

		sqlArray := []string{sqlDeleteRoleRoute, sqlInsertRoleRoute}
		argsArray := [][]interface{}{argsDeleteRoleRoute, argsInsertRoleRoute}
		dbModule := factory.GetDbModule("gosql")
		err := dbModule.Dbo.SqlTransactionExecute(sqlArray, argsArray)
		if err != nil {
			services.SetError(flowData, controllerCode, serviceCode, "RR6", "Set RoleRoute Error", err)
		}
	}

	return
}
