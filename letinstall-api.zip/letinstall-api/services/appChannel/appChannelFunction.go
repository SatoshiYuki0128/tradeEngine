package appchannelservice

import (
	aeshelper "letsinstallapi/common/aes"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
	"strings"
)

//FunctionCode:AC1
func outputAppChannelList(flowData *models.FlowData, request models.Doc_PostAppChannelReq, groupKey, controllerCode, serviceCode string) {
	if appChannelList := getAppChannels(flowData, request, groupKey, controllerCode, serviceCode); appChannelList != nil {
		flowData.Response = appChannelList
	}
	return
}

//FunctionCode:AC2
func getAppChannels(flowData *models.FlowData, request models.Doc_PostAppChannelReq, groupKey, controllerCode, serviceCode string) (appChannelList []models.Doc_AppChannelModel) {

	sql := `select channelId,groupKey,appKey,channelName,channelLink,channelPwd,delFlag,createTime,createUser,updateTime,updateUser
		from AppChannel
		where (appKey=? or (groupKey=? and ifnull(appKey,'')='')) and delFlag = 0`
	var args []interface{}
	args = append(args, request.Where.AppKey, groupKey)
	if !request.IsConditionEmpty() {
		if request.Where.ChannelID != -1 {
			sql += " and channelId = ?"
			args = append(args, request.Where.ChannelID)
		}
		if request.Where.ChannelName != "" {
			sql += " and channelName = ?"
			args = append(args, request.Where.ChannelName)
		}
		if request.Where.UpdateTime_start != "" {
			sql += " and updateTime >= ?"
			args = append(args, services.IpTimeToUTCTime(flowData, flowData.Data["RequestIP"].(string), request.Where.UpdateTime_start, controllerCode, serviceCode))
		}
		if request.Where.UpdateTime_end != "" {
			sql += " and updateTime <= ?"
			args = append(args, services.IpTimeToUTCTime(flowData, flowData.Data["RequestIP"].(string), request.Where.UpdateTime_end, controllerCode, serviceCode))
		}
		if request.Where.UpdateUser != "" {
			sql += " and updateUser = ?"
			args = append(args, request.Where.UpdateUser)
		}

		if request.OrderBy.ColumnName != "" {
			sql += " order by ? " + request.OrderBy.OrderType
			args = append(args, request.OrderBy.ColumnName)
		}

		if request.Page.Limit > 0 && request.Page.Number > 0 {
			sql += " limit ? ,?"
			number := (request.Page.Number - 1) * request.Page.Limit
			args = append(args, number, request.Page.Limit)
		}
	}
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&appChannelList, sql, args...)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AC1", "Get AppChannel List Error", err)
	}

	return
}

//FunctionCode:AC3
func insertAppChannel(flowData *models.FlowData, request models.Doc_AppChannelModel, userKey, groupKey, controllerCode, serviceCode string) (isOK bool) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	sql := `insert into AppChannel(groupKey,appKey,channelName,channelLink,channelPwd,delFlag,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?,?,?);`
	dbModule := factory.GetDbModule("gosql")
	_, _, err := dbModule.Dbo.SqlInsert(sql, groupKey, request.AppKey, request.ChannelName, request.ChannelLink, aeshelper.AesEncryptCBC(request.ChannelPwd, aeshelper.AES128Key), request.DelFlag, currentTime, userKey, currentTime, userKey)
	if err == nil {
		isOK = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "AC3", "Insert AppChannel List Error", err)
	}

	return
}

//FunctionCode:AC4
func updateAppChannel(flowData *models.FlowData, request models.Doc_AppChannelModel, userKey, groupKey, controllerCode, serviceCode string) (isOK bool) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
	var args []interface{}
	sql := `update AppChannel set `
	setSql := []string{}
	if request.GroupKey != "" {
		setSql = append(setSql, " groupKey = ? ")
		args = append(args, request.GroupKey)
	}
	if request.AppKey != "" {
		setSql = append(setSql, " appKey = ? ")
		args = append(args, request.AppKey)
	}
	if request.ChannelName != "" {
		setSql = append(setSql, " channelName = ? ")
		args = append(args, request.ChannelName)
	}
	if request.ChannelLink != "" {
		setSql = append(setSql, " channelLink = ? ")
		args = append(args, request.ChannelLink)
	}
	if request.ChannelPwd != "" {
		setSql = append(setSql, " channelPwd = ? ")
		args = append(args, aeshelper.AesEncryptCBC(request.ChannelPwd, aeshelper.AES128Key))
	}
	if request.DelFlag >= 0 {
		setSql = append(setSql, " delFlag = ? ")
		args = append(args, request.DelFlag)
	}
	setSql = append(setSql, " updateUser = ? ", " updateTime = ? ")
	args = append(args, userKey, currentTime)

	sql += strings.Join(setSql, ",") + " where channelId = ? ;"
	args = append(args, request.ChannelID)

	dbModule := factory.GetDbModule("gosql")
	_, err := dbModule.Dbo.SqlUpdateOrDelete(sql, args...)
	if err == nil {
		isOK = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "AC4", "Update AppChannel List Error", err)
	}

	return
}

//FunctionCode:AC5
func setAppChannel(flowData *models.FlowData, request models.Doc_AppChannelModel, userKey, groupKey, controllerCode, serviceCode string) {
	updateStatus := models.UpdateStatusModel{}
	if request.ChannelID > 0 {
		if request.DelFlag == 1 {
			updateStatus.Action = "delete"
		} else {
			updateStatus.Action = "edit"
		}
		if updateAppChannel(flowData, request, userKey, groupKey, controllerCode, serviceCode) {
			updateStatus.Status = true
		}

	} else {
		updateStatus.Action = "add"
		if insertAppChannel(flowData, request, userKey, groupKey, controllerCode, serviceCode) {
			updateStatus.Status = true
		}
	}
	flowData.Response = updateStatus

	return
}
