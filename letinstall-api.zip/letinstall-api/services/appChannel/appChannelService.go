package appchannelservice

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

//ServiceCode:AC1
func GetAppChannelList(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.GetAppChannelRequest)

	keys, isOK := services.GetKeysByCid(flowData, request.Cid, ctrlCode, "AC1")
	if isOK {
		outputAppChannelList(flowData, request.Doc_PostAppChannelReq, keys.GroupKey, ctrlCode, "AC1")
	}
	return
}

//ServiceCode:AC2
func UpdateAppChannel(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.UpdateAppChannelRequest)

	keys, isOK := services.GetKeysByCid(flowData, request.Cid, ctrlCode, "AC2")
	if isOK {
		setAppChannel(flowData, request.Doc_AppChannelModel, keys.UserKey, keys.GroupKey, ctrlCode, "AC2")
	}
	return
}
