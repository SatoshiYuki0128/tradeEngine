package services

import (
	httphelper "letsinstallapi/common/http"
	"letsinstallapi/models"
	"net/http"
)

// ServiceCode:C1
func GetAndValidateRequest[T any](httpRequest *http.Request, flowData *models.FlowData, controllerCode string) (result bool) {

	initFlowData(flowData, controllerCode, "C1")
	data, isOK := httphelper.GetRequestBody(httpRequest, flowData, controllerCode, "C1")
	if isOK {
		httphelper.CheckModel[T](data, httpRequest, flowData, controllerCode, "C1")

		if flowData.Err == nil {
			result = true
		}
	}

	return
}

// ServiceCode:C2
func ServeResponse(w http.ResponseWriter, flowData *models.FlowData) {
	httphelper.JsonResponse(w, flowData)
}
