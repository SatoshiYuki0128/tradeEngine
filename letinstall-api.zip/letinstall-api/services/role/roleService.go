package roleservice

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

//ServiceCode:R1
func GetRole(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.GetRoleRequest)
	if keys, isOK := services.GetKeysByCid(flowData, request.Cid, controllerCode, "R1"); isOK {
		getRoles(flowData, request, keys.GroupKey, controllerCode, "R1")
	}
	return
}

//ServiceCode:R2
func PutRole(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.PutRoleRequest)

	if keys, isOK := services.GetKeysByCid(flowData, request.Cid, controllerCode, "R2"); isOK {
		setRole(flowData, request.Doc_RoleModel, keys.UserKey, keys.GroupKey, controllerCode, "R2")
	}
	return
}
