package roleservice

import (
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
	"strings"
)

//FunctionCode:R1
func getRoles(flowData *models.FlowData, request models.GetRoleRequest, groupKey, controllerCode, serviceCode string) {

	sql := `select id,groupKey,roleLevel,roleName,roleMemo,delflag,createTime,createUser,updateTime,updateUser
		from Role where groupKey=? and delFlag = 0`
	args := []interface{}{groupKey}
	if request.OrderBy.ColumnName != "" {
		sql += " order by ? " + request.OrderBy.OrderType
		args = append(args, request.OrderBy.ColumnName)
	}

	if request.Page.Limit > 0 && request.Page.Number > 0 {
		sql += " limit ? ,?"
		number := (request.Page.Number - 1) * request.Page.Limit
		args = append(args, number, request.Page.Limit)
	}

	dbModule := factory.GetDbModule("gosql")
	roleRoutes := []models.Doc_RoleModel{}
	err := dbModule.Dbo.SqlSelect(&roleRoutes, sql, args...)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "R1", "Get Roles Error", err)
	}
	flowData.Response = roleRoutes

	return
}

//FunctionCode:R2
func setRole(flowData *models.FlowData, request models.Doc_RoleModel, userKey, groupKey, controllerCode, serviceCode string) {
	updateStatus := models.UpdateStatusModel{}
	if request.Id > 0 {
		if request.Delflag == 1 {
			updateStatus.Action = "delete"
		} else {
			updateStatus.Action = "edit"
		}
		if updateRole(flowData, request, userKey, controllerCode, serviceCode) {
			updateStatus.Status = true
		}

	} else {
		updateStatus.Action = "add"
		if insertRole(flowData, request, userKey, groupKey, controllerCode, serviceCode) {
			updateStatus.Status = true
		}
	}
	flowData.Response = updateStatus

	return
}

//FunctionCode:R3
func insertRole(flowData *models.FlowData, request models.Doc_RoleModel, userKey, groupKey, controllerCode, serviceCode string) (isOK bool) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	sql := `insert into Role(groupKey,roleLevel,roleName,roleMemo,delflag,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?,?);`
	dbModule := factory.GetDbModule("gosql")
	_, _, err := dbModule.Dbo.SqlInsert(sql, groupKey, request.RoleLevel, request.RoleName, request.RoleMemo, request.Delflag, currentTime, userKey, currentTime, userKey)
	if err == nil {
		isOK = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "R3", "Insert Role Error", err)
	}

	return
}

//FunctionCode:R4
func updateRole(flowData *models.FlowData, request models.Doc_RoleModel, userKey, controllerCode, serviceCode string) (isOK bool) {

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")
	var args []interface{}
	sql := `update Role set `
	setSql := []string{}
	if request.GroupKey != "" {
		setSql = append(setSql, " groupKey = ? ")
		args = append(args, request.GroupKey)
	}
	if request.RoleLevel > 0 {
		setSql = append(setSql, " roleLevel = ? ")
		args = append(args, request.RoleLevel)
	}
	if request.RoleName != "" {
		setSql = append(setSql, " roleName = ? ")
		args = append(args, request.RoleName)
	}
	if request.RoleMemo != "" {
		setSql = append(setSql, " roleMemo = ? ")
		args = append(args, request.RoleMemo)
	}
	if request.Delflag >= 0 {
		setSql = append(setSql, " delFlag = ? ")
		args = append(args, request.Delflag)
	}
	setSql = append(setSql, " updateUser = ? ", " updateTime = ? ")
	args = append(args, userKey, currentTime)

	sql += strings.Join(setSql, ",") + " where id = ? ;"
	args = append(args, request.Id)

	dbModule := factory.GetDbModule("gosql")
	_, err := dbModule.Dbo.SqlUpdateOrDelete(sql, args...)
	if err == nil {
		isOK = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "R4", "Update Role Error", err)
	}

	return
}
