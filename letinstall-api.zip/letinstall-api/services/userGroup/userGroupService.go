package groupService

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

// GetPromoCode serviceCode:GS1
func GetPromoCode(flowData *models.FlowData, controllerCode string) {
	cid := flowData.Request.(models.GetPromoCode).Cid
	keys, isOK := services.GetKeysByCid(flowData, cid, controllerCode, "GS1")
	if !isOK {
		return
	}
	getUrl(flowData, keys, controllerCode, "GS1")
}

// GetUserGroup serviceCode:GS2
func GetUserGroup(flowData *models.FlowData, controllerCode string) {
	cid := flowData.Request.(models.GetUserGroup).Cid
	keys, isOK := services.GetKeysByCid(flowData, cid, controllerCode, "GS2")
	if !isOK {
		return
	}
	getUserGroupFromDB(flowData, keys, controllerCode, "GS2")
}

// EditUserGroup serviceCode:GS3
func EditUserGroup(flowData *models.FlowData, controllerCode string) {
	cid := flowData.Request.(models.EditUserGroup).Cid
	keys, isOK := services.GetKeysByCid(flowData, cid, controllerCode, "GS3")
	if !isOK {
		return
	}

	if flowData.Request.(models.EditUserGroup).Id < 1 {
		insertUserGroupToDB(flowData, keys, controllerCode, "GS3")
	} else {
		updateUserGroupToDB(flowData, keys, controllerCode, "GS3")
	}

}
