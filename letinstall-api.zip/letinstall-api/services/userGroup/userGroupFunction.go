package groupService

import (
	"encoding/json"
	"fmt"
	aeshelper "letsinstallapi/common/aes"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
)

// getUrl functionCode:GS1
func getUrl(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {
	keepdays := flowData.Request.(models.GetPromoCode).KeepDays

	promo := new(models.Doc_PromoKeyModel)
	promo.GroupKey = keys.GroupKey
	promo.UserKey = keys.UserKey

	if keepdays > 0 {
		promo.ActiveTime = timehelper.GetUTCTime().AddDate(0, 0, keepdays).Unix()
	}

	jsonValue, err := json.Marshal(promo)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "GS1", "物件轉換失敗", err)
	}
	enCode := aeshelper.AesEncryptCBC(string(jsonValue), aeshelper.AES128Key)
	promoURL := fmt.Sprintf("https://qa.letsinstall.io/?code=%s", enCode)

	//fmt.Println(string(jsonValue))
	//fmt.Println(enCode)
	//fmt.Println(promoURL)
	//deCode := aeshelper.AesDecryptCBC(enCode, aeshelper.AES128Key)
	//fmt.Println(deCode)

	flowData.Response = promoURL
	return
}

// getUserGroupFromDB functionCode:GS2
func getUserGroupFromDB(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {

	req := flowData.Request.(models.GetUserGroup)
	var args []interface{}

	where := ""
	if keys.GroupKey != "" {
		where += " and (groupKey = ? or parentKey = ?)"
		args = append(args, keys.GroupKey)
		args = append(args, keys.GroupKey)
	}
	if keys.UserKey != "" {
		where += " and userKey = ?"
		args = append(args, keys.UserKey)
	}
	if req.Where.GroupName != "" {
		req.Where.GroupName = "%" + req.Where.GroupName + "%"
		where += " and groupName like ?"
		args = append(args, req.Where.GroupName)
	}
	if req.Where.UpdateTime_start != "" {
		where += " and updateTime >= ?"
		args = append(args, req.Where.UpdateTime_start)
	}
	if req.Where.UpdateTime_end != "" {
		where += " and updateTime <= ?"
		args = append(args, req.Where.UpdateTime_end)
	}
	if req.Where.UpdateUser != "" {
		where += " and updateUser = ?"
		args = append(args, req.Where.UpdateUser)
	}
	if len(where) != 0 {
		where = " where " + where[5:]
	}
	order := ""
	if req.OrderBy.OrderType == "asc" || req.OrderBy.OrderType == "desc" {
		order += " ? " + req.OrderBy.OrderType
		args = append(args, req.OrderBy.ColumnName)
	}
	if len(order) != 0 {
		order = " order by" + order
	}
	limit := ""
	if req.Page.Number > 0 && req.Page.Limit > 0 {
		limit += " ?, ?"
		number := (req.Page.Number - 1) * req.Page.Limit
		args = append(args, number)
		args = append(args, req.Page.Limit)
	}
	if len(limit) != 0 {
		limit = " limit" + limit
	}

	sql := "select id, groupKey, userKey, groupName, groupmemo, parentkey, createTime, createuser, updatetime, updateuser from UserGroup" + where + order + limit + ";"
	//fmt.Println(sql)
	dbModule := factory.GetDbModule("gosql")
	result := models.Doc_GetUserGroupRM{}
	err := dbModule.Dbo.SqlSelect(&result.Data, sql, args...)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "GS2", "Get DB Error", err)
		return
	}
	result.TotalCount = len(result.Data)

	flowData.Response = result
	return
}

// insertUserGroupToDB functionCode:GS3
func insertUserGroupToDB(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {
	req := flowData.Request.(models.EditUserGroup)
	currentTime := timehelper.GetUTCTimeString()

	sql := "insert into UserGroup (groupkey, userkey, groupname, groupmemo, parentkey, createtime, createuser, updatetime, updateuser) value (?, ?, ?, ?, ?, ?, ?, ?, ?);"
	dbModule := factory.GetDbModule("gosql")
	_, _, err := dbModule.Dbo.SqlInsert(sql, keys.GroupKey, keys.UserKey, req.GroupName, req.GroupMemo, req.GroupKey, currentTime, keys.Account, currentTime, keys.Account)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "GS3", "Insert DB Error", err)
		return
	}

	var result = models.UpdateStatusModel{}
	result.Action = "insert"
	result.Status = true
	flowData.Response = result
}

// updateUserGroupToDB functionCode:GS4
func updateUserGroupToDB(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {

	req := flowData.Request.(models.EditUserGroup)
	currentTime := timehelper.GetUTCTimeString()

	sql := "update UserGroup set groupname = ?, groupmemo = ?, parentkey = ?, updatetime = ?, updateuser = ? where groupkey = ? and userkey = ? and id = ?;"
	dbModule := factory.GetDbModule("gosql")
	num, err := dbModule.Dbo.SqlUpdateOrDelete(sql, req.GroupName, req.GroupMemo, req.ParentKey, currentTime, keys.Account, keys.GroupKey, keys.UserKey, req.Id)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "GS4", "Update DB Error", err)
		return
	}
	if num == 0 {
		services.SetError(flowData, controllerCode, serviceCode, "GS4", "No match data", err)
		return
	}

	var result = models.UpdateStatusModel{}
	result.Action = "update"
	result.Status = true
	flowData.Response = result
}
