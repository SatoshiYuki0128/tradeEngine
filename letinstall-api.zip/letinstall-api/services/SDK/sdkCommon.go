package sdkservice

import (
	"fmt"
	"letsinstallapi/factory"
	"strings"
)

func GetSQL_DbTable(tableName string, whereCols map[string]interface{}) string {
	whereCols_sql := ""
	for key, _ := range whereCols {
		_value := GetValueSQL(whereCols[key])
		if strings.ToUpper(_value) == "NULL" {
			whereCols_sql += fmt.Sprintf(" and `%s` is NULL", key)
		} else {
			whereCols_sql += fmt.Sprintf(" and `%s`=%v", key, GetValueSQL(whereCols[key]))
		}
	}
	sql := fmt.Sprintf("SELECT * FROM `%s` WHERE 1=1", tableName) + whereCols_sql
	return sql
}

//Arvin
func UpdateTable_BySQL(tableName string, updateCols map[string]interface{}, whereCols map[string]interface{}) (affectCount int64, existedCount int64, err error) {
	updateCols_sql := ""
	whereCols_sql := ""
	if len(updateCols) == 0 {
		return
	} else {
		for key, _ := range updateCols {
			if updateCols_sql != "" {
				updateCols_sql += " ,"
			}
			updateCols_sql += fmt.Sprintf(" `%s`=%v", key, GetValueSQL(updateCols[key]))
		}
	}
	for key, _ := range whereCols {
		_value := GetValueSQL(whereCols[key])
		if strings.ToUpper(_value) == "NULL" {
			whereCols_sql += fmt.Sprintf(" and `%s` is NULL", key)
		} else {
			whereCols_sql += fmt.Sprintf(" and `%s`=%v", key, GetValueSQL(whereCols[key]))
		}
	}

	//查詢是否有此筆資料
	selectSQL := fmt.Sprintf("SELECT COUNT(1) as TotalCount FROM `%s` WHERE 1=1 %s ;", tableName, whereCols_sql)
	dbModule := factory.GetDbModule("gosql")
	dbModule.Dbo.SqlSelect(&existedCount, selectSQL)

	//更新資料
	updateSQL := fmt.Sprintf("UPDATE `%s` SET %s  WHERE 1=1 %s ;", tableName, updateCols_sql, whereCols_sql)
	dbModule_upd := factory.GetDbModule("gosql")
	affectCount, err = dbModule_upd.Dbo.SqlUpdateOrDelete(updateSQL)
	return
}
func InsertTable_BySQL(tableName string, insertCols map[string]interface{}, whereCols map[string]interface{}) (pkID int64, pkCount int64, err error) {
	nameCols_sql := ""
	valueCols_sql := ""
	whereCols_sql := ""
	if len(insertCols) == 0 {
		return
	} else {
		for key, _ := range insertCols {
			if nameCols_sql != "" {
				nameCols_sql += " ,"
			}
			nameCols_sql += fmt.Sprintf(" `%s`", key)

			if valueCols_sql != "" {
				valueCols_sql += " ,"
			}
			valueCols_sql += fmt.Sprintf(" %v", key, GetValueSQL(insertCols[key]))
		}
	}
	for key, _ := range whereCols {
		_value := GetValueSQL(whereCols[key])
		if strings.ToUpper(_value) == "NULL" {
			whereCols_sql += fmt.Sprintf(" and `%s` is NULL", key)
		} else {
			whereCols_sql += fmt.Sprintf(" and `%s`=%v", key, GetValueSQL(whereCols[key]))
		}
	}
	if len(whereCols) > 0 {
		//查詢是否有此筆資料
		selectSQL := fmt.Sprintf("SELECT COUNT(1) as TotalCount FROM `%s` WHERE 1=1 %s ;", tableName, whereCols_sql)
		dbModule := factory.GetDbModule("gosql")
		dbModule.Dbo.SqlSelect(&pkCount, selectSQL)
	}

	if pkCount == 0 {
		//Insert資料
		insertSQL := fmt.Sprintf("INSERT INTO %s ( %s ) VALUES ( %s );", tableName, nameCols_sql, valueCols_sql)
		dbModule_upd := factory.GetDbModule("gosql")
		_, pkID, err = dbModule_upd.Dbo.SqlInsert(insertSQL)
		if pkID > 0 {
			pkCount = 1
		}
	}
	return
}

//Arvin
func GetValueSQL(value interface{}) string {
	if fmt.Sprintf("%T", value) == "string" {
		_value := strings.Replace(fmt.Sprintf("%v", value), "'", "", -1)
		if strings.ToUpper(_value) == "NULL" {
			return "NULL"
		} else {
			return fmt.Sprintf("'%v'", _value)
		}
	} else {
		return fmt.Sprintf("%v", value)
	}
}

// ***************************
