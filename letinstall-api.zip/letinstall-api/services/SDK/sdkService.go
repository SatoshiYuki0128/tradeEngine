package sdkservice

import (
	"letsinstallapi/models"
)

// ServiceCode:SDK2
func SetDownload(flowData *models.FlowData, controllerCode string) {
	_ServiceCode := "SDK2"
	request := flowData.Request.(models.Doc_RequestSDK)
	flowData.Response = UpdateDownloadStatus(flowData, request, controllerCode, _ServiceCode)
}
