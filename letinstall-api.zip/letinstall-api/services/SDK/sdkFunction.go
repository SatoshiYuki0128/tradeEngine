package sdkservice

import (
	"encoding/json"
	"fmt"
	rsahelper "letsinstallapi/common/rsa"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/models"
	"letsinstallapi/services"
	"sort"
	"strings"
)

// setDownload serviceCode: SDK22
func AgentDeviceInfo_service(flowData *models.FlowData, rsaReq models.Doc_RequestSDK, ctrlCode, serviceCode string) (response bool) {
	funcCode := "SDK22"
	response = false
	// fmt.Printf("[Toekn] %s [Rsa] %s [ctrlCode] %s [serviceCode] %s\n", rsaReq.Token, rsaReq.Rsa, ctrlCode, serviceCode)
	requestJSON := rsahelper.RSA_Decrypt(rsaReq.Rsa)
	req := models.SetDownload{}
	fmt.Println(string(requestJSON))
	json.Unmarshal(requestJSON, &req)

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	insertCols := map[string]interface{}{
		"isDownload": 1,
		"updateTime": timehelper.TimeString(currentTime),
	}
	whereCols := map[string]interface{}{}

	affectCount, _, err := InsertTable_BySQL("AgentDevice_1st", insertCols, whereCols)
	if err == nil {
		response = true
		if affectCount == 0 {
			services.SetError(flowData, ctrlCode, serviceCode, funcCode, "該筆資料無需更新", err)
		}
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, funcCode, "UPDATE AgentDevice_1st Error", err)
	}
	return
}

// func GetDB_AgentDevice_1st(req models.AgentDevice_1stDB, isDownload bool) (response []models.AgentDevice_1stDB, sqlLog string,
// 	deviceMatch int, matchType string, deviceDiff string, deviceDiffName string) {
// 	deviceMatch = -1
// 	temp_datalist := []models.AgentDevice_1stDB{}
// 	var datalist []models.AgentDevice_1stDB

// 	queryString := AgentDevice_1st_QueryString

// 	queryString_uuid := queryString
// 	// ********************** uuid
// 	if req.Uuid != "" {
// 		queryString_uuid, _ = CombineSQLscript(queryString_uuid, "", " and uuid = '"+req.Uuid+"'")
// 		queryString_uuid, _ = CombineSQLscript(queryString_uuid, "", " and appkey = '"+req.Appkey+"'")
// 		if isDownload {
// 			queryString_uuid, _ = CombineSQLscript(queryString_uuid, "", " and isDownload = 1")
// 		}
// 		queryString_uuid, _ = CombineSQLscript(queryString_uuid, "", " order by updateDate desc")
// 		sqlLog = queryString_uuid

// 		temp_datalist, errResponse = GetDB_bySQL_AgentDevice_1st(queryString_uuid)
// 		if errResponse.Status == "998" {
// 			return
// 		}
// 	}
// 	if len(temp_datalist) > 0 {
// 		deviceDiff, deviceDiffName = GetDiff_1st(temp_datalist[0], req)
// 		matchType = "Uuid＆Appkey"
// 		if deviceDiff == "" {
// 			deviceMatch = 1 // uuid 比對成功，裝置資訊吻合
// 		} else {
// 			deviceMatch = 0 // uuid 比對成功，裝置資訊比對失敗
// 		}
// 		datalist = temp_datalist
// 	} else {
// 		swsh_cond := fmt.Sprintf(" and GREATEST(sw,sh)=GREATEST(%d,%d) and LEAST(sw,sh)=LEAST(%d,%d)", req.Sh, req.Sw, req.Sh, req.Sw)
// 		queryString += swsh_cond
// 		queryString += " and sp = '" + req.Sp + "'"
// 		queryString += " and gv = '" + req.Gv + "'"
// 		queryString += " and gr = '" + req.Gr + "'"
// 		queryString += " and os = '" + req.Os + "'"
// 		queryString += " and osver = '" + req.Osver + "'"
// 		queryString += " and ver = '" + req.Ver + "'"
// 		queryString += " and appkey = '" + req.Appkey + "'"
// 		queryString += " and ip_xff = '" + req.Ip_xff + "'"
// 		queryString += " and timezone = '" + req.Timezone + "'"
// 		queryString += " and lang = '" + req.Lang + "'"
// 		if isDownload {
// 			queryString += " and isDownload = 1"
// 		}
// 		queryString += " order by updateDate desc"

// 		sqlLog = queryString

// 		// temp_datalist, errResponse = GetDB_bySQL_AgentDevice_1st(queryString)
// 		// if errResponse.Status == "998" {
// 		// 	return
// 		// }

// 		if len(temp_datalist) > 0 {
// 			deviceDiff, deviceDiffName = GetDiff_1st(temp_datalist[0], req)
// 			matchType = "device"
// 			if deviceDiff == "" {
// 				deviceMatch = 1 // device 比對成功，裝置資訊吻合
// 			} else {
// 				deviceMatch = 0 // device 比對成功，裝置資訊比對失敗
// 			}
// 		}
// 		if len(temp_datalist) == 0 {
// 			matchType = "no data"
// 		} else {
// 			datalist = Get1st_natipFilter(temp_datalist, req.Ip_nat)
// 		}
// 	}

// 	if len(datalist) > 0 {
// 		response = datalist
// 	} else {
// 		deviceMatch = -1 //查無資料
// 	}
// 	return
// }

// setDownload serviceCode: SDK21
func UpdateDownloadStatus(flowData *models.FlowData, rsaReq models.Doc_RequestSDK, ctrlCode, serviceCode string) (response bool) {
	funcCode := "SDK21"
	response = false
	// fmt.Printf("[Toekn] %s [Rsa] %s [ctrlCode] %s [serviceCode] %s\n", rsaReq.Token, rsaReq.Rsa, ctrlCode, serviceCode)
	requestJSON := rsahelper.RSA_Decrypt(rsaReq.Rsa)
	req := models.SetDownload{}
	fmt.Println(string(requestJSON))
	json.Unmarshal(requestJSON, &req)

	errMsg := ""
	if req.Uuid == "" || req.Appkey == "" {
		// errResponse.Msg = fmt.Sprintf("有參數為空值 -> channelId : %d, uuid : %s, isDownload : %d, appkey : %s", req.ChannelId, req.Uuid, req.IsDownload, req.Appkey)
		errMsg = "參數為空值!"
		if req.Uuid == "" {
			errMsg += fmt.Sprintf(" [Uuid]%s", req.Uuid)
		}
		if req.Appkey == "" {
			errMsg += fmt.Sprintf(" [Appkey]%s", req.Appkey)
		}
		services.SetError(flowData, ctrlCode, serviceCode, funcCode, errMsg, nil)
		return
	}
	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	updateCols := map[string]interface{}{
		"isDownload": 1,
		"updateTime": timehelper.TimeString(currentTime),
	}
	whereCols := map[string]interface{}{
		"appkey":    req.Appkey,
		"uuid":      req.Uuid,
		"channelId": req.ChannelId,
	}

	affectCount, existedCount, err := UpdateTable_BySQL("AgentDevice_1st", updateCols, whereCols)
	if err == nil {
		if existedCount == 0 {
			services.SetError(flowData, ctrlCode, serviceCode, funcCode, "找不到該筆資料！", err)
		} else {
			response = true
			if affectCount == 0 {
				services.SetError(flowData, ctrlCode, serviceCode, funcCode, "該筆資料無需更新", err)
			}
		}
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, funcCode, "UPDATE AgentDevice_1st Error", err)
	}
	return
}

func Get1st_natipFilter(dbDatas []models.AgentDevice_1stDB, req_ip_nat string) (match []models.AgentDevice_1stDB) {
	var matchDatas []models.AgentDevice_1stDB
	req_ip_nat = strings.TrimSpace(req_ip_nat)

	if len(dbDatas) <= 1 {
		for _, db := range dbDatas {
			if req_ip_nat != "" && req_ip_nat == db.Ip_nat {
				// 比對到：req內網IP有值且等於db內網IP
				matchDatas = append(matchDatas, db)
			} else if req_ip_nat == "" || db.Ip_nat == "" {
				// 比對到：req內網IP值empty 或 db內網IP為empty
				matchDatas = append(matchDatas, db)
			}
		}
	} else { //多筆

		if req_ip_nat != "" { // IF：req內網IP有值
			for _, db := range dbDatas {
				if db.Ip_nat != "" && req_ip_nat == db.Ip_nat {
					// 比對到：req內網IP有值 且 等於db內網IP
					matchDatas = append(matchDatas, db)
				}
			}
			if len(matchDatas) == 0 {
				for _, db := range dbDatas {
					if db.Ip_nat == "" {
						// 比對到：req內網IP有值 且 db內網IP為empty
						matchDatas = append(matchDatas, db)
					}
				}
			}
		} else if req_ip_nat == "" { // IF：req內網IP為empty
			for _, db := range dbDatas {
				// 比對到：req內網IP為empty
				matchDatas = append(matchDatas, db)
			}
		}

	}
	if len(matchDatas) >= 1 {
		//從比對到的資料中取最後一筆(已 order by 過)
		match = append(match, matchDatas[0])
	}
	return match
}

func GetDiff_1st(dbObj models.AgentDevice_1stDB, req models.AgentDevice_1stDB) (diffLog string, diffName string) {
	var dbObj_SwSh []int
	dbObj_SwSh = append(dbObj_SwSh, dbObj.Sh)
	dbObj_SwSh = append(dbObj_SwSh, dbObj.Sw)
	sort.Ints(dbObj_SwSh)
	dbObj.Sw = dbObj_SwSh[0]
	dbObj.Sh = dbObj_SwSh[1]
	var req_SwSh []int
	req_SwSh = append(req_SwSh, req.Sh)
	req_SwSh = append(req_SwSh, req.Sw)
	sort.Ints(req_SwSh)
	req.Sw = req_SwSh[0]
	req.Sh = req_SwSh[1]

	if req.Sw != dbObj.Sw {
		diffLog += fmt.Sprintf(" [Sw]%d", req.Sw)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Sw"
	}
	if req.Sh != dbObj.Sh {
		diffLog += fmt.Sprintf(" [Sh]%d", req.Sh)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Sh"
	}
	if req.Sp != dbObj.Sp {
		diffLog += fmt.Sprintf(" [Sp]%s", req.Sp)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Sp"
	}
	if req.Gv != dbObj.Gv {
		diffLog += fmt.Sprintf(" [Gv]%s", req.Gv)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Gv"
	}
	if req.Gr != dbObj.Gr {
		diffLog += fmt.Sprintf(" [Gr]%s", req.Gr)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Gr"
	}
	if req.Os != dbObj.Os {
		diffLog += fmt.Sprintf(" [Os]%s", req.Os)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Os"
	}
	if req.Osver != dbObj.Osver {
		diffLog += fmt.Sprintf(" [Osver]%s", req.Osver)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Osver"
	}
	if req.Appkey != dbObj.Appkey {
		diffLog += fmt.Sprintf(" [Appkey]%s", req.Appkey)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Appkey"
	}
	if req.Ip_xff != dbObj.Ip_xff {
		diffLog += fmt.Sprintf(" [Ip_xff]%s", req.Ip_xff)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Ip_xff"
	}

	if req.Timezone != dbObj.Timezone {
		diffLog += fmt.Sprintf(" [Timezone]%s", req.Timezone)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Timezone"
	}
	if req.Lang != dbObj.Lang {
		diffLog += fmt.Sprintf(" [Lang]%s", req.Lang)
		if diffName != "" {
			diffName += ","
		}
		diffName += "Lang"
	}
	return
}
