package registerservice

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"letsinstallapi/common"
	aeshelper "letsinstallapi/common/aes"
	jwthelper "letsinstallapi/common/jwt"
	otphelper "letsinstallapi/common/otp"
	redishelper "letsinstallapi/common/redis"
	timehelper "letsinstallapi/common/time"
	uidhelper "letsinstallapi/common/uid"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
	"math/big"
	"strings"
	"time"

	"github.com/spf13/viper"
)

//FunctionCode:RG10
func getYaboConsolerUser(flowData *models.FlowData, userName, ctrlCode, serviceCode string) (result models.YaboConsolerUser) {

	sql := "select Id, Account, Pwd, AppKey from YaboConsolerUser where Account = ?;"
	dbModule := factory.GetDbModule("gosql")
	var users []models.YaboConsolerUser
	err := dbModule.Dbo.SqlSelect(&users, sql, userName)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG10", "Get DB Error", err)
		return
	}

	if len(users) < 1 {
		services.SetError(flowData, ctrlCode, serviceCode, "RG10", "該用戶不存在", nil)
		return
	}
	result = users[0]

	return
}

//FunctionCode:RG11
func isRequestPasswordEquaLDbPassword(flowData *models.FlowData, requestPassword, DbPassword, ctrlCode, serviceCode string) (result bool) {

	if requestPassword != DbPassword {
		services.SetError(flowData, ctrlCode, serviceCode, "RG11", "密碼錯誤", nil)
		return false
	}
	return true
}

//FunctionCode:RG12
func updateLastLoginTime(flowData *models.FlowData, userName, ctrlCode, serviceCode string) (result bool) {

	sql := "update YaboConsolerUser set LastloginTime = ? where Account = ?;"
	dbModule := factory.GetDbModule("gosql")
	rowsAffect, err := dbModule.Dbo.SqlUpdateOrDelete(sql, timehelper.GetUTCTime(), userName)
	if err != nil || rowsAffect < 1 {
		services.SetError(flowData, ctrlCode, serviceCode, "RG12", "Update DB Error", err)
		return
	}
	result = true

	return
}

//FunctionCode:RG13
func generateJwtToken(flowData *models.FlowData, userId, ctrlCode, serviceCode string) (result bool) {
	jwtToken, err := jwthelper.GenerateJwtToken(userId)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG13", "jwt產生失敗", err)
		return false
	}
	flowData.Response = models.SignInResponse{JwtToken: jwtToken}

	return true
}

//FunctionCode:RG14
func generateChannelConsoleUrl(flowData *models.FlowData, appkey, account, ctrlCode, serviceCode string) {
	optcode := otphelper.GenerateOTP(appkey)
	domain := viper.GetString("YaboConsolerUserDomain")
	data := fmt.Sprintf("appkey=%s&otpcode=%s&account=%s&domain=%s", appkey, optcode, account, domain)
	encodestr := base64.StdEncoding.EncodeToString([]byte(data))
	host := viper.GetString("ChannelConsole.Url")
	url := fmt.Sprintf("%s?%s?", host, encodestr)
	url = host
	response := flowData.Response.(models.SignInResponse)
	response.ChannelConsoleUrl = url
	flowData.Response = response.ToUrl()
	return
}

//FunctionCode:RG15
func isUserNotSignup(flowData *models.FlowData, userName, phoneNumber, ctrlCode, serviceCode string) bool {

	sql := "select id from YaboConsolerUser where Account = ? and Phone = ?;"
	var id []int
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&id, sql, userName, phoneNumber)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG15", "Get DB Error", err)
		return false
	}

	if len(id) >= 1 {
		services.SetError(flowData, ctrlCode, serviceCode, "RG15", "該帳號或號碼已被使用", nil)
		return false
	}

	return true
}

//FunctionCode:RG16
func getChannelUserRoleId(flowData *models.FlowData, ctrlCode, serviceCode string) (roleId int, isOK bool) {

	var roleIds []int
	sql := "select id as roleId from Role where name = 'channelUser' and delflag = 0;"
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&roleIds, sql)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG16", "Get DB Error", err)
		return
	}
	roleId = roleIds[0]
	isOK = true
	return
}

//FunctionCode:RG17
func createYaboConsolerUser(flowData *models.FlowData, request models.SignUpRequest, roleId int, ctrlCode, serviceCode string) bool {
	domain := viper.GetString("YaboConsolerUserDomain")
	username := strings.Split(request.UserName, "@")[0]
	sql := "insert into YaboConsolerUser(Account, UserName, Pwd, RoleID, CreateUser, LastUpdateUser, Phone, domain, AppKey, CreateDate, LastUpdateTime) value(?, ?, ?, ?, 'rd7', 'rd7', ?, ?, floor(rand()*99999999),?,?);"
	dbModule := factory.GetDbModule("gosql")
	currentTime := timehelper.GetUTCTimeString()
	_, _, err := dbModule.Dbo.SqlInsert(sql, request.UserName, username, request.Password, roleId, request.PhoneNumber, domain, currentTime, currentTime)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG17", "Insert DB Error", err)
		return false
	}
	return true
}

//FunctionCode:RG20
func getUserIdFromJwtToken(flowData *models.FlowData, jwtToken string, userId *string, ctrlCode, serviceCode string) (result bool) {

	parsedUserId, err := jwthelper.ParseJwtToken(jwtToken)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG20", "jwt解碼失敗", err)
		return
	}
	userId = &parsedUserId
	result = true
	return
}

//FunctionCode:RG21
func getRoleRouteFromDB(flowData *models.FlowData, userId, ctrlCode, serviceCode string) {

	sql := "select UserName, Role from YaboConsolerUser where Id = ?;"
	dbModule := factory.GetDbModule("gosql")
	var userRoleRoutes models.UserRoleRoutes
	err := dbModule.Dbo.SqlSelect(&userRoleRoutes, sql, userId)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG21", "Get DB Error", err)
		return
	}

	var roleRoutes []models.RoleRoute
	sql = "select rr.routeId, rt.title from YaboConsolerUser y join RoleRoute rr on y.RoleId = rr.roleId join Route rt on rr.routeId = rt.id where y.Id = ?;"
	err = dbModule.Dbo.SqlSelect(&roleRoutes, sql, userId)
	if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG21", "Get DB Error", err)
		return
	}
	userRoleRoutes.Routes = roleRoutes
	flowData.Response = userRoleRoutes

	return
}

//FunctionCode:RG1
func isCreateNewGroup(flowData *models.FlowData, parentGroup *models.Doc_UserGroupRoleModel, groupKey, controllerCode, serviceCode string) (isCreateNewGroup, noError bool) {

	if groupKey == "" {
		groupKey = viper.GetString("Register.NormalApp.DefaultGroupKey")
	}

	sql := `select UG.id,UG.groupKey,UG.groupName, OU.userKey as userKey,R.id as adminRoleID
		from OwnerUser as OU
		inner join Role as R on R.id=OU.roleID
		inner join UserGroup as UG on UG.groupKey=R.groupKey
		where R.roleName = 'admin' and R.groupKey=? and OU.isEnable=1 limit 1`
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(parentGroup, sql, groupKey)
	if err == nil && parentGroup.Id > 0 {
		isCreateNewGroup = true
		noError = true
	} else if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RG1", "Get GroupKey Error", err)
	} else if parentGroup.Id == 0 {
		services.SetError(flowData, controllerCode, serviceCode, "RG1", "GroupKey驗證錯誤", nil)
	}

	return
}

//FunctionCode:RG2
func createGroupAndRole(flowData *models.FlowData, parentGroup models.Doc_UserGroupRoleModel, requestGroupName, currentTime, controllerCode, serviceCode string) (result bool) {

	sqlArray := []string{}
	argsArray := [][]interface{}{}
	newGroupKey := uidhelper.GetBase16Uid("GK-")
	newGroupName := generateGroupName(requestGroupName, parentGroup.GroupName)

	sqlInsertGroup := `insert into UserGroup (groupKey,userKey,groupName,groupMemo,parentKey,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?,?);`
	argsInsertGroup := []interface{}{newGroupKey, parentGroup.UserKey, newGroupName, "", parentGroup.GroupKey, currentTime, parentGroup.UserKey, currentTime, parentGroup.UserKey}

	/* ========== */
	// Insert Role(3)  admin  owner  user
	sqlInsertRoles := `insert into Role(groupKey,roleLevel,roleName,roleMemo,delflag,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?,?),(?,?,?,?,?,?,?,?,?),(?,?,?,?,?,?,?,?,?);`
	argsInsertRoles := []interface{}{}
	for roleLevel := 1; roleLevel <= 3; roleLevel++ {
		switch roleLevel {
		case 1:
			argsInsertRoles = append(argsInsertRoles, newGroupKey, roleLevel, "admin", "", 0, currentTime, parentGroup.UserKey, currentTime, parentGroup.UserKey)
		case 2:
			argsInsertRoles = append(argsInsertRoles, newGroupKey, roleLevel, "owner", "", 0, currentTime, parentGroup.UserKey, currentTime, parentGroup.UserKey)
		case 3:
			argsInsertRoles = append(argsInsertRoles, newGroupKey, roleLevel, "user", "", 0, currentTime, parentGroup.UserKey, currentTime, parentGroup.UserKey)
		}

	}
	sqlArray = append(sqlArray, sqlInsertGroup, sqlInsertRoles)
	argsArray = append(argsArray, argsInsertGroup, argsInsertRoles)

	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlTransactionExecute(sqlArray, argsArray)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RG2", "創建群組與角色失敗", err)
	}
	return
}

//FunctionCode:RG3
func generateGroupName(requestGroupName, parentGroupName string) (newGroupName string) {

	if parentGroupName != "" {
		newGroupName = strings.Replace(parentGroupName, "_sub", "", -1)
	} else if requestGroupName != "" {
		newGroupName = strings.Replace(requestGroupName, "_sub", "", -1)
	} else {
		newGroupName = "tempGroupName"
	}
	newGroupName += "_sub"

	return
}

//FunctionCode:RG4
func createOwnerUser(flowData *models.FlowData, parentGroup models.Doc_UserGroupRoleModel, request models.RegisterUserRequest, currentTime, controllerCode, serviceCode string) {

	newUserKey := uidhelper.GetBase16Uid("UK-")
	aesPassword := aeshelper.AesEncryptCBC(request.Pwd, aeshelper.AES128Key)
	sql := `insert into OwnerUser(userKey,roleID,roleName,userName,account,pwd,isEnable,vipLevel,lastloginIP,phone
		,createTime,createUser,updateTime,updateUser)
		values (?,?,?,?,?,?,?,?,?,?,?,?,?,?);`
	dbModule := factory.GetDbModule("gosql")
	_, lastId, err := dbModule.Dbo.SqlInsert(sql, newUserKey, parentGroup.AdminRoleID, "admin", request.Account, request.Account, aesPassword, 1, 1, flowData.Data["RequestIP"].(string), request.Phone, currentTime, parentGroup.UserKey, currentTime, parentGroup.UserKey)
	if err == nil {
		request.Id = int(lastId)
		request.Pwd = common.MarkString(request.Pwd, len(request.Pwd))
		flowData.Response = request
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "RG4", "創建帳號失敗", err)
	}

	return
}

//FunctionCode:RG5
func isNewUser(flowData *models.FlowData, userAccount, controllerCode, serviceCode string) (noError bool) {

	if user := getOwnerUser(flowData, userAccount, controllerCode, serviceCode); user.Id == 0 {
		noError = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "RG5", "帳號已存在", nil)
	}

	return
}

//FunctionCode:RG6
func getOwnerUser(flowData *models.FlowData, userAccount, controllerCode, serviceCode string) (user models.Doc_OwnerUserModel) {

	sql := `select id,userKey,roleID,roleName,userName,account,pwd,isEnable,vipLevel,lastloginTime,lastloginIP,cid,phone,isEnable,
		createTime,createUser,updateTime,updateUser
		from OwnerUser
		where account=?
		limit 1;`
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&user, sql, userAccount)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "RG6", "Get OwnerUser Error", err)
	}

	return
}

//FunctionCode:RG7
func isPasswordEqualSavedOne(flowData *models.FlowData, requestPassword, savedPassword, controllerCode, serviceCode string) (isOK bool) {

	if aeshelper.AesEncryptCBC(requestPassword, aeshelper.AES128Key) != savedPassword {
		services.SetError(flowData, controllerCode, serviceCode, "RG7", "密碼錯誤", nil)
	}
	isOK = true

	return
}

//FunctionCode:RG8
func getOwnerUserIdByAccount(flowData *models.FlowData, request models.Doc_UserLoginReq, controllerCode, serviceCode string) (ownerUserId int) {

	if user := getOwnerUser(flowData, request.Account, controllerCode, "RG2"); user.Id == 0 {
		services.SetError(flowData, controllerCode, serviceCode, "RG8", "帳號不存在", nil)
	} else if user.Id > 0 &&
		isPasswordEqualSavedOne(flowData, request.Pwd, user.Pwd, controllerCode, serviceCode) {
		ownerUserId = user.Id
	}

	return
}

//FunctionCode:RG9
func newCid() string {
	return fmt.Sprintf("%s#%d", uidhelper.NewXid(), time.Now().Unix())
}

//FunctionCode:RG10
func updateLoginData(flowData *models.FlowData, ownerUserId int, cid, currentTime, controllerCode, serviceCode string) (isOK bool) {

	sql := `update OwnerUser set lastloginIP=?,lastloginTime=?,cid=? where id=?;`
	dbModule := factory.GetDbModule("gosql")
	rowsAffect, err := dbModule.Dbo.SqlUpdateOrDelete(sql, flowData.Data["RequestIP"].(string), currentTime, cid, ownerUserId)
	if err == nil && rowsAffect == 1 {
		isOK = true
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "RG10", "Update LoginData Error", err)
	}

	return
}

//FunctionCode:RG11
func insertCidLog(flowData *models.FlowData, userKey, groupKey, cid, currentTime, controllerCode, serviceCode string) {

	sql := `insert into OwnerUserCids(userKey,groupKey,lastloginTime,lastloginIP,cid) values (?,?,?,?,?);`
	dbModule := factory.GetDbModule("gosql")
	rowsAffect, _, err := dbModule.Dbo.SqlInsert(sql, userKey, groupKey, currentTime, flowData.Data["RequestIP"].(string), cid)
	if err == nil && rowsAffect == 1 {
		flowData.Response = models.Doc_UserLoginModel{Cid: cid}
	} else {
		services.SetError(flowData, controllerCode, serviceCode, "RG11", "Insert Cid Log Error", err)
	}

	return
}

//FunctionCode:RG12
func getGroupKeyFromPromotionCode(flowData *models.FlowData, promotionCode, controllerCode, serviceCode string) (groupKey string, isOK bool) {

	if promotionCode != "" {
		codeJosn := aeshelper.AesDecryptCBC(promotionCode, aeshelper.AES128Key)
		var codeModel models.Doc_PromoKeyModel
		err := json.Unmarshal([]byte(codeJosn), &codeModel)
		if err == nil {
			nowTimeUnix := timehelper.GetUTCTime().Unix()
			if codeModel.ActiveTime <= 0 || nowTimeUnix < codeModel.ActiveTime {
				groupKey = codeModel.GroupKey
			} else {
				services.SetError(flowData, controllerCode, serviceCode, "RG12", "推廣碼過期", err)
			}
		} else {
			services.SetError(flowData, controllerCode, serviceCode, "RG12", "推廣碼不正確", err)
		}
	} else {
		groupKey = viper.GetString("Register.NormalApp.DefaultGroupKey")
	}
	isOK = true

	return
}

//FunctionCode:RG13
func isRequestOtpCodeEqualCacheOtpCode(flowData *models.FlowData, otpCode, phoneNumber, ctrlCode, serviceCode string) (result bool) {

	cacheOtpCode := getCacheOtpCode(phoneNumber)
	if otpCode == cacheOtpCode {
		result = true
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, "RG13", "驗證碼不正確", nil)
	}

	return
}

//FunctionCode:RG14
func isUserPhoneExsited(flowData *models.FlowData, phoneNumber, ctrlCode, serviceCode string) (result bool) {

	sql := "select count(*) from OwnerUser where phone = ?;"
	var userCount int
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&userCount, sql, phoneNumber)
	if err == nil && userCount == 1 {
		result = true
	} else if err != nil {
		services.SetError(flowData, ctrlCode, serviceCode, "RG14", "Get DB Error", err)
	} else if userCount < 1 {
		services.SetError(flowData, ctrlCode, serviceCode, "RG14", "找不到該用戶", nil)
	}

	return
}

//FunctionCode:RG15
func isPasswordFormatWell(flowData *models.FlowData, password, ctrlCode, serviceCode string) (result bool) {

	if common.IsNoBlankViewableAsciiString(password) {
		result = true
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, "RG15", "密碼格式有誤", nil)
	}
	return
}

//FunctionCode:RG16
func isPasswordEqualEnsurePassword(flowData *models.FlowData, password, ensurePassword, ctrlCode, serviceCode string) (result bool) {

	if password == ensurePassword {
		result = true
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, "RG16", "兩次輸入密碼不相同", nil)
	}
	return
}

//FunctionCode:RG17
func resetUserPassword(flowData *models.FlowData, request models.ForgetPasswordRequest, ctrlCode, serviceCode string) {

	sql := "update OwnerUser set pwd = ? where Phone = ?;"
	dbModule := factory.GetDbModule("gosql")
	rowsAffect, err := dbModule.Dbo.SqlUpdateOrDelete(sql, aeshelper.AesEncryptCBC(request.Password, aeshelper.AES128Key), request.PhoneNumber)
	if err != nil || rowsAffect != 1 {
		services.SetError(flowData, ctrlCode, serviceCode, "RG17", "更新密碼失敗", err)
	}
}

//FunctionCode:RG18
func getCacheOtpCode(phoneNumber string) (cacheOtpCode string) {

	redisKey := fmt.Sprintf("otp_phone:%s", phoneNumber)
	cacheOtpCode = redishelper.GetKey(redisKey)
	return
}

//FunctionCode:RG19
func isPhoneNumberFormatWell(flowData *models.FlowData, phoneNumber, ctrlCode, serviceCode string) bool {
	for i := range phoneNumber {
		if phoneNumber[i] > '9' || phoneNumber[i] < '0' {
			services.SetError(flowData, ctrlCode, serviceCode, "RG19", "電話號碼格式有誤", nil)
			return false
		}
	}

	return true
}

//FunctionCode:RG20
func generateOtpCode() (otpCode string) {

	for i := 0; i < 6; i++ {
		result, _ := rand.Int(rand.Reader, big.NewInt(10))
		otpCode += result.String()
	}

	return
}

//FunctionCode:RG21
func setOtpCode2Redis(otpCode, phoneNumber string) {
	redisKey := fmt.Sprintf("otp_phone:%s", phoneNumber)
	redishelper.SetRedisDataWithAcitiveSecond(redisKey, otpCode, 600)
}

//FunctionCode:RG22
func sendAuthCodeToPhone(flowData *models.FlowData, request models.GetVerifyCodeRequest, otpCode, ctrlCode, serviceCode string) {

	if sendVerifyCodeRequest, isOK := getSendVerifyCodeRequest(flowData, request, otpCode, ctrlCode, serviceCode); isOK {

		host := viper.GetString("RD2.Host")
		url := viper.GetString("RD2.ApiList.sendVerifyCode.uri")
		responseBody, err := common.APIPOST(fmt.Sprintf("%s/%s", host, url), nil, nil, sendVerifyCodeRequest)
		if err == nil {
			var responseJson models.VerifyCodeResp
			err = json.Unmarshal(responseBody, &responseJson)
			if err != nil {
				services.SetError(flowData, ctrlCode, serviceCode, "RG22", "傳送OTPCode異常", err)
			}
		} else {
			services.SetError(flowData, ctrlCode, serviceCode, "RG22", "傳送OTPCode失敗", err)
		}
	}

	return
}

//FunctionCode:RG23
func getSendVerifyCodeRequest(flowData *models.FlowData, request models.GetVerifyCodeRequest, otpCode, ctrlCode, serviceCode string) (sendVerifyCodeRequest []byte, isOK bool) {
	verifyCode := models.VerifyCode{
		Mobile:      request.PhoneNumber,
		Msg:         otpCode,
		CountryCode: request.CountryCode,
		Platfrom:    "LetsInstall",
		Test:        0,
	}
	sendVerifyCodeRequest, err := json.Marshal(verifyCode)
	if err == nil {
		isOK = true
	} else {
		services.SetError(flowData, ctrlCode, serviceCode, "RG23", "物件反序列錯誤", err)
	}

	return
}
