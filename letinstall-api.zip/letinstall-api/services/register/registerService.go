package registerservice

import (
	"context"
	otphelper "letsinstallapi/common/otp"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/models"
	"letsinstallapi/services"
)

// ServiceCode:RG1
func CheckOTPCode(flowData *models.FlowData, ctrlCode string) (outCtx context.Context) {

	request := flowData.Request.(models.OTPCheckRequest)
	response := otphelper.VerifyOTP(request.AppKey, request.OtpCode)
	flowData.Response = response

	return
}

// ServiceCode:RG4
func SignIn(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.SignInRequest)

	if !isPasswordFormatWell(flowData, request.Password, ctrlCode, "RG4") {
		return
	}

	yaboConsolerUser := getYaboConsolerUser(flowData, request.UserName, ctrlCode, "RG4")

	if isRequestPasswordEquaLDbPassword(flowData, request.Password, yaboConsolerUser.Password, ctrlCode, "RG4") &&
		updateLastLoginTime(flowData, request.UserName, ctrlCode, "RG4") &&
		generateJwtToken(flowData, yaboConsolerUser.UserId, ctrlCode, "RG4") {
		generateChannelConsoleUrl(flowData, yaboConsolerUser.Appkey, yaboConsolerUser.Account, ctrlCode, "RG4")
	}

	return
}

// ServiceCode:RG5
func SignUp(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.SignUpRequest)

	if isPasswordFormatWell(flowData, request.Password, ctrlCode, "RG5") &&
		isPhoneNumberFormatWell(flowData, request.PhoneNumber, ctrlCode, "RG5") &&
		isPasswordEqualEnsurePassword(flowData, request.Password, request.EnsurePassword, ctrlCode, "RG5") &&
		isRequestOtpCodeEqualCacheOtpCode(flowData, request.OtpCode, request.PhoneNumber, ctrlCode, "RG5") &&
		isUserNotSignup(flowData, request.UserName, request.PhoneNumber, ctrlCode, "RG5") {
		roleId, isOK := getChannelUserRoleId(flowData, ctrlCode, "RG5")
		if !isOK {
			return
		}
		createYaboConsolerUser(flowData, request, roleId, ctrlCode, "RG5")
	}

	return
}

// ServiceCode:RG6
func GetRoleRoute(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.RoleRouteRequest)

	userId := ""
	if getUserIdFromJwtToken(flowData, request.JwtToken, &userId, ctrlCode, "RG6") {
		getRoleRouteFromDB(flowData, userId, ctrlCode, "RG6")
	}

	return
}

// ServiceCode:RG1
func RegisterUser(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.RegisterUserRequest)

	if !isUserPhoneExsited(flowData, request.Phone, controllerCode, "RG1") {
		parentGroup := models.Doc_UserGroupRoleModel{}
		currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

		if groupKey, isOK := getGroupKeyFromPromotionCode(flowData, request.PromotionCode, controllerCode, "RG1"); isOK &&
			isNewUser(flowData, request.Account, controllerCode, "RG1") {
			if isCreateNewGroup, noError := isCreateNewGroup(flowData, &parentGroup, groupKey, controllerCode, "RG1"); !noError {
				return
			} else if isCreateNewGroup {
				createGroupAndRole(flowData, parentGroup, request.GroupName, currentTime, controllerCode, "RG1")
			}

			createOwnerUser(flowData, parentGroup, request, currentTime, controllerCode, "RG1")
		}
	}

	return
}

// ServiceCode:RG2
func UserLogin(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.Doc_UserLoginReq)

	currentTime := timehelper.GetUTCTime().Format("2006-01-02 15:04:05")

	if ownerUserId := getOwnerUserIdByAccount(flowData, request, controllerCode, "RG2"); ownerUserId > 0 {
		cid := newCid()

		if updateLoginData(flowData, ownerUserId, cid, currentTime, controllerCode, "RG2") {
			keys, isOK := services.GetKeysByCid(flowData, cid, controllerCode, "RG2")
			if isOK {
				insertCidLog(flowData, keys.UserKey, keys.GroupKey, cid, currentTime, controllerCode, "RG2")
			}
		}
	}

	return
}

// ServiceCode:RG3
func ForgetPassword(flowData *models.FlowData, controllerCode string) {

	request := flowData.Request.(models.ForgetPasswordRequest)

	if isRequestOtpCodeEqualCacheOtpCode(flowData, request.OtpCode, request.PhoneNumber, controllerCode, "RG3") &&
		isUserPhoneExsited(flowData, request.PhoneNumber, controllerCode, "RG3") &&
		isPasswordFormatWell(flowData, request.Password, controllerCode, "RG3") &&
		isPasswordEqualEnsurePassword(flowData, request.Password, request.EnsurePassword, controllerCode, "RG3") {
		resetUserPassword(flowData, request, controllerCode, "RG3")
	}

	return
}

// ServiceCode:RG4
func GetVerifyCode(flowData *models.FlowData, ctrlCode string) {

	request := flowData.Request.(models.GetVerifyCodeRequest)

	if isPhoneNumberFormatWell(flowData, request.PhoneNumber, ctrlCode, "RG4") {
		otpCode := generateOtpCode()
		setOtpCode2Redis(otpCode, request.PhoneNumber)
		sendAuthCodeToPhone(flowData, request, otpCode, ctrlCode, "RG4")
	}

	return
}
