package owneruserservice

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

//ResetPassword serviceCode:OU1
func ResetPassword(flowData *models.FlowData, controllerCode string) {
	keys, isOK := services.GetKeysByCid(flowData, flowData.Request.(models.ResetPassword).Cid, controllerCode, "OU1")
	if !isOK {
		return
	}
	updatePasswordToDB(flowData, keys, controllerCode, "OU1")
}

//GetOwnerUser serviceCode:OU2
func GetOwnerUser(flowData *models.FlowData, controllerCode string) {
	keys, isOK := services.GetKeysByCid(flowData, flowData.Request.(models.GetOwnerUser).Cid, controllerCode, "OU2")
	if !isOK {
		return
	}
	getOwnerUserFromDB(flowData, keys, controllerCode, "OU2")
}

//EditOwnerUser serviceCode:OU3
func EditOwnerUser(flowData *models.FlowData, controllerCode string) {
	keys, isOK := services.GetKeysByCid(flowData, flowData.Request.(models.Doc_OwnerUserModel).Cid, controllerCode, "OU3")
	if !isOK {
		return
	}
	updateOwnerUserToDB(flowData, keys, controllerCode, "OU3")
}
