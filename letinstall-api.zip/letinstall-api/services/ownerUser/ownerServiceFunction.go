package owneruserservice

import (
	aeshelper "letsinstallapi/common/aes"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
)

//updatePasswordToDB functionCode:OU1
func updatePasswordToDB(flowData *models.FlowData, key models.UserAndGroupKey, controllerCode, serviceCode string) {
	req := flowData.Request.(models.ResetPassword)
	currentTime := timehelper.GetUTCTimeString()
	req.Pwd = aeshelper.AesEncryptCBC(req.Pwd, aeshelper.AES128Key)
	req.NewPwd = aeshelper.AesEncryptCBC(req.NewPwd, aeshelper.AES128Key)

	sql := "update OwnerUser set pwd = ?, updateTime = ?, updateUser = ? where userKey = ? and pwd = ?;"
	dbModule := factory.GetDbModule("gosql")
	num, err := dbModule.Dbo.SqlUpdateOrDelete(sql, req.NewPwd, currentTime, key.Account, key.UserKey, req.Pwd)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "OU1", "Update DB Error", err)
		return
	}
	if num == 0 {
		services.SetError(flowData, controllerCode, serviceCode, "OU1", "密碼錯誤！", err)
		return
	}

	result := models.UpdateStatusModel{}
	result.Action = "update"
	result.Status = true

	flowData.Response = result
}

//getOwnerUserFromDB functionCode:OU2
func getOwnerUserFromDB(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {
	req := flowData.Request.(models.GetOwnerUser)
	var args []interface{}

	where := " and userKey = ?"
	args = append(args, keys.UserKey)
	if req.Where.UserName != "" {
		req.Where.UserName = "%" + req.Where.UserName + "%"
		where += " and userName like ?"
		args = append(args, req.Where.UserName)
	}
	if req.Where.UpdateTime_start != "" {
		where += " and updateTime >= ?"
		args = append(args, req.Where.UpdateTime_start)
	}
	if req.Where.UpdateTime_end != "" {
		where += " and updateTime <= ?"
		args = append(args, req.Where.UpdateTime_end)
	}
	if req.Where.UpdateUser != "" {
		where += " and updateUser = ?"
		args = append(args, req.Where.UpdateUser)
	}
	if len(where) != 0 {
		where = " where " + where[5:]
	}
	order := ""
	if req.OrderBy.OrderType == "asc" || req.OrderBy.OrderType == "desc" {
		order += " ? " + req.OrderBy.OrderType
		args = append(args, req.OrderBy.ColumnName)
	}
	if len(order) != 0 {
		order = " order by" + order
	}
	limit := ""
	if req.Number > 0 && req.Limit > 0 {
		limit += " ?, ?"
		number := (req.Number - 1) * req.Limit
		args = append(args, number)
		args = append(args, req.Limit)
	}
	if len(limit) != 0 {
		limit = " limit" + limit
	}

	query := "select id, userKey, roleID, roleName, userName, account, pwd, vipLevel, lastloginTime, lastloginIP, cid, phone, isEnable, createTime, createUser, updateTime, updateUser, email from OwnerUser" + where + order + limit + ";"
	dbModule := factory.GetDbModule("gosql")
	result := models.Doc_GetOwnerUserRM{}
	err := dbModule.Dbo.SqlSelect(&result.Data, query, args...)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "OU3", "Get DB Error", err)
		return
	}
	result.TotalCount = len(result.Data)

	flowData.Response = result
}

//updateOwnerUserToDB functionCode:OU3
func updateOwnerUserToDB(flowData *models.FlowData, keys models.UserAndGroupKey, controllerCode, serviceCode string) {
	req := flowData.Request.(models.Doc_OwnerUserModel)
	//flowData.Response = req

	sql := "update OwnerUser set roleid = ?, rolename = ?, username = ?, viplevel = ?, phone = ?, email = ?, isenable = ? where userKey = ?"

}
