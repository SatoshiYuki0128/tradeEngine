package applistservice

import (
	"letsinstallapi/models"
	"letsinstallapi/services"
)

// GetAppList serviceCode: AL1
func GetAppList(flowData *models.FlowData, controllerCode string) {
	cid := flowData.Request.(models.PostAppReq).Cid

	keys, isOK := services.GetKeysByCid(flowData, cid, controllerCode, "Al1")
	if !isOK {
		return
	}
	//fmt.Println(groupKey)

	isOK = getAppListData(flowData, keys.GroupKey, controllerCode, "AL1")
	if !isOK {
		return
	}
	//fmt.Println(data)
}

// EditAppList serviceCode: AL2
func EditAppList(flowData *models.FlowData, controllerCode string) {
	req := flowData.Request.(models.EditAppListReq)

	keys, isOK := services.GetKeysByCid(flowData, req.Cid, controllerCode, "Al2")
	if !isOK {
		return
	}
	if req.Id < 1 {
		insertAppList(flowData, req, keys, controllerCode, "AL2")
	} else {
		updateAppList(flowData, req, keys, controllerCode, "AL2")
	}
}
