package applistservice

import (
	iplocationhelper "letsinstallapi/common/ipLocation"
	timehelper "letsinstallapi/common/time"
	uidhelper "letsinstallapi/common/uid"
	"letsinstallapi/factory"
	"letsinstallapi/models"
	"letsinstallapi/services"
)

// functionCode: AL1
//func getAppListGroupKey(flowData *models.FlowData, controllerCode, serviceCode string) (groupKey string, isOK bool) {
//	sql := `select R.groupKey from OwnerUser as OU inner join Role as R on R.Id=OU.RoleID where OU.userKey=?;`
//	dbModule := factory.GetDbModule("gosql")
//	userKey := flowData.Request.(models.PostAppReq).UserKey
//	err := dbModule.Dbo.SqlSelect(&groupKey, sql, userKey)
//	if err != nil {
//		services.SetError(flowData, controllerCode, serviceCode, "AL1", "Get DB Error", err)
//		return
//	}
//
//	if len(groupKey) < 1 {
//		services.SetError(flowData, controllerCode, serviceCode, "AL1", "該用戶不存在", nil)
//		return
//	}
//
//	isOK = true
//
//	return
//}

// functionCode: AL2
func getAppListData(flowData *models.FlowData, groupKey string, controllerCode, serviceCode string) (isOK bool) {
	var result []models.GetAppList
	req := flowData.Request.(models.PostAppReq)
	var args []interface{}

	where := ""
	if req.Where.AppKey != "" {
		where += " and appKey = ?"
		args = append(args, req.Where.AppKey)
	}
	if groupKey != "" {
		where += " and groupKey = ?"
		args = append(args, groupKey)
	}
	if req.Where.AppName != "" {
		req.Where.AppName = "%" + req.Where.AppName + "%"
		where += " and appName like ?"
		args = append(args, req.Where.AppName)
	}
	if req.Where.Platform != "" {
		where += " and platform = ?"
		args = append(args, req.Where.Platform)
	}
	if req.Where.UpdateTime_start != "" {
		where += " and updateTime >= ?"
		args = append(args, services.IpTimeToUTCTime(flowData, flowData.Data["RequestIP"].(string), req.Where.UpdateTime_start, controllerCode, serviceCode))
	}
	if req.Where.UpdateTime_end != "" {
		where += " and updateTime <= ?"
		args = append(args, services.IpTimeToUTCTime(flowData, flowData.Data["RequestIP"].(string), req.Where.UpdateTime_end, controllerCode, serviceCode))
	}
	if req.Where.UpdateUser != "" {
		where += " and updateUser = ?"
		args = append(args, req.Where.UpdateUser)
	}
	if len(where) != 0 {
		where = " where " + where[5:] + " and delFlag = 0"
	}
	order := ""
	if req.OrderBy.OrderType == "asc" || req.OrderBy.OrderType == "desc" {
		order += " ? " + req.OrderBy.OrderType
		args = append(args, req.OrderBy.ColumnName)
		//args = append(args, req.OrderBy.OrderType)
	}
	if len(order) != 0 {
		order = " order by" + order
	}
	limit := ""
	if req.Page.Number > 0 && req.Page.Limit > 0 {
		limit += " ?, ?"
		number := (req.Page.Number - 1) * req.Page.Limit
		args = append(args, number)
		args = append(args, req.Page.Limit)
	}
	if len(limit) != 0 {
		limit = " limit" + limit
	}

	sql := "select id, appKey, groupKey, appName, appName_tw, appName_cn, appName_en, platform, versionNumber, userCountryCode, createTime, createUser, updateTime, updateUser, isActive, delFlag from App" + where + order + limit + ";"
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&result, sql, args...)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AL2", "Get DB Error", err)
		return
	}

	flowData.Response = result
	isOK = true

	return
}

func insertAppList(flowData *models.FlowData, req models.EditAppListReq, keys models.UserAndGroupKey, controllerCode, serviceCode string) (isOK bool) {
	sql := "insert into App (appKey, groupKey, appName, appName_tw, appName_cn, appName_en, platform, versionNumber, userIP, userCountryCode, isActive, delFlag, createTime, createUser, updateTime, updateUser) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
	dbModule := factory.GetDbModule("gosql")

	currentTime := timehelper.GetUTCTimeString()
	appKey := uidhelper.GetBase16Uid("AK-")
	ip := flowData.Data["RequestIP"].(string)
	ipLocation, err := iplocationhelper.GetIpLocaton(ip)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AL3", "無法定位", err)
		return
	}

	_, _, err = dbModule.Dbo.SqlInsert(sql, appKey, keys.GroupKey, req.AppName, req.AppName_tw, req.AppName_cn, req.AppName_en, req.Platform, req.VersionNumber, ip, ipLocation.Country, req.IsActive, req.DelFlag, currentTime, keys.UserKey, currentTime, keys.UserKey)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AL3", "Insert DB Error", err)
		return
	}

	//sql = "select id, appKey, groupKey, appName, appName_tw, appName_cn, appName_en, platform, versionNumber, userIP, userCountryCode, isActive, delFlag, createDate, createUser, updateTime, updateUser from App where id = ?;"
	//result := models.EditAppListRes{}
	//err = dbModule.Dbo.SqlSelect(&result, sql, lastId)
	//if err != nil {
	//	services.SetError(flowData, controllerCode, serviceCode, "AL3", "Select DB Error", err)
	//	return
	//}

	var result = models.UpdateStatusModel{}
	result.Action = "insert"
	result.Status = true
	flowData.Response = result

	isOK = true
	return
}

func updateAppList(flowData *models.FlowData, req models.EditAppListReq, keys models.UserAndGroupKey, controllerCode, serviceCode string) (isOK bool) {
	sql := "update App set groupKey = ?, appName = ?, appName_tw = ?, appName_cn = ?, appName_en = ?, platform = ?, versionNumber = ?, userIP = ?, userCountryCode = ?, isActive = ?, delFlag = ?, updateTime = ?, updateUser = ? where id = ?;"
	dbModule := factory.GetDbModule("gosql")

	currentTime := timehelper.GetUTCTimeString()
	//appKey := uidhelper.GetBase16Uid("AK-")
	ip := flowData.Data["RequestIP"].(string)
	ipLocation, err := iplocationhelper.GetIpLocaton(ip)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AL3", "找不到countryCode", err)
		return
	}

	count, err := dbModule.Dbo.SqlUpdateOrDelete(sql, keys.GroupKey, req.AppName, req.AppName_tw, req.AppName_cn, req.AppName_en, req.Platform, req.VersionNumber, ip, ipLocation.Country, req.IsActive, req.DelFlag, currentTime, keys.UserKey, req.Id)
	if err != nil {
		services.SetError(flowData, controllerCode, serviceCode, "AL3", "Insert DB Error", err)
		return
	}
	if count == 0 {
		services.SetError(flowData, controllerCode, serviceCode, "AL3", "找不到這筆資料", err)
		return
	}

	//sql = "select id, appKey, groupKey, appName, appName_tw, appName_cn, appName_en, platform, versionNumber, userIP, userCountryCode, isActive, delFlag, createDate, createUser, updateTime, updateUser from App where id = ?"
	//result := models.EditAppListRes{}
	//err = dbModule.Dbo.SqlSelect(&result, sql, req.Id)
	//if err != nil {
	//	services.SetError(flowData, controllerCode, serviceCode, "AL3", "Select DB Error", err)
	//	return
	//}

	var result = models.UpdateStatusModel{}
	if req.DelFlag == 1 {
		result.Action = "delete"
		result.Status = true
	} else {
		result.Action = "update"
		result.Status = true
	}

	flowData.Response = result
	isOK = true

	return
}
