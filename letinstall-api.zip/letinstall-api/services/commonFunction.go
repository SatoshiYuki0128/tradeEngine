package services

import (
	iplocationhelper "letsinstallapi/common/ipLocation"
	timehelper "letsinstallapi/common/time"
	"letsinstallapi/factory"
	"letsinstallapi/models"
)

//FunctionCode:N/A
func SetError(flowData *models.FlowData, controllerCode, serviceCode, functionCode, errorMessage string, baseError error) {
	servErr := models.ServError{ServCode: serviceCode, FuncCode: functionCode, Msg: errorMessage, Err: baseError}
	flowData.CtrlError = models.CtrlError{CtrlCode: controllerCode, ServError: servErr}
}

//FunctionCode:C1
func GetGroupKeyByUserKey(flowData *models.FlowData, userKey, controllerCode, serviceCode string) (groupKey string, isOK bool) {
	sql := `select R.groupKey from OwnerUser as OU inner join Role as R on R.Id=OU.RoleID where OU.userKey=?;`
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&groupKey, sql, userKey)
	if err != nil {
		SetError(flowData, controllerCode, serviceCode, "C1", "Get DB Error", err)
		return
	}

	if len(groupKey) < 1 {
		SetError(flowData, controllerCode, serviceCode, "C1", "該用戶不存在", nil)
		return
	}

	isOK = true

	return
}

//FunctionCode:C2
func initFlowData(flowData *models.FlowData, controllerCode, serviceCode string) {
	if flowData.Data == nil {
		flowData.Data = map[string]interface{}{}
	}
}

//FunctionCode:C3
func GetKeysByCid(flowData *models.FlowData, cid, controllerCode, serviceCode string) (keys models.UserAndGroupKey, isOK bool) {
	sql := `select R.groupKey,OU.userKey,OU.account,OU.roleID
		from OwnerUser as OU 
		inner join Role as R on R.id=OU.roleID
		where OU.cid= ? ;`
	dbModule := factory.GetDbModule("gosql")
	err := dbModule.Dbo.SqlSelect(&keys, sql, cid)
	if err != nil || keys.UserKey == "" || keys.GroupKey == "" || keys.Account == "" || keys.RoleId == 0 {
		SetError(flowData, controllerCode, serviceCode, "C3", "驗證失敗", err)
	} else {
		isOK = true
	}

	return
}

//FunctionCode:C4
func IpTimeToUTCTime(flowData *models.FlowData, ip, time, controllerCode, serviceCode string) (utcTimeString string) {

	ipLocation, err := iplocationhelper.GetIpLocaton(ip)
	if err == nil {
		utcTime, err := timehelper.ParseWithLocation(ipLocation.TimeZone, time)
		if err == nil {
			utcTimeString = utcTime.Format(timehelper.TIME_LAYOUT)
		} else {
			SetError(flowData, controllerCode, serviceCode, "C4", "時間轉換失敗", err)
		}
	} else {
		SetError(flowData, controllerCode, serviceCode, "C4", "定位失敗", err)
	}

	return
}
